var require = meteorInstall({"lib":{"random.js":["babel-runtime/helpers/typeof",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/random.js                                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                        //
                                                                                                               //
var _typeof3 = _interopRequireDefault(_typeof2);                                                               //
                                                                                                               //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }              //
                                                                                                               //
;                                                                                                              // 2
                                                                                                               //
(function (root, factory) {                                                                                    // 2
  // Support AMD                                                                                               // 4
  if (typeof define === 'function' && define.amd) {                                                            // 5
    define([], factory); // Support CommonJS                                                                   // 6
  } else if ((typeof exports === "undefined" ? "undefined" : (0, _typeof3.default)(exports)) === 'object') {   // 9
    var randomColor = factory(); // Support NodeJS & Component, which allow module.exports to be a function    // 10
                                                                                                               //
    if ((typeof module === "undefined" ? "undefined" : (0, _typeof3.default)(module)) === 'object' && module && module.exports) {
      exports = module.exports = randomColor;                                                                  // 14
    } // Support CommonJS 1.1.1 spec                                                                           // 15
                                                                                                               //
                                                                                                               //
    exports.randomColor = randomColor; // Support vanilla script loading                                       // 18
  } else {                                                                                                     // 21
    root.randomColor = factory();                                                                              // 22
  }                                                                                                            // 23
                                                                                                               //
  ;                                                                                                            // 23
})(this, function () {                                                                                         // 25
  // Shared color dictionary                                                                                   // 27
  var colorDictionary = {}; // Populate the color dictionary                                                   // 28
                                                                                                               //
  loadColorBounds();                                                                                           // 31
                                                                                                               //
  var randomColor = function (options) {                                                                       // 33
    options = options || {};                                                                                   // 34
    var H, S, B; // Check if we need to generate multiple colors                                               // 36
                                                                                                               //
    if (options.count != null) {                                                                               // 39
      var totalColors = options.count,                                                                         // 41
          colors = [];                                                                                         // 41
      options.count = null;                                                                                    // 44
                                                                                                               //
      while (totalColors > colors.length) {                                                                    // 46
        colors.push(randomColor(options));                                                                     // 47
      }                                                                                                        // 48
                                                                                                               //
      options.count = totalColors;                                                                             // 50
      return colors;                                                                                           // 52
    } // First we pick a hue (H)                                                                               // 53
                                                                                                               //
                                                                                                               //
    H = pickHue(options); // Then use H to determine saturation (S)                                            // 56
                                                                                                               //
    S = pickSaturation(H, options); // Then use S and H to determine brightness (B).                           // 59
                                                                                                               //
    B = pickBrightness(H, S, options); // Then we return the HSB color in the desired format                   // 62
                                                                                                               //
    return setFormat([H, S, B], options);                                                                      // 65
  };                                                                                                           // 66
                                                                                                               //
  function pickHue(options) {                                                                                  // 68
    var hueRange = getHueRange(options.hue),                                                                   // 70
        hue = randomWithin(hueRange); // Instead of storing red as two seperate ranges,                        // 70
    // we group them, using negative numbers                                                                   // 74
                                                                                                               //
    if (hue < 0) {                                                                                             // 75
      hue = 360 + hue;                                                                                         // 75
    }                                                                                                          // 75
                                                                                                               //
    return hue;                                                                                                // 77
  }                                                                                                            // 79
                                                                                                               //
  function pickSaturation(hue, options) {                                                                      // 81
    if (options.luminosity === 'random') {                                                                     // 83
      return randomWithin([0, 100]);                                                                           // 84
    }                                                                                                          // 85
                                                                                                               //
    if (options.hue === 'monochrome') {                                                                        // 87
      return 0;                                                                                                // 88
    }                                                                                                          // 89
                                                                                                               //
    var saturationRange = getSaturationRange(hue);                                                             // 91
    var sMin = saturationRange[0],                                                                             // 93
        sMax = saturationRange[1];                                                                             // 93
                                                                                                               //
    switch (options.luminosity) {                                                                              // 96
      case 'bright':                                                                                           // 98
        sMin = 55;                                                                                             // 99
        break;                                                                                                 // 100
                                                                                                               //
      case 'dark':                                                                                             // 102
        sMin = sMax - 10;                                                                                      // 103
        break;                                                                                                 // 104
                                                                                                               //
      case 'light':                                                                                            // 106
        sMax = 55;                                                                                             // 107
        break;                                                                                                 // 108
    }                                                                                                          // 96
                                                                                                               //
    return randomWithin([sMin, sMax]);                                                                         // 111
  }                                                                                                            // 113
                                                                                                               //
  function pickBrightness(H, S, options) {                                                                     // 115
    var brightness,                                                                                            // 117
        bMin = getMinimumBrightness(H, S),                                                                     // 117
        bMax = 100;                                                                                            // 117
                                                                                                               //
    switch (options.luminosity) {                                                                              // 121
      case 'dark':                                                                                             // 123
        bMax = bMin + 20;                                                                                      // 124
        break;                                                                                                 // 125
                                                                                                               //
      case 'light':                                                                                            // 127
        bMin = (bMax + bMin) / 2;                                                                              // 128
        break;                                                                                                 // 129
                                                                                                               //
      case 'random':                                                                                           // 131
        bMin = 0;                                                                                              // 132
        bMax = 100;                                                                                            // 133
        break;                                                                                                 // 134
    }                                                                                                          // 121
                                                                                                               //
    return randomWithin([bMin, bMax]);                                                                         // 137
  }                                                                                                            // 139
                                                                                                               //
  function setFormat(hsv, options) {                                                                           // 141
    switch (options.format) {                                                                                  // 143
      case 'hsvArray':                                                                                         // 145
        return hsv;                                                                                            // 146
                                                                                                               //
      case 'hslArray':                                                                                         // 148
        return HSVtoHSL(hsv);                                                                                  // 149
                                                                                                               //
      case 'hsl':                                                                                              // 151
        var hsl = HSVtoHSL(hsv);                                                                               // 152
        return 'hsl(' + hsl[0] + ', ' + hsl[1] + '%, ' + hsl[2] + '%)';                                        // 153
                                                                                                               //
      case 'rgbArray':                                                                                         // 155
        return HSVtoRGB(hsv);                                                                                  // 156
                                                                                                               //
      case 'rgb':                                                                                              // 158
        var rgb = HSVtoRGB(hsv);                                                                               // 159
        return 'rgb(' + rgb.join(', ') + ')';                                                                  // 160
                                                                                                               //
      default:                                                                                                 // 162
        return HSVtoHex(hsv);                                                                                  // 163
    }                                                                                                          // 143
  }                                                                                                            // 166
                                                                                                               //
  function getMinimumBrightness(H, S) {                                                                        // 168
    var lowerBounds = getColorInfo(H).lowerBounds;                                                             // 170
                                                                                                               //
    for (var i = 0; i < lowerBounds.length - 1; i++) {                                                         // 172
      var s1 = lowerBounds[i][0],                                                                              // 174
          v1 = lowerBounds[i][1];                                                                              // 174
      var s2 = lowerBounds[i + 1][0],                                                                          // 177
          v2 = lowerBounds[i + 1][1];                                                                          // 177
                                                                                                               //
      if (S >= s1 && S <= s2) {                                                                                // 180
        var m = (v2 - v1) / (s2 - s1),                                                                         // 182
            b = v1 - m * s1;                                                                                   // 182
        return m * S + b;                                                                                      // 185
      }                                                                                                        // 186
    }                                                                                                          // 188
                                                                                                               //
    return 0;                                                                                                  // 190
  }                                                                                                            // 191
                                                                                                               //
  function getHueRange(colorInput) {                                                                           // 193
    if (typeof parseInt(colorInput) === 'number') {                                                            // 195
      var number = parseInt(colorInput);                                                                       // 197
                                                                                                               //
      if (number < 360 && number > 0) {                                                                        // 199
        return [number, number];                                                                               // 200
      }                                                                                                        // 201
    }                                                                                                          // 203
                                                                                                               //
    if (typeof colorInput === 'string') {                                                                      // 205
      if (colorDictionary[colorInput]) {                                                                       // 207
        var color = colorDictionary[colorInput];                                                               // 208
                                                                                                               //
        if (color.hueRange) {                                                                                  // 209
          return color.hueRange;                                                                               // 209
        }                                                                                                      // 209
      }                                                                                                        // 210
    }                                                                                                          // 211
                                                                                                               //
    return [0, 360];                                                                                           // 213
  }                                                                                                            // 215
                                                                                                               //
  function getSaturationRange(hue) {                                                                           // 217
    return getColorInfo(hue).saturationRange;                                                                  // 218
  }                                                                                                            // 219
                                                                                                               //
  function getColorInfo(hue) {                                                                                 // 221
    // Maps red colors to make picking hue easier                                                              // 223
    if (hue >= 334 && hue <= 360) {                                                                            // 224
      hue -= 360;                                                                                              // 225
    }                                                                                                          // 226
                                                                                                               //
    for (var colorName in meteorBabelHelpers.sanitizeForInObject(colorDictionary)) {                           // 228
      var color = colorDictionary[colorName];                                                                  // 229
                                                                                                               //
      if (color.hueRange && hue >= color.hueRange[0] && hue <= color.hueRange[1]) {                            // 230
        return colorDictionary[colorName];                                                                     // 233
      }                                                                                                        // 234
    }                                                                                                          // 235
                                                                                                               //
    return 'Color not found';                                                                                  // 235
  }                                                                                                            // 236
                                                                                                               //
  function randomWithin(range) {                                                                               // 238
    return Math.floor(range[0] + Math.random() * (range[1] + 1 - range[0]));                                   // 239
  }                                                                                                            // 240
                                                                                                               //
  function HSVtoHex(hsv) {                                                                                     // 242
    var rgb = HSVtoRGB(hsv);                                                                                   // 244
                                                                                                               //
    function componentToHex(c) {                                                                               // 246
      var hex = c.toString(16);                                                                                // 247
      return hex.length == 1 ? "0" + hex : hex;                                                                // 248
    }                                                                                                          // 249
                                                                                                               //
    var hex = "#" + componentToHex(rgb[0]) + componentToHex(rgb[1]) + componentToHex(rgb[2]);                  // 251
    return hex;                                                                                                // 253
  }                                                                                                            // 255
                                                                                                               //
  function defineColor(name, hueRange, lowerBounds) {                                                          // 257
    var sMin = lowerBounds[0][0],                                                                              // 259
        sMax = lowerBounds[lowerBounds.length - 1][0],                                                         // 259
        bMin = lowerBounds[lowerBounds.length - 1][1],                                                         // 259
        bMax = lowerBounds[0][1];                                                                              // 259
    colorDictionary[name] = {                                                                                  // 265
      hueRange: hueRange,                                                                                      // 266
      lowerBounds: lowerBounds,                                                                                // 267
      saturationRange: [sMin, sMax],                                                                           // 268
      brightnessRange: [bMin, bMax]                                                                            // 269
    };                                                                                                         // 265
  }                                                                                                            // 272
                                                                                                               //
  function loadColorBounds() {                                                                                 // 274
    defineColor('monochrome', null, [[0, 0], [100, 0]]);                                                       // 276
    defineColor('red', [-26, 18], [[20, 100], [30, 92], [40, 89], [50, 85], [60, 78], [70, 70], [80, 60], [90, 55], [100, 50]]);
    defineColor('orange', [19, 46], [[20, 100], [30, 93], [40, 88], [50, 86], [60, 85], [70, 70], [100, 70]]);
    defineColor('yellow', [47, 62], [[25, 100], [40, 94], [50, 89], [60, 86], [70, 84], [80, 82], [90, 80], [100, 75]]);
    defineColor('green', [63, 178], [[30, 100], [40, 90], [50, 85], [60, 81], [70, 74], [80, 64], [90, 50], [100, 40]]);
    defineColor('blue', [179, 257], [[20, 100], [30, 86], [40, 80], [50, 74], [60, 60], [70, 52], [80, 44], [90, 39], [100, 35]]);
    defineColor('purple', [258, 282], [[20, 100], [30, 87], [40, 79], [50, 70], [60, 65], [70, 59], [80, 52], [90, 45], [100, 42]]);
    defineColor('pink', [283, 334], [[20, 100], [30, 90], [40, 86], [60, 84], [80, 80], [90, 75], [100, 73]]);
  }                                                                                                            // 324
                                                                                                               //
  function HSVtoRGB(hsv) {                                                                                     // 326
    // this doesn't work for the values of 0 and 360                                                           // 328
    // here's the hacky fix                                                                                    // 329
    var h = hsv[0];                                                                                            // 330
                                                                                                               //
    if (h === 0) {                                                                                             // 331
      h = 1;                                                                                                   // 331
    }                                                                                                          // 331
                                                                                                               //
    if (h === 360) {                                                                                           // 332
      h = 359;                                                                                                 // 332
    } // Rebase the h,s,v values                                                                               // 332
                                                                                                               //
                                                                                                               //
    h = h / 360;                                                                                               // 335
    var s = hsv[1] / 100,                                                                                      // 336
        v = hsv[2] / 100;                                                                                      // 336
    var h_i = Math.floor(h * 6),                                                                               // 339
        f = h * 6 - h_i,                                                                                       // 339
        p = v * (1 - s),                                                                                       // 339
        q = v * (1 - f * s),                                                                                   // 339
        t = v * (1 - (1 - f) * s),                                                                             // 339
        r = 256,                                                                                               // 339
        g = 256,                                                                                               // 339
        b = 256;                                                                                               // 339
                                                                                                               //
    switch (h_i) {                                                                                             // 348
      case 0:                                                                                                  // 349
        r = v, g = t, b = p;                                                                                   // 349
        break;                                                                                                 // 349
                                                                                                               //
      case 1:                                                                                                  // 350
        r = q, g = v, b = p;                                                                                   // 350
        break;                                                                                                 // 350
                                                                                                               //
      case 2:                                                                                                  // 351
        r = p, g = v, b = t;                                                                                   // 351
        break;                                                                                                 // 351
                                                                                                               //
      case 3:                                                                                                  // 352
        r = p, g = q, b = v;                                                                                   // 352
        break;                                                                                                 // 352
                                                                                                               //
      case 4:                                                                                                  // 353
        r = t, g = p, b = v;                                                                                   // 353
        break;                                                                                                 // 353
                                                                                                               //
      case 5:                                                                                                  // 354
        r = v, g = p, b = q;                                                                                   // 354
        break;                                                                                                 // 354
    }                                                                                                          // 348
                                                                                                               //
    var result = [Math.floor(r * 255), Math.floor(g * 255), Math.floor(b * 255)];                              // 356
    return result;                                                                                             // 357
  }                                                                                                            // 358
                                                                                                               //
  function HSVtoHSL(hsv) {                                                                                     // 360
    var h = hsv[0],                                                                                            // 361
        s = hsv[1] / 100,                                                                                      // 361
        v = hsv[2] / 100,                                                                                      // 361
        k = (2 - s) * v;                                                                                       // 361
    return [h, Math.round(s * v / (k < 1 ? k : 2 - k) * 10000) / 100, k / 2 * 100];                            // 366
  }                                                                                                            // 371
                                                                                                               //
  return randomColor;                                                                                          // 373
});                                                                                                            // 374
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/routes.js                                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
FlowRouter.route('/', {                                                                                        // 1
	name: 'home-about',                                                                                           // 2
	action: function () {                                                                                         // 3
		BlazeLayout.render('MainLayout', {                                                                           // 4
			main: 'About'                                                                                               // 4
		});                                                                                                          // 4
	}                                                                                                             // 5
});                                                                                                            // 1
FlowRouter.route('/new-project', {                                                                             // 8
	name: 'new-project',                                                                                          // 9
	action: function () {                                                                                         // 10
		console.log(Meteor.user());                                                                                  // 11
                                                                                                               //
		if (!Meteor.userId()) {                                                                                      // 12
			FlowRouter.go('home-about');                                                                                // 13
		} else {                                                                                                     // 14
			BlazeLayout.render('MainLayout', {                                                                          // 15
				main: 'NewProject'                                                                                         // 15
			});                                                                                                         // 15
		}                                                                                                            // 16
	}                                                                                                             // 17
});                                                                                                            // 8
FlowRouter.route('/login', {                                                                                   // 20
	name: 'login',                                                                                                // 21
	action: function () {                                                                                         // 22
		BlazeLayout.render('MainLayout', {                                                                           // 23
			main: 'Login'                                                                                               // 23
		});                                                                                                          // 23
	}                                                                                                             // 24
});                                                                                                            // 20
FlowRouter.route('/contact', {                                                                                 // 27
	name: 'contact',                                                                                              // 28
	action: function () {                                                                                         // 29
		BlazeLayout.render('MainLayout', {                                                                           // 30
			main: 'Contact'                                                                                             // 30
		});                                                                                                          // 30
	}                                                                                                             // 31
});                                                                                                            // 27
FlowRouter.route('/image-upload', {                                                                            // 34
	name: 'image-upload',                                                                                         // 35
	action: function () {                                                                                         // 36
		BlazeLayout.render('MainLayout', {                                                                           // 37
			main: 'ImageUpload'                                                                                         // 37
		});                                                                                                          // 37
	}                                                                                                             // 38
});                                                                                                            // 34
FlowRouter.route('/project/:id', {                                                                             // 41
	name: 'project',                                                                                              // 42
	action: function () {                                                                                         // 43
		BlazeLayout.render('MainLayout', {                                                                           // 44
			main: 'Project'                                                                                             // 44
		});                                                                                                          // 44
	}                                                                                                             // 45
});                                                                                                            // 41
var adminRoutes = FlowRouter.group({                                                                           // 48
	prefix: '/admin',                                                                                             // 49
	name: 'admin'                                                                                                 // 50
});                                                                                                            // 48
adminRoutes.route('/dashboard', {                                                                              // 53
	name: 'dashboard',                                                                                            // 54
	action: function () {                                                                                         // 55
		BlazeLayout.render('MainLayout', {                                                                           // 56
			main: 'Dashboard'                                                                                           // 56
		});                                                                                                          // 56
	}                                                                                                             // 57
});                                                                                                            // 53
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Newsletters.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/Newsletters.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Newsletters = new Mongo.Collection('newsletters');                                                             // 1
NewsletterSchema = new SimpleSchema({                                                                          // 3
	email: {                                                                                                      // 4
		type: String,                                                                                                // 5
		label: "Email"                                                                                               // 6
	}                                                                                                             // 4
});                                                                                                            // 3
Meteor.methods({                                                                                               // 10
	insertEmail: function (email) {                                                                               // 11
		Newsletters.insert({                                                                                         // 12
			email: email                                                                                                // 12
		});                                                                                                          // 12
	}                                                                                                             // 13
});                                                                                                            // 10
Newsletters.attachSchema(NewsletterSchema);                                                                    // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Projects.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/Projects.js                                                                                     //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Images = new FilesCollection({                                                                                 // 1
	collectionName: 'Images',                                                                                     // 2
	storagePath: '../images',                                                                                     // 3
	allowClientCode: true,                                                                                        // 4
	// Required to let you remove uploaded file                                                                   // 4
	permissions: 0774,                                                                                            // 5
	parentDirPermissions: 0774,                                                                                   // 6
	onBeforeRemove: function (cursor) {                                                                           // 7
		if (this.userId) {                                                                                           // 8
			var user = this.user();                                                                                     // 9
                                                                                                               //
			if (Roles.userIsInRole(user, 'admin')) {                                                                    // 10
				var imgId = cursor._selector;                                                                              // 12
				var project = Projects.findOne({                                                                           // 13
					pictures: {                                                                                               // 13
						$in: [imgId]                                                                                             // 13
					}                                                                                                         // 13
				});                                                                                                        // 13
				var p_id = project._id;                                                                                    // 14
				Projects.update({                                                                                          // 15
					"_id": p_id                                                                                               // 15
				}, {                                                                                                       // 15
					"$pull": {                                                                                                // 15
						"pictures": imgId                                                                                        // 15
					}                                                                                                         // 15
				});                                                                                                        // 15
				return true;                                                                                               // 16
			}                                                                                                           // 18
		}                                                                                                            // 19
                                                                                                               //
		return false;                                                                                                // 20
	}                                                                                                             // 21
});                                                                                                            // 1
Projects = new Mongo.Collection('projects');                                                                   // 24
Projects.allow({                                                                                               // 26
	// who is allowed to insert into this recipes function                                                        // 27
	// if user Id exists                                                                                          // 28
	insert: function (userId, doc) {                                                                              // 29
		return !!userId;                                                                                             // 30
	},                                                                                                            // 31
	update: function (userId, doc) {                                                                              // 32
		return !!userId;                                                                                             // 33
	}                                                                                                             // 34
});                                                                                                            // 26
ProjectSchema = new SimpleSchema({                                                                             // 37
	name: {                                                                                                       // 38
		type: String,                                                                                                // 39
		label: "Name"                                                                                                // 40
	},                                                                                                            // 38
	desc: {                                                                                                       // 42
		type: String,                                                                                                // 43
		label: "Description",                                                                                        // 44
		autoform: {                                                                                                  // 45
			rows: 5                                                                                                     // 46
		}                                                                                                            // 45
	},                                                                                                            // 42
	author: {                                                                                                     // 49
		type: String,                                                                                                // 50
		label: "Author",                                                                                             // 51
		autoValue: function () {                                                                                     // 52
			return this.userId;                                                                                         // 53
		},                                                                                                           // 54
		autoform: {                                                                                                  // 55
			type: "hidden"                                                                                              // 56
		}                                                                                                            // 55
	},                                                                                                            // 49
	pictures: {                                                                                                   // 59
		type: [String],                                                                                              // 60
		label: 'Add Pictures'                                                                                        // 61
	},                                                                                                            // 59
	"pictures.$": {                                                                                               // 63
		autoform: {                                                                                                  // 64
			afFieldInput: {                                                                                             // 65
				type: 'fileUpload',                                                                                        // 66
				collection: 'Images'                                                                                       // 67
			}                                                                                                           // 65
		}                                                                                                            // 64
	}                                                                                                             // 63
});                                                                                                            // 37
Meteor.methods({                                                                                               // 73
	deleteProject: function (id) {                                                                                // 74
		Projects.remove(id);                                                                                         // 75
	},                                                                                                            // 76
	deleteImage: function (id) {                                                                                  // 77
		Images.remove(id);                                                                                           // 78
	}                                                                                                             // 79
});                                                                                                            // 73
Projects.attachSchema(ProjectSchema);                                                                          // 83
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"Accounts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/Accounts.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var postSignUp = function (userId, info) {                                                                     // 1
	if (info.email === "annalublina@gmail.com") {                                                                 // 2
		Roles.addUsersToRoles(userId, 'admin');                                                                      // 3
	}                                                                                                             // 4
                                                                                                               //
	if (info.profile.emailList === true) {                                                                        // 5
		Roles.addUsersToRoles(userId, 'emailList');                                                                  // 6
	}                                                                                                             // 7
                                                                                                               //
	FlowRouter.go('/');                                                                                           // 8
};                                                                                                             // 9
                                                                                                               //
AccountsTemplates.configure({                                                                                  // 11
	postSignUpHook: postSignUp                                                                                    // 12
});                                                                                                            // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/init.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.startup(function () {});                                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/publish.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.publish('projects', function () {                                                                       // 1
	return Projects.find();                                                                                       // 2
});                                                                                                            // 3
Meteor.publish('project', function (id) {                                                                      // 4
	check(id, String);                                                                                            // 5
	return Projects.find({                                                                                        // 6
		_id: id                                                                                                      // 6
	});                                                                                                           // 6
});                                                                                                            // 7
Meteor.publish('files.images.all', function () {                                                               // 8
	return Images.collection.find({});                                                                            // 9
});                                                                                                            // 10
Meteor.publish('allUsers', function () {                                                                       // 11
	if (Roles.userIsInRole(this.userId, 'admin')) {                                                               // 13
		return Meteor.users.find({});                                                                                // 14
	}                                                                                                             // 15
});                                                                                                            // 17
Meteor.publish('newsletters', function () {                                                                    // 18
	return Newsletters.find({});                                                                                  // 19
});                                                                                                            // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// mup.js                                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.exports = {                                                                                             // 1
  servers: {                                                                                                   // 2
    one: {                                                                                                     // 3
      // TODO: set host address, username, and authentication method                                           // 4
      host: '138.197.101.26',                                                                                  // 5
      username: 'root',                                                                                        // 6
      // pem: './path/to/pem'                                                                                  // 7
      password: 'Bubblechick1' // or neither for authenticate from ssh-agent                                   // 8
                                                                                                               //
    }                                                                                                          // 3
  },                                                                                                           // 2
  meteor: {                                                                                                    // 13
    // TODO: change app name and path                                                                          // 14
    name: 'AnnaLublina',                                                                                       // 15
    path: '.',                                                                                                 // 16
    volumes: {                                                                                                 // 17
      '/images': '/images'                                                                                     // 18
    },                                                                                                         // 17
    servers: {                                                                                                 // 21
      one: {}                                                                                                  // 22
    },                                                                                                         // 21
    buildOptions: {                                                                                            // 25
      serverOnly: true                                                                                         // 26
    },                                                                                                         // 25
    env: {                                                                                                     // 28
      // TODO: Change to your app's url                                                                        // 29
      // If you are using ssl, it needs to start with https://                                                 // 30
      ROOT_URL: 'http://138.197.101.26',                                                                       // 31
      MONGO_URL: 'mongodb://localhost/meteor'                                                                  // 32
    },                                                                                                         // 28
    docker: {                                                                                                  // 35
      // change to 'kadirahq/meteord' if your app is not using Meteor 1.4                                      // 36
      image: 'abernix/meteord:base'                                                                            // 37
    },                                                                                                         // 35
    // This is the maximum time in seconds it will wait                                                        // 41
    // for your app to start                                                                                   // 42
    // Add 30 seconds if the server has 512mb of ram                                                           // 43
    // And 30 more if you have binary npm dependencies.                                                        // 44
    deployCheckWaitTime: 120,                                                                                  // 45
    // Show progress bar while uploading bundle to server                                                      // 47
    // You might need to disable it on CI servers                                                              // 48
    enableUploadProgressBar: false                                                                             // 49
  },                                                                                                           // 13
  mongo: {                                                                                                     // 52
    port: 27017,                                                                                               // 53
    version: '3.4.1',                                                                                          // 54
    servers: {                                                                                                 // 55
      one: {}                                                                                                  // 56
    }                                                                                                          // 55
  }                                                                                                            // 52
};                                                                                                             // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./lib/random.js");
require("./lib/routes.js");
require("./collections/Newsletters.js");
require("./collections/Projects.js");
require("./server/Accounts.js");
require("./server/init.js");
require("./server/publish.js");
require("./mup.js");
//# sourceMappingURL=app.js.map
