(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matb33:bootstrap-glyphicons'] = {};

})();
