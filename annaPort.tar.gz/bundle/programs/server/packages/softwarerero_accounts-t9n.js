(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, T9n;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n.coffee.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  if (Meteor.isClient) {                                                                                               // 2
    return typeof Template !== "undefined" && Template !== null ? Template.registerHelper('t9n', function (x, params) {
      return T9n.get(x, true, params.hash);                                                                            // 6
    }) : void 0;                                                                                                       // 3
  }                                                                                                                    // 8
});                                                                                                                    // 1
                                                                                                                       //
T9n = function () {                                                                                                    // 7
  function T9n() {}                                                                                                    // 12
                                                                                                                       //
  T9n.maps = {};                                                                                                       // 9
  T9n.defaultLanguage = 'en';                                                                                          // 10
  T9n.language = '';                                                                                                   // 11
  T9n.dep = new Deps.Dependency();                                                                                     // 12
  T9n.depLanguage = new Deps.Dependency();                                                                             // 13
  T9n.missingPrefix = ">";                                                                                             // 14
  T9n.missingPostfix = "<";                                                                                            // 15
                                                                                                                       //
  T9n.map = function (language, map) {                                                                                 // 17
    if (!this.maps[language]) {                                                                                        // 18
      this.maps[language] = {};                                                                                        // 19
    }                                                                                                                  // 31
                                                                                                                       //
    this.registerMap(language, '', false, map);                                                                        // 20
    return this.dep.changed();                                                                                         // 33
  };                                                                                                                   // 17
                                                                                                                       //
  T9n.get = function (label, markIfMissing, args, language) {                                                          // 23
    var index, parent, ref, ref1, ret;                                                                                 // 24
                                                                                                                       //
    if (markIfMissing == null) {                                                                                       // 38
      markIfMissing = true;                                                                                            // 23
    }                                                                                                                  // 40
                                                                                                                       //
    if (args == null) {                                                                                                // 41
      args = {};                                                                                                       // 23
    }                                                                                                                  // 43
                                                                                                                       //
    this.dep.depend();                                                                                                 // 24
    this.depLanguage.depend();                                                                                         // 25
                                                                                                                       //
    if (typeof label !== 'string') {                                                                                   // 26
      return '';                                                                                                       // 26
    }                                                                                                                  // 48
                                                                                                                       //
    if (language == null) {                                                                                            // 49
      language = this.language;                                                                                        // 27
    }                                                                                                                  // 51
                                                                                                                       //
    ret = (ref = this.maps[language]) != null ? ref[label] : void 0;                                                   // 28
                                                                                                                       //
    if (!ret) {                                                                                                        // 29
      index = language.lastIndexOf('_');                                                                               // 30
                                                                                                                       //
      if (index) {                                                                                                     // 31
        parent = language.substring(0, index);                                                                         // 32
                                                                                                                       //
        if (parent) {                                                                                                  // 33
          return this.get(label, markIfMissing, args, parent);                                                         // 34
        }                                                                                                              // 31
      }                                                                                                                // 29
    }                                                                                                                  // 61
                                                                                                                       //
    if (!ret) {                                                                                                        // 35
      ret = (ref1 = this.maps[this.defaultLanguage]) != null ? ref1[label] : void 0;                                   // 36
    }                                                                                                                  // 64
                                                                                                                       //
    if (!ret) {                                                                                                        // 37
      if (markIfMissing) {                                                                                             // 38
        return this.missingPrefix + label + this.missingPostfix;                                                       // 67
      } else {                                                                                                         // 38
        return label;                                                                                                  // 69
      }                                                                                                                // 37
    }                                                                                                                  // 71
                                                                                                                       //
    if (Object.keys(args).length === 0) {                                                                              // 39
      return ret;                                                                                                      // 73
    } else {                                                                                                           // 39
      return this.replaceParams(ret, args);                                                                            // 75
    }                                                                                                                  // 76
  };                                                                                                                   // 23
                                                                                                                       //
  T9n.registerMap = function (language, prefix, dot, map) {                                                            // 41
    var key, results, value;                                                                                           // 42
                                                                                                                       //
    if (typeof map === 'string') {                                                                                     // 42
      return this.maps[language][prefix] = map;                                                                        // 82
    } else if ((typeof map === "undefined" ? "undefined" : _typeof(map)) === 'object') {                               // 42
      if (dot) {                                                                                                       // 45
        prefix = prefix + '.';                                                                                         // 46
      }                                                                                                                // 86
                                                                                                                       //
      results = [];                                                                                                    // 47
                                                                                                                       //
      for (key in meteorBabelHelpers.sanitizeForInObject(map)) {                                                       // 88
        value = map[key];                                                                                              // 89
        results.push(this.registerMap(language, prefix + key, true, value));                                           // 90
      }                                                                                                                // 47
                                                                                                                       //
      return results;                                                                                                  // 92
    }                                                                                                                  // 93
  };                                                                                                                   // 41
                                                                                                                       //
  T9n.getLanguage = function () {                                                                                      // 50
    this.depLanguage.depend();                                                                                         // 51
    return this.language;                                                                                              // 52
  };                                                                                                                   // 50
                                                                                                                       //
  T9n.getLanguages = function () {                                                                                     // 54
    this.dep.depend();                                                                                                 // 55
    return Object.keys(this.maps).sort();                                                                              // 56
  };                                                                                                                   // 54
                                                                                                                       //
  T9n.getLanguageInfo = function () {                                                                                  // 58
    var i, k, keys, len, results;                                                                                      // 59
    this.dep.depend();                                                                                                 // 59
    keys = Object.keys(this.maps).sort();                                                                              // 60
    results = [];                                                                                                      // 61
                                                                                                                       //
    for (i = 0, len = keys.length; i < len; i++) {                                                                     // 111
      k = keys[i];                                                                                                     // 112
      results.push({                                                                                                   // 113
        name: this.maps[k]['t9Name'],                                                                                  // 62
        code: k                                                                                                        // 62
      });                                                                                                              // 62
    }                                                                                                                  // 61
                                                                                                                       //
    return results;                                                                                                    // 118
  };                                                                                                                   // 58
                                                                                                                       //
  T9n.setLanguage = function (language) {                                                                              // 64
    if (this.language === language) {                                                                                  // 65
      return;                                                                                                          // 65
    }                                                                                                                  // 124
                                                                                                                       //
    language = language.replace(new RegExp('-', 'g'), '_');                                                            // 66
                                                                                                                       //
    if (!this.maps[language]) {                                                                                        // 67
      if (language.indexOf('_') > 1) {                                                                                 // 68
        return this.setLanguage(language.substring(0, language.lastIndexOf('_')));                                     // 128
      } else {                                                                                                         // 68
        throw Error("language " + language + " does not exist");                                                       // 71
      }                                                                                                                // 67
    }                                                                                                                  // 132
                                                                                                                       //
    this.language = language;                                                                                          // 72
    return this.depLanguage.changed();                                                                                 // 134
  };                                                                                                                   // 64
                                                                                                                       //
  T9n.replaceParams = function (str, args) {                                                                           // 75
    var key, re, value;                                                                                                // 76
                                                                                                                       //
    for (key in meteorBabelHelpers.sanitizeForInObject(args)) {                                                        // 76
      value = args[key];                                                                                               // 140
      re = new RegExp("@{" + key + "}", 'g');                                                                          // 77
      str = str.replace(re, value);                                                                                    // 78
    }                                                                                                                  // 76
                                                                                                                       //
    return str;                                                                                                        // 144
  };                                                                                                                   // 75
                                                                                                                       //
  return T9n;                                                                                                          // 147
}();                                                                                                                   // 149
                                                                                                                       //
this.T9n = T9n;                                                                                                        // 82
                                                                                                                       //
this.t9n = function (x, includePrefix, params) {                                                                       // 83
  return T9n.get(x);                                                                                                   // 154
};                                                                                                                     // 83
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ar.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ar;                                                                                                                // 4
ar = {                                                                                                                 // 4
  add: "اضف",                                                                                                          // 6
  and: "و",                                                                                                            // 7
  back: "رجوع",                                                                                                        // 8
  changePassword: "غير كلمة السر",                                                                                     // 9
  choosePassword: "اختر كلمة السر",                                                                                    // 10
  clickAgree: "بفتح حسابك انت توافق على",                                                                              // 11
  configure: "تعديل",                                                                                                  // 12
  createAccount: "افتح حساب جديد",                                                                                     // 13
  currentPassword: "كلمة السر الحالية",                                                                                // 14
  dontHaveAnAccount: "ليس عندك حساب؟",                                                                                 // 15
  email: "البريد الالكترونى",                                                                                          // 16
  emailAddress: "البريد الالكترونى",                                                                                   // 17
  emailResetLink: "اعادة تعيين البريد الالكترونى",                                                                     // 18
  forgotPassword: "نسيت كلمة السر؟",                                                                                   // 19
  ifYouAlreadyHaveAnAccount: "اذا كان عندك حساب",                                                                      // 20
  newPassword: "كلمة السر الجديدة",                                                                                    // 21
  newPasswordAgain: "كلمة السر الجديدة مرة اخرى",                                                                      // 22
  optional: "اختيارى",                                                                                                 // 23
  OR: "او",                                                                                                            // 24
  password: "كلمة السر",                                                                                               // 25
  passwordAgain: "كلمة السر مرة اخرى",                                                                                 // 26
  privacyPolicy: "سياسة الخصوصية",                                                                                     // 27
  remove: "ازالة",                                                                                                     // 28
  resetYourPassword: "اعادة تعيين كلمة السر",                                                                          // 29
  setPassword: "تعيين كلمة السر",                                                                                      // 30
  sign: "تسجيل",                                                                                                       // 31
  signIn: "تسجيل الدخول",                                                                                              // 32
  signin: "تسجيل الدخول",                                                                                              // 33
  signOut: "تسجيل الخروج",                                                                                             // 34
  signUp: "افتح حساب جديد",                                                                                            // 35
  signupCode: "رمز التسجيل",                                                                                           // 36
  signUpWithYourEmailAddress: "سجل ببريدك الالكترونى",                                                                 // 37
  terms: "شروط الاستخدام",                                                                                             // 38
  updateYourPassword: "جدد كلمة السر",                                                                                 // 39
  username: "اسم المستخدم",                                                                                            // 40
  usernameOrEmail: "اسم المستخدم او البريد الالكترونى",                                                                // 41
  "with": "مع",                                                                                                        // 42
  info: {                                                                                                              // 45
    emailSent: "تم ارسال البريد الالكترونى",                                                                           // 46
    emailVerified: "تم تأكيد البريد الالكترونى",                                                                       // 47
    passwordChanged: "تم تغيير كلمة السر",                                                                             // 48
    passwordReset: "تم اعادة تعيين كلمة السر"                                                                          // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "البريد الالكترونى مطلوب",                                                                          // 53
    minChar: "سبعة حروف هو الحد الادنى لكلمة السر",                                                                    // 54
    pwdsDontMatch: "كلمتين السر لا يتطابقان",                                                                          // 55
    pwOneDigit: "كلمة السر يجب ان تحتوى على رقم واحد على الاقل",                                                       // 56
    pwOneLetter: "كلمة السر تحتاج الى حرف اخر",                                                                        // 57
    signInRequired: "عليك بتسجبل الدخول لفعل ذلك",                                                                     // 58
    signupCodeIncorrect: "رمز التسجيل غير صحيح",                                                                       // 59
    signupCodeRequired: "رمز التسجيل مطلوب",                                                                           // 60
    usernameIsEmail: "اسم المستخدم لا يمكن ان يكون بريد الكترونى",                                                     // 61
    usernameRequired: "اسم المستخدم مطلوب",                                                                            // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "البريد الالكترونى مسجل",                                                               // 70
      "Email doesn't match the criteria.": "البريد الالكترونى لا يتوافق مع الشروط",                                    // 71
      "Invalid login token": "رمز الدخول غير صالح",                                                                    // 72
      "Login forbidden": "تسجيل الدخول غير مسموح",                                                                     // 73
      "Service unknown": "خدمة غير معروفة",                                                                            // 75
      "Unrecognized options for login request": "اختيارات غير معلومة عند تسجيل الدخول",                                // 76
      "User validation failed": "تأكيد المستخدم فشل",                                                                  // 77
      "Username already exists.": "اسم المستخدم مسجل",                                                                 // 78
      "You are not logged in.": "لم تسجل دخولك",                                                                       // 79
      "You've been logged out by the server. Please log in again.": "لقد تم تسجيل خروجك من قبل الخادم. قم بتسجيل الدخول مجددا.",
      "Your session has expired. Please log in again.": "لقد انتهت جلستك. قم بتسجيل الدخول مجددا.",                    // 81
      "No matching login attempt found": "لم نجد محاولة دخول مطابقة",                                                  // 85
      "Password is old. Please reset your password.": "كلمة السر قديمة. قم باعادة تعيين كلمة السر.",                   // 89
      "Incorrect password": "كلمة السر غير صحيحة.",                                                                    // 93
      "Invalid email": "البريد الالكترونى غير صالح",                                                                   // 94
      "Must be logged in": "يجب ان تسجل دخولك",                                                                        // 95
      "Need to set a username or email": "يجب تعيين اسم مستخدم او بريد الكترونى",                                      // 96
      "old password format": "صيغة كلمة السر القديمة",                                                                 // 97
      "Password may not be empty": "كلمة السر لا يمكن ان تترك فارغة",                                                  // 98
      "Signups forbidden": "فتح الحسابات غير مسموح",                                                                   // 99
      "Token expired": "انتهى زمن الرمز",                                                                              // 100
      "Token has invalid email address": "الرمز يحتوى على بريد الكترونى غير صالح",                                     // 101
      "User has no password set": "المستخدم لم يقم بتعيين كلمة سر",                                                    // 102
      "User not found": "اسم المستخدم غير موجود",                                                                      // 103
      "Verify email link expired": "انتهى زمن رابط تأكيد البريد الالكترونى",                                           // 104
      "Verify email link is for unknown address": "رابط تأكيد البريد الالكترونى ينتمى الى بريد الكترونى غير معروف",    // 105
      "Match failed": "المطابقة فشلت",                                                                                 // 108
      "Unknown error": "خطأ غير معروف"                                                                                 // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("ar", ar);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ca.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ca;                                                                                                                // 4
ca = {                                                                                                                 // 4
  t9Name: 'Català',                                                                                                    // 6
  add: "afegir",                                                                                                       // 8
  and: "i",                                                                                                            // 9
  back: "enrere",                                                                                                      // 10
  changePassword: "Canviar contrasenya",                                                                               // 11
  choosePassword: "Escollir contrasenya",                                                                              // 12
  clickAgree: "Al fer clic a Subscriure aproves la",                                                                   // 13
  configure: "Disposició",                                                                                             // 14
  createAccount: "Crear compte",                                                                                       // 15
  currentPassword: "Contrasenya actual",                                                                               // 16
  dontHaveAnAccount: "No tens compte?",                                                                                // 17
  email: "Correu",                                                                                                     // 18
  emailAddress: "Adreça de correu",                                                                                    // 19
  emailResetLink: "Restablir correu",                                                                                  // 20
  forgotPassword: "Has oblidat la contrasenya?",                                                                       // 21
  ifYouAlreadyHaveAnAccount: "Si ja tens un compte",                                                                   // 22
  newPassword: "Nova contrasenya",                                                                                     // 23
  newPasswordAgain: "Nova contrasenya (repetir)",                                                                      // 24
  optional: "Opcional",                                                                                                // 25
  OR: "O",                                                                                                             // 26
  password: "Contrasenya",                                                                                             // 27
  passwordAgain: "Contrasenya (repetir)",                                                                              // 28
  privacyPolicy: "Política de Privacitat",                                                                             // 29
  remove: "eliminar",                                                                                                  // 30
  resetYourPassword: "Restablir la teva contrasenya",                                                                  // 31
  setPassword: "Definir contrasenya",                                                                                  // 32
  sign: "Entra",                                                                                                       // 33
  signIn: "Entra",                                                                                                     // 34
  signin: "entra",                                                                                                     // 35
  signOut: "Surt",                                                                                                     // 36
  signUp: "Subscriure's",                                                                                              // 37
  signupCode: "Còdi de subscripció",                                                                                   // 38
  signUpWithYourEmailAddress: "Subscriure-te amb el correu",                                                           // 39
  terms: "Termes d'ús",                                                                                                // 40
  updateYourPassword: "Actualitzar la teva contrasenya",                                                               // 41
  username: "Usuari",                                                                                                  // 42
  usernameOrEmail: "Usuari o correu",                                                                                  // 43
  "with": "amb",                                                                                                       // 44
  maxAllowedLength: "Longitud màxima permesa",                                                                         // 45
  minRequiredLength: "Longitud mínima requerida",                                                                      // 46
  resendVerificationEmail: "Envia el correu de nou",                                                                   // 47
  resendVerificationEmailLink_pre: "Correu de verificació perdut?",                                                    // 48
  resendVerificationEmailLink_link: "Envia de nou",                                                                    // 49
  info: {                                                                                                              // 51
    emailSent: "Correu enviat",                                                                                        // 52
    emailVerified: "Correu verificat",                                                                                 // 53
    passwordChanged: "Contrasenya canviada",                                                                           // 54
    passwordReset: "Restablir contrasenya"                                                                             // 55
  },                                                                                                                   // 52
  error: {                                                                                                             // 57
    emailRequired: "Es requereix el correu.",                                                                          // 58
    minChar: "7 caràcters mínim.",                                                                                     // 59
    pwdsDontMatch: "Les contrasenyes no coincideixen",                                                                 // 60
    pwOneDigit: "mínim un dígit.",                                                                                     // 61
    pwOneLetter: "mínim una lletra.",                                                                                  // 62
    signInRequired: "Has d'iniciar sessió per a fer això.",                                                            // 63
    signupCodeIncorrect: "El còdi de subscripció no coincideix.",                                                      // 64
    signupCodeRequired: "Es requereix el còdi de subscripció.",                                                        // 65
    usernameIsEmail: "L'usuari no pot ser el correu.",                                                                 // 66
    usernameRequired: "Es requereix un usuari.",                                                                       // 67
    accounts: {                                                                                                        // 70
      "Email already exists.": "El correu ja existeix.",                                                               // 75
      "Email doesn't match the criteria.": "El correu no coincideix amb els criteris.",                                // 76
      "Invalid login token": "Token d'entrada invàlid",                                                                // 77
      "Login forbidden": "No es permet entrar en aquests moments",                                                     // 78
      "Service unknown": "Servei desconegut",                                                                          // 80
      "Unrecognized options for login request": "Opcions desconegudes per la petició d'entrada",                       // 81
      "User validation failed": "No s'ha pogut validar l'usuari",                                                      // 82
      "Username already exists.": "L'usuari ja existeix.",                                                             // 83
      "You are not logged in.": "No has iniciat sessió",                                                               // 84
      "You've been logged out by the server. Please log in again.": "Has estat desconnectat pel servidor. Si us plau, entra de nou.",
      "Your session has expired. Please log in again.": "La teva sessió ha expirat. Si us plau, entra de nou.",        // 86
      "Already verified": "Ja està verificat",                                                                         // 87
      "No matching login attempt found": "No s'ha trobat un intent de login vàlid",                                    // 91
      "Password is old. Please reset your password.": "La contrasenya és antiga, si us plau, restableix una contrasenya nova",
      "Incorrect password": "Contrasenya invàlida",                                                                    // 99
      "Invalid email": "Correu invàlid",                                                                               // 100
      "Must be logged in": "Has d'iniciar sessió",                                                                     // 101
      "Need to set a username or email": "Has d'especificar un usuari o un correu",                                    // 102
      "old password format": "Format de contrasenya antic",                                                            // 103
      "Password may not be empty": "La contrasenya no pot ser buida",                                                  // 104
      "Signups forbidden": "Subscripció no permesa en aquest moment",                                                  // 105
      "Token expired": "Token expirat",                                                                                // 106
      "Token has invalid email address": "El token conté un correu invàlid",                                           // 107
      "User has no password set": "Usuari no té contrasenya",                                                          // 108
      "User not found": "Usuari no trobat",                                                                            // 109
      "Verify email link expired": "L'enllaç per a verificar el correu ha expirat",                                    // 110
      "Verify email link is for unknown address": "L'enllaç per a verificar el correu conté una adreça desconeguda",   // 111
      "At least 1 digit, 1 lowercase and 1 uppercase": "Al menys 1 dígit, 1 lletra minúscula i 1 majúscula",           // 112
      "Please verify your email first. Check the email and follow the link!": "Si us plau, verifica el teu correu primer. Comprova el correu i segueix l'enllaç que conté!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Un nou correu ha estat enviat a la teva bústia. Si no reps el correu assegura't de comprovar la bústia de correu no desitjat.",
      "Match failed": "Comprovació fallida",                                                                           // 117
      "Unknown error": "Error desconegut"                                                                              // 120
    }                                                                                                                  // 75
  }                                                                                                                    // 58
};                                                                                                                     // 6
T9n.map("ca", ca);                                                                                                     // 123
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/cs.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var cs;                                                                                                                // 4
cs = {                                                                                                                 // 4
  add: "přidat",                                                                                                       // 6
  and: "a",                                                                                                            // 7
  back: "zpět",                                                                                                        // 8
  changePassword: "Změnte heslo",                                                                                      // 9
  choosePassword: "Zvolte heslo",                                                                                      // 10
  clickAgree: "Stiskem tlačítka Registrovat souhlasíte s",                                                             // 11
  configure: "Nastavit",                                                                                               // 12
  createAccount: "Vytvořit účet",                                                                                      // 13
  currentPassword: "Současné heslo",                                                                                   // 14
  dontHaveAnAccount: "Nemáte účet?",                                                                                   // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Emailová adresa",                                                                                     // 17
  emailResetLink: "Odkaz na reset emailu",                                                                             // 18
  forgotPassword: "Zapomenuté heslo?",                                                                                 // 19
  ifYouAlreadyHaveAnAccount: "Pokud již máte účet",                                                                    // 20
  newPassword: "Nové heslo",                                                                                           // 21
  newPasswordAgain: "Nové heslo (zopakovat)",                                                                          // 22
  optional: "Volitelný",                                                                                               // 23
  OR: "nebo",                                                                                                          // 24
  password: "Heslo",                                                                                                   // 25
  passwordAgain: "Heslo (zopakovat)",                                                                                  // 26
  privacyPolicy: "Nastavení soukromí",                                                                                 // 27
  remove: "odstranit",                                                                                                 // 28
  resetYourPassword: "Resetovat heslo",                                                                                // 29
  setPassword: "Nastavit heslo",                                                                                       // 30
  sign: "Přihlášení",                                                                                                  // 31
  signIn: "Přihlásit se",                                                                                              // 32
  signin: "přihlásit se",                                                                                              // 33
  signOut: "Odhlásit se",                                                                                              // 34
  signUp: "Registrovat",                                                                                               // 35
  signupCode: "Registrační kód",                                                                                       // 36
  signUpWithYourEmailAddress: "Registrovat se emailovou adresou",                                                      // 37
  terms: "Podmínky použití",                                                                                           // 38
  updateYourPassword: "Aktualizujte si své heslo",                                                                     // 39
  username: "Uživatelské jméno",                                                                                       // 40
  usernameOrEmail: "Uživatelské jméno nebo email",                                                                     // 41
  "with": "s",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "Email odeslán",                                                                                        // 46
    emailVerified: "Email ověřen",                                                                                     // 47
    passwordChanged: "Heslo změněno",                                                                                  // 48
    passwordReset: "Heslo resetováno"                                                                                  // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email je povinný.",                                                                                // 53
    minChar: "minimální délka hesla je 7 znaků.",                                                                      // 54
    pwdsDontMatch: "Hesla nesouhlasí",                                                                                 // 55
    pwOneDigit: "Heslo musí obsahovat alespoň jednu číslici.",                                                         // 56
    pwOneLetter: "Heslo musí obsahovat alespoň 1 slovo.",                                                              // 57
    signInRequired: "Musíte být příhlášeni.",                                                                          // 58
    signupCodeIncorrect: "Registrační kód je chybný.",                                                                 // 59
    signupCodeRequired: "Registrační kód je povinný.",                                                                 // 60
    usernameIsEmail: "Uživatelské jméno nemůže být emailová adresa.",                                                  // 61
    usernameRequired: "Uživatelské jméno je povinné."                                                                  // 62
  },                                                                                                                   // 53
  accounts: {                                                                                                          // 65
    "A login handler should return a result or undefined": "Přihlašovací rutina musí vracet výsledek nebo undefined",  // 69
    "Email already exists.": "Email již existuje.",                                                                    // 70
    "Email doesn't match the criteria.": "Email nesplňuje požadavky.",                                                 // 71
    "Invalid login token": "Neplatný přihlašovací token",                                                              // 72
    "Login forbidden": "Přihlášení je zakázáno",                                                                       // 73
    "Service unknown": "Neznámá služba",                                                                               // 75
    "Unrecognized options for login request": "Nerozpoznaná volba přihlašovacího požadavku",                           // 76
    "User validation failed": "Validace uživatele selhala",                                                            // 77
    "Username already exists.": "Uživatelské jméno již existuje.",                                                     // 78
    "You are not logged in.": "Nejste přihlášený.",                                                                    // 79
    "You've been logged out by the server. Please log in again.": "Byl jste odhlášen. Prosím přihlašte se znovu.",     // 80
    "Your session has expired. Please log in again.": "Vaše připojení vypršelo. Prosím přihlašte se znovu.",           // 81
    "No matching login attempt found": "Nenalezen odpovídající způsob přihlášení",                                     // 85
    "Password is old. Please reset your password.": "Heslo je staré. Prosíme nastavte si ho znovu.",                   // 89
    "Incorrect password": "Chybné heslo",                                                                              // 93
    "Invalid email": "Neplatný email",                                                                                 // 94
    "Must be logged in": "Uživatel musí být přihlášen",                                                                // 95
    "Need to set a username or email": "Je třeba zadat uživatelské jméno nebo email",                                  // 96
    "old password format": "starý formát hesla",                                                                       // 97
    "Password may not be empty": "Heslo nemůže být prázdné",                                                           // 98
    "Signups forbidden": "Registrace je zakázaná",                                                                     // 99
    "Token expired": "Token vypršel",                                                                                  // 100
    "Token has invalid email address": "Token má neplatnou emailovou adresu",                                          // 101
    "User has no password set": "Uživatel nemá nastavené heslo",                                                       // 102
    "User not found": "Uživatel nenalezen",                                                                            // 103
    "Verify email link expired": "Odkaz pro ověření emailu vypršel",                                                   // 104
    "Verify email link is for unknown address": "Odkaz pro ověření emailu má neznámou adresu",                         // 105
    "Match failed": "Nesouhlasí",                                                                                      // 108
    "Unknown error": "Neznámá chyba"                                                                                   // 111
  }                                                                                                                    // 69
};                                                                                                                     // 6
T9n.map("cs", cs);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/da.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var da;                                                                                                                // 4
da = {                                                                                                                 // 4
  add: "tilføj",                                                                                                       // 6
  and: "og",                                                                                                           // 7
  back: "tilbage",                                                                                                     // 8
  changePassword: "Skift kodeord",                                                                                     // 9
  choosePassword: "Vælg kodeord",                                                                                      // 10
  clickAgree: "Ved at klikke på tilmeld accepterer du vores",                                                          // 11
  configure: "Konfigurer",                                                                                             // 12
  createAccount: "Opret konto",                                                                                        // 13
  currentPassword: "Nuværende kodeord",                                                                                // 14
  dontHaveAnAccount: "Har du ikke en konto?",                                                                          // 15
  email: "E-mail",                                                                                                     // 16
  emailAddress: "E-mail adresse",                                                                                      // 17
  emailResetLink: "Nulstil E-mail Link",                                                                               // 18
  forgotPassword: "Glemt kodeord?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Hvis jeg allerede har en konto",                                                         // 20
  newPassword: "Nyt kodeord",                                                                                          // 21
  newPasswordAgain: "Nyt kodeord (igen)",                                                                              // 22
  optional: "Frivilligt",                                                                                              // 23
  OR: "eller",                                                                                                         // 24
  password: "Kodeord",                                                                                                 // 25
  passwordAgain: "Kodeord (igen)",                                                                                     // 26
  privacyPolicy: "Privatlivspolitik",                                                                                  // 27
  remove: "fjern",                                                                                                     // 28
  resetYourPassword: "Nulstil dit kodeord",                                                                            // 29
  setPassword: "Sæt kodeord",                                                                                          // 30
  sign: "Log",                                                                                                         // 31
  signIn: "Log ind",                                                                                                   // 32
  signin: "Log ind",                                                                                                   // 33
  signOut: "Log ud",                                                                                                   // 34
  signUp: "Tilmeld",                                                                                                   // 35
  signupCode: "Tilmeldingskode",                                                                                       // 36
  signUpWithYourEmailAddress: "Tilmeld med din e-mail adresse",                                                        // 37
  terms: "Betingelser for brug",                                                                                       // 38
  updateYourPassword: "Skift dit kodeord",                                                                             // 39
  username: "Brugernavn",                                                                                              // 40
  usernameOrEmail: "Brugernavn eller e-mail",                                                                          // 41
  "with": "med",                                                                                                       // 42
  info: {                                                                                                              // 45
    emailSent: "E-mail sendt",                                                                                         // 46
    emailVerified: "Email verificeret",                                                                                // 47
    passwordChanged: "Password ændret",                                                                                // 48
    passwordReset: "Password reset"                                                                                    // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "E-mail er påkrævet.",                                                                              // 53
    minChar: "Kodeordet skal være mindst 7 tegn.",                                                                     // 54
    pwdsDontMatch: "De to kodeord er ikke ens.",                                                                       // 55
    pwOneDigit: "Kodeord kræver mindste et tal.",                                                                      // 56
    pwOneLetter: "Kodeord kræver mindst et bogstav.",                                                                  // 57
    signInRequired: "Du skal være logget ind for at kunne gøre det.",                                                  // 58
    signupCodeIncorrect: "Tilmeldingskode er forkert.",                                                                // 59
    signupCodeRequired: "Tilmeldingskode er påkrævet.",                                                                // 60
    usernameIsEmail: "Brugernavn kan ikke være en e-mail adresse.",                                                    // 61
    usernameRequired: "Brugernavn skal udfyldes.",                                                                     // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "E-mail findes allerede.",                                                              // 70
      "Email doesn't match the criteria.": "E-mail modsvarer ikke kriteriet.",                                         // 71
      "Invalid login token": "Invalid log ind token",                                                                  // 72
      "Login forbidden": "Log ind forbudt",                                                                            // 73
      "Service unknown": "Service ukendt",                                                                             // 75
      "Unrecognized options for login request": "Ukendte options for login forsøg",                                    // 76
      "User validation failed": "Bruger validering fejlede",                                                           // 77
      "Username already exists.": "Brugernavn findes allerede.",                                                       // 78
      "You are not logged in.": "Du er ikke logget ind.",                                                              // 79
      "You've been logged out by the server. Please log in again.": "Du er blevet logget af serveren. Log ind igen.",  // 80
      "Your session has expired. Please log in again.": "Din session er udløbet. Log ind igen.",                       // 81
      "No matching login attempt found": "Der fandtes ingen login forsøg",                                             // 85
      "Password is old. Please reset your password.": "Kodeordet er for gammelt. Du skal resette det.",                // 89
      "Incorrect password": "Forkert kodeord",                                                                         // 93
      "Invalid email": "Invalid e-mail",                                                                               // 94
      "Must be logged in": "Du skal være logget ind",                                                                  // 95
      "Need to set a username or email": "Du skal angive enten brugernavn eller e-mail",                               // 96
      "old password format": "gammelt kodeord format",                                                                 // 97
      "Password may not be empty": "Kodeord skal være udfyldt",                                                        // 98
      "Signups forbidden": "Tilmeldinger forbudt",                                                                     // 99
      "Token expired": "Token udløbet",                                                                                // 100
      "Token has invalid email address": "Token har en invalid e-mail adresse",                                        // 101
      "User has no password set": "Bruger har ikke angivet noget kodeord",                                             // 102
      "User not found": "Bruger ej fundet",                                                                            // 103
      "Verify email link expired": "Verify email link expired",                                                        // 104
      "Verify email link is for unknown address": "Verificer e-mail link for ukendt adresse",                          // 105
      "Match failed": "Match fejlede",                                                                                 // 108
      "Unknown error": "Ukendt fejl"                                                                                   // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("da", da);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/de.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var de;                                                                                                                // 4
de = {                                                                                                                 // 4
  t9Name: 'Deutsch',                                                                                                   // 6
  add: "hinzufügen",                                                                                                   // 8
  and: "und",                                                                                                          // 9
  back: "zurück",                                                                                                      // 10
  changePassword: "Passwort ändern",                                                                                   // 11
  choosePassword: "Passwort auswählen",                                                                                // 12
  clickAgree: "Die Registrierung impliziert die Akzeptanz unserer",                                                    // 13
  configure: "Konfigurieren",                                                                                          // 14
  createAccount: "Konto erstellen",                                                                                    // 15
  currentPassword: "Aktuelles Passwort",                                                                               // 16
  dontHaveAnAccount: "Noch kein Konto?",                                                                               // 17
  email: "E-Mail",                                                                                                     // 18
  emailAddress: "E-Mail Adresse",                                                                                      // 19
  emailResetLink: "Senden",                                                                                            // 20
  forgotPassword: "Passwort vergessen?",                                                                               // 21
  ifYouAlreadyHaveAnAccount: "Falls bereits ein Konto existiert, bitte hier",                                          // 22
  newPassword: "Neues Passwort",                                                                                       // 23
  newPasswordAgain: "Neues Passwort (wiederholen)",                                                                    // 24
  optional: "Optional",                                                                                                // 25
  OR: "ODER",                                                                                                          // 26
  password: "Passwort",                                                                                                // 27
  passwordAgain: "Passwort (wiederholen)",                                                                             // 28
  privacyPolicy: "Datenschutzerklärung",                                                                               // 29
  remove: "entfernen",                                                                                                 // 30
  resetYourPassword: "Passwort zurücksetzen",                                                                          // 31
  setPassword: "Passwort festlegen",                                                                                   // 32
  sign: "Anmelden",                                                                                                    // 33
  signIn: "Anmelden",                                                                                                  // 34
  signin: "anmelden",                                                                                                  // 35
  signOut: "Abmelden",                                                                                                 // 36
  signUp: "Registrieren",                                                                                              // 37
  signupCode: "Registrierungscode",                                                                                    // 38
  signUpWithYourEmailAddress: "Mit E-Mail registrieren",                                                               // 39
  terms: "Geschäftsbedingungen",                                                                                       // 40
  updateYourPassword: "Passwort aktualisieren",                                                                        // 41
  username: "Benutzername",                                                                                            // 42
  usernameOrEmail: "Benutzername oder E-Mail",                                                                         // 43
  "with": "mit",                                                                                                       // 44
  "Verification email lost?": "Verifizierungsemail verloren?",                                                         // 45
  "Send again": "Erneut senden",                                                                                       // 46
  "Send the verification email again": "Verifizierungsemail erneut senden",                                            // 47
  "Send email again": "Email erneut senden",                                                                           // 48
  "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Eine neue Email wurde verschickt. Sollte sich die Email nicht im Posteingang befinden, empfiehlt es sich, den Spamordner zu überprüfen.",
  info: {                                                                                                              // 51
    emailSent: "E-Mail gesendet",                                                                                      // 52
    emailVerified: "E-Mail verifiziert",                                                                               // 53
    PasswordChanged: "Passwort geändert",                                                                              // 54
    PasswordReset: "Passwort zurückgesetzt"                                                                            // 55
  },                                                                                                                   // 52
  error: {                                                                                                             // 58
    emailRequired: "E-Mail benötigt.",                                                                                 // 59
    minChar: "Passwort muss mindestens 7 Zeichen lang sein.",                                                          // 60
    pwdsDontMatch: "Passwörter stimmen nicht überein.",                                                                // 61
    pwOneDigit: "Passwort muss mindestens eine Ziffer enthalten.",                                                     // 62
    pwOneLetter: "Passwort muss mindestens einen Buchstaben enthalten.",                                               // 63
    signInRequired: "Eine Anmeldung ist erforderlich.",                                                                // 64
    signupCodeIncorrect: "Registrierungscode ungültig.",                                                               // 65
    signupCodeRequired: "Registrierungscode benötigt.",                                                                // 66
    usernameIsEmail: "Benutzername darf keine E-Mail Adresse sein.",                                                   // 67
    usernameRequired: "Benutzername benötigt.",                                                                        // 68
    accounts: {                                                                                                        // 70
      "Email already exists.": "Die E-Mail Adresse wird bereits verwendet.",                                           // 75
      "Email doesn't match the criteria.": "E-Mail Adresse erfüllt die Anforderungen nicht.",                          // 76
      "Invalid login token": "Ungültiger Login-Token",                                                                 // 77
      "Login forbidden": "Anmeldedaten ungültig",                                                                      // 78
      "Service unknown": "Dienst unbekannt",                                                                           // 80
      "Unrecognized options for login request": "Unbekannte Optionen für Login Request",                               // 81
      "User validation failed": "Die Benutzerdaten sind nicht korrekt",                                                // 82
      "Username already exists.": "Der Benutzer existiert bereits.",                                                   // 83
      "You are not logged in.": "Eine Anmeldung ist erforderlich.",                                                    // 84
      "You've been logged out by the server. Please log in again.": "Die Sitzung ist abgelaufen, eine neue Anmeldung ist nötig.",
      "Your session has expired. Please log in again.": "Die Sitzung ist abgelaufen, eine neue Anmeldung ist nötig.",  // 86
      "No matching login attempt found": "Kein passender Loginversuch gefunden.",                                      // 90
      "Password is old. Please reset your password.": "Das Passwort ist abgelaufen, ein Zurücksetzen ist erforderlich.",
      "Incorrect password": "Falsches Passwort",                                                                       // 98
      "Invalid email": "Ungültige E-Mail Adresse",                                                                     // 99
      "Must be logged in": "Eine Anmeldung ist erforderlich",                                                          // 100
      "Need to set a username or email": "Benutzername oder E-Mail Adresse müssen angegeben werden",                   // 101
      "Password may not be empty": "Das Passwort darf nicht leer sein",                                                // 103
      "Signups forbidden": "Anmeldungen sind nicht erlaubt",                                                           // 104
      "Token expired": "Token ist abgelaufen",                                                                         // 105
      "Token has invalid email address": "E-Mail Adresse passt nicht zum Token",                                       // 106
      "User has no password set": "Kein Passwort für den Benutzer angegeben",                                          // 107
      "User not found": "Benutzer nicht gefunden",                                                                     // 108
      "Verify email link expired": "Link zur E-Mail Verifizierung ist abgelaufen",                                     // 109
      "Verify email link is for unknown address": "Link zur Verifizierung ist für eine unbekannte E-Mail Adresse",     // 110
      "Already verified": "Diese E-Mail-Adresse ist bereits verifiziert",                                              // 111
      "Match failed": "Abgleich fehlgeschlagen",                                                                       // 114
      "Unknown error": "Unbekannter Fehler"                                                                            // 117
    }                                                                                                                  // 75
  }                                                                                                                    // 59
};                                                                                                                     // 6
T9n.map("de", de);                                                                                                     // 120
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/el.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var el;                                                                                                                // 4
el = {                                                                                                                 // 4
  add: "προσθέστε",                                                                                                    // 6
  and: "και",                                                                                                          // 7
  back: "πίσω",                                                                                                        // 8
  changePassword: "Αλλαγή Κωδικού",                                                                                    // 9
  choosePassword: "Επιλογή Κωδικού",                                                                                   // 10
  clickAgree: "Πατώντας Εγγραφή, συμφωνείτε σε",                                                                       // 11
  configure: "Διαμόρφωση",                                                                                             // 12
  createAccount: "Δημιουργία Λογαριασμού",                                                                             // 13
  currentPassword: "Τρέχων Κωδικός",                                                                                   // 14
  dontHaveAnAccount: "Δεν έχετε λογαριασμό;",                                                                          // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Ηλεκτρονική Διεύθυνση",                                                                               // 17
  emailResetLink: "Αποστολή Συνδέσμου Επαναφοράς",                                                                     // 18
  forgotPassword: "Ξεχάσατε τον κωδικό;",                                                                              // 19
  ifYouAlreadyHaveAnAccount: "Αν έχετε ήδη λογαριασμό",                                                                // 20
  newPassword: "Νέος Κωδικός",                                                                                         // 21
  newPasswordAgain: "Νέος Κωδικός (ξανά)",                                                                             // 22
  optional: "Προαιρετικά",                                                                                             // 23
  OR: "Ή",                                                                                                             // 24
  password: "Κωδικός",                                                                                                 // 25
  passwordAgain: "Κωδικός (ξανά)",                                                                                     // 26
  privacyPolicy: "Πολιτική Απορρήτου",                                                                                 // 27
  remove: "αφαιρέστε",                                                                                                 // 28
  resetYourPassword: "Επαναφορά κωδικού",                                                                              // 29
  setPassword: "Ορίστε Κωδικό",                                                                                        // 30
  sign: "Σύνδεση",                                                                                                     // 31
  signIn: "Είσοδος",                                                                                                   // 32
  signin: "συνδεθείτε",                                                                                                // 33
  signOut: "Αποσύνδεση",                                                                                               // 34
  signUp: "Εγγραφή",                                                                                                   // 35
  signupCode: "Κώδικας Εγγραφής",                                                                                      // 36
  signUpWithYourEmailAddress: "Εγγραφή με την ηλεκτρονική σας διεύθυνση",                                              // 37
  terms: "Όροι Χρήσης",                                                                                                // 38
  updateYourPassword: "Ανανεώστε τον κωδικό σας",                                                                      // 39
  username: "Όνομα χρήστη",                                                                                            // 40
  usernameOrEmail: "Όνομα χρήστη ή email",                                                                             // 41
  "with": "με",                                                                                                        // 42
  info: {                                                                                                              // 45
    emailSent: "Το Email στάλθηκε",                                                                                    // 46
    emailVerified: "Το Email επιβεβαιώθηκε",                                                                           // 47
    passwordChanged: "Ο Κωδικός άλλαξε",                                                                               // 48
    passwordReset: "Ο Κωδικός επαναφέρθηκε"                                                                            // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Το Email απαιτείται.",                                                                             // 53
    minChar: "7 χαρακτήρες τουλάχιστον.",                                                                              // 54
    pwdsDontMatch: "Οι κωδικοί δεν ταιριάζουν",                                                                        // 55
    pwOneDigit: "Ο κωδικός πρέπει να έχει τουλάχιστον ένα ψηφίο.",                                                     // 56
    pwOneLetter: "Ο κωδικός πρέπει να έχει τουλάχιστον ένα γράμμα.",                                                   // 57
    signInRequired: "Πρέπει να είστε συνδεδεμένος για να πραγματοποιήσετε αυτή την ενέργεια.",                         // 58
    signupCodeIncorrect: "Ο κώδικας εγγραφής δεν είναι σωστός.",                                                       // 59
    signupCodeRequired: "Ο κώδικας εγγραφής απαιτείται.",                                                              // 60
    usernameIsEmail: "Το όνομα χρήστη δεν μπορεί να είναι μια διεύθυνση email.",                                       // 61
    usernameRequired: "Το όνομα χρήστη απαιτείται.",                                                                   // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Αυτό το email υπάρχει ήδη.",                                                           // 70
      "Email doesn't match the criteria.": "Το email δεν ταιριάζει με τα κριτήρια.",                                   // 71
      "Invalid login token": "Άκυρο διακριτικό σύνδεσης",                                                              // 72
      "Login forbidden": "Η είσοδος απαγορεύεται",                                                                     // 73
      "Service unknown": "Άγνωστη υπηρεσία",                                                                           // 75
      "Unrecognized options for login request": "Μη αναγνωρίσιμες επιλογές για αίτημα εισόδου",                        // 76
      "User validation failed": "Η επικύρωση του χρήστη απέτυχε",                                                      // 77
      "Username already exists.": "Αυτό το όνομα χρήστη υπάρχει ήδη.",                                                 // 78
      "You are not logged in.": "Δεν είστε συνδεδεμένος.",                                                             // 79
      "You've been logged out by the server. Please log in again.": "Αποσυνδεθήκατε από τον διακομιστή. Παρακαλούμε συνδεθείτε ξανά.",
      "Your session has expired. Please log in again.": "Η συνεδρία έληξε. Παρακαλούμε συνδεθείτε ξανά.",              // 81
      "No matching login attempt found": "Δεν βρέθηκε καμία απόπειρα σύνδεσης που να ταιριάζει",                       // 85
      "Password is old. Please reset your password.": "Ο κωδικός είναι παλιός. Παρακαλούμε επαναφέρετε τον κωδικό σας.",
      "Incorrect password": "Εσφαλμένος κωδικός",                                                                      // 93
      "Invalid email": "Εσφαλμένο email",                                                                              // 94
      "Must be logged in": "Πρέπει να είστε συνδεδεμένος",                                                             // 95
      "Need to set a username or email": "Χρειάζεται να ορίσετε όνομα χρήστη ή email",                                 // 96
      "old password format": "κωδικός παλιάς μορφής",                                                                  // 97
      "Password may not be empty": "Ο κωδικός δεν μπορεί να είναι άδειος",                                             // 98
      "Signups forbidden": "Οι εγγραφές απαγορεύονται",                                                                // 99
      "Token expired": "Το διακριτικό σύνδεσης έληξε",                                                                 // 100
      "Token has invalid email address": "Το διακριτικό σύνδεσης έχει άκυρη διεύθυνση email",                          // 101
      "User has no password set": "Ο χρήστης δεν έχει ορίσει κωδικό",                                                  // 102
      "User not found": "Ο χρήστης δεν βρέθηκε",                                                                       // 103
      "Verify email link expired": "Ο σύνδεσμος επαλήθευσης του email έληξε",                                          // 104
      "Verify email link is for unknown address": "Ο σύνδεσμος επαλήθευσης του email είναι για άγνωστη διεύθυνση",     // 105
      "Match failed": "Η αντιστοίχηση απέτυχε",                                                                        // 108
      "Unknown error": "Άγνωστο σφάλμα"                                                                                // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("el", el);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/en.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var en;                                                                                                                // 3
en = {                                                                                                                 // 3
  t9Name: 'English',                                                                                                   // 5
  add: "add",                                                                                                          // 7
  and: "and",                                                                                                          // 8
  back: "back",                                                                                                        // 9
  cancel: "Cancel",                                                                                                    // 10
  changePassword: "Change Password",                                                                                   // 11
  choosePassword: "Choose a Password",                                                                                 // 12
  clickAgree: "By clicking Register, you agree to our",                                                                // 13
  configure: "Configure",                                                                                              // 14
  createAccount: "Create an Account",                                                                                  // 15
  currentPassword: "Current Password",                                                                                 // 16
  dontHaveAnAccount: "Don't have an account?",                                                                         // 17
  email: "Email",                                                                                                      // 18
  emailAddress: "Email Address",                                                                                       // 19
  emailResetLink: "Email Reset Link",                                                                                  // 20
  forgotPassword: "Forgot your password?",                                                                             // 21
  ifYouAlreadyHaveAnAccount: "If you already have an account",                                                         // 22
  newPassword: "New Password",                                                                                         // 23
  newPasswordAgain: "New Password (again)",                                                                            // 24
  optional: "Optional",                                                                                                // 25
  OR: "OR",                                                                                                            // 26
  password: "Password",                                                                                                // 27
  passwordAgain: "Password (again)",                                                                                   // 28
  privacyPolicy: "Privacy Policy",                                                                                     // 29
  remove: "remove",                                                                                                    // 30
  resetYourPassword: "Reset your password",                                                                            // 31
  setPassword: "Set Password",                                                                                         // 32
  sign: "Sign",                                                                                                        // 33
  signIn: "Sign In",                                                                                                   // 34
  signin: "sign in",                                                                                                   // 35
  signOut: "Sign Out",                                                                                                 // 36
  signUp: "Register",                                                                                                  // 37
  signupCode: "Registration Code",                                                                                     // 38
  signUpWithYourEmailAddress: "Register with your email address",                                                      // 39
  terms: "Terms of Use",                                                                                               // 40
  updateYourPassword: "Update your password",                                                                          // 41
  username: "Username",                                                                                                // 42
  usernameOrEmail: "Username or email",                                                                                // 43
  "with": "with",                                                                                                      // 44
  maxAllowedLength: "Maximum allowed length",                                                                          // 45
  minRequiredLength: "Minimum required length",                                                                        // 46
  resendVerificationEmail: "Send email again",                                                                         // 47
  resendVerificationEmailLink_pre: "Verification email lost?",                                                         // 48
  resendVerificationEmailLink_link: "Send again",                                                                      // 49
  enterPassword: "Enter password",                                                                                     // 50
  enterNewPassword: "Enter new password",                                                                              // 51
  enterEmail: "Enter email",                                                                                           // 52
  enterUsername: "Enter username",                                                                                     // 53
  enterUsernameOrEmail: "Enter username or email",                                                                     // 54
  orUse: "Or use",                                                                                                     // 55
  info: {                                                                                                              // 57
    emailSent: "Email sent",                                                                                           // 58
    emailVerified: "Email verified",                                                                                   // 59
    passwordChanged: "Password changed",                                                                               // 60
    passwordReset: "Password reset"                                                                                    // 61
  },                                                                                                                   // 58
  alert: {                                                                                                             // 63
    ok: 'Ok',                                                                                                          // 64
    type: {                                                                                                            // 65
      info: 'Notice',                                                                                                  // 66
      error: 'Error',                                                                                                  // 67
      warning: 'Warning'                                                                                               // 68
    }                                                                                                                  // 66
  },                                                                                                                   // 64
  error: {                                                                                                             // 70
    emailRequired: "Email is required.",                                                                               // 71
    minChar: "7 character minimum password.",                                                                          // 72
    pwdsDontMatch: "Passwords don't match",                                                                            // 73
    pwOneDigit: "Password must have at least one digit.",                                                              // 74
    pwOneLetter: "Password requires 1 letter.",                                                                        // 75
    signInRequired: "You must be signed in to do that.",                                                               // 76
    signupCodeIncorrect: "Registration code is incorrect.",                                                            // 77
    signupCodeRequired: "Registration code is required.",                                                              // 78
    usernameIsEmail: "Username cannot be an email address.",                                                           // 79
    usernameRequired: "Username is required.",                                                                         // 80
    accounts: {                                                                                                        // 83
      "Email already exists.": "Email already exists.",                                                                // 87
      "Email doesn't match the criteria.": "Email doesn't match the criteria.",                                        // 88
      "Invalid login token": "Invalid login token",                                                                    // 89
      "Login forbidden": "Login forbidden",                                                                            // 90
      "Service unknown": "Service unknown",                                                                            // 92
      "Unrecognized options for login request": "Unrecognized options for login request",                              // 93
      "User validation failed": "User validation failed",                                                              // 94
      "Username already exists.": "Username already exists.",                                                          // 95
      "You are not logged in.": "You are not logged in.",                                                              // 96
      "You've been logged out by the server. Please log in again.": "You've been logged out by the server. Please log in again.",
      "Your session has expired. Please log in again.": "Your session has expired. Please log in again.",              // 98
      "Already verified": "Already verified",                                                                          // 99
      "Invalid email or username": "Invalid email or username",                                                        // 100
      "Internal server error": "Internal server error",                                                                // 101
      "undefined": "Something went wrong",                                                                             // 102
      "No matching login attempt found": "No matching login attempt found",                                            // 106
      "Password is old. Please reset your password.": "Password is old. Please reset your password.",                  // 110
      "Incorrect password": "Incorrect password",                                                                      // 114
      "Invalid email": "Invalid email",                                                                                // 115
      "Must be logged in": "Must be logged in",                                                                        // 116
      "Need to set a username or email": "Need to set a username or email",                                            // 117
      "old password format": "old password format",                                                                    // 118
      "Password may not be empty": "Password may not be empty",                                                        // 119
      "Signups forbidden": "Signups forbidden",                                                                        // 120
      "Token expired": "Token expired",                                                                                // 121
      "Token has invalid email address": "Token has invalid email address",                                            // 122
      "User has no password set": "User has no password set",                                                          // 123
      "User not found": "User not found",                                                                              // 124
      "Verify email link expired": "Verify email link expired",                                                        // 125
      "Verify email link is for unknown address": "Verify email link is for unknown address",                          // 126
      "At least 1 digit, 1 lowercase and 1 uppercase": "At least 1 digit, 1 lowercase and 1 uppercase",                // 127
      "Please verify your email first. Check the email and follow the link!": "Please verify your email first. Check the email and follow the link!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.",
      "Match failed": "Match failed",                                                                                  // 132
      "Unknown error": "Unknown error",                                                                                // 135
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Error, too many requests. Please slow down. You must wait 1 seconds before trying again."
    }                                                                                                                  // 87
  }                                                                                                                    // 71
};                                                                                                                     // 5
T9n.map("en", en);                                                                                                     // 139
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/es.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var es;                                                                                                                // 4
es = {                                                                                                                 // 4
  t9Name: 'Español',                                                                                                   // 6
  add: "agregar",                                                                                                      // 8
  and: "y",                                                                                                            // 9
  back: "atrás",                                                                                                       // 10
  cancel: "Cancelar",                                                                                                  // 11
  changePassword: "Cambiar contraseña",                                                                                // 12
  choosePassword: "Eligir contraseña",                                                                                 // 13
  clickAgree: "Al hacer clic en Sucribir apruebas la",                                                                 // 14
  configure: "Disposición",                                                                                            // 15
  createAccount: "Crear cuenta",                                                                                       // 16
  currentPassword: "Contraseña actual",                                                                                // 17
  dontHaveAnAccount: "No tienes una cuenta?",                                                                          // 18
  email: "Email",                                                                                                      // 19
  emailAddress: "Dirección de email",                                                                                  // 20
  emailResetLink: "Reiniciar email",                                                                                   // 21
  forgotPassword: "¿Olvidó su contraseña?",                                                                            // 22
  ifYouAlreadyHaveAnAccount: "Si ya tiene una cuenta",                                                                 // 23
  newPassword: "Nueva contraseña",                                                                                     // 24
  newPasswordAgain: "Nueva contraseña (repetir)",                                                                      // 25
  optional: "Opcional",                                                                                                // 26
  OR: "O",                                                                                                             // 27
  password: "Contraseña",                                                                                              // 28
  passwordAgain: "Contraseña (repetir)",                                                                               // 29
  privacyPolicy: "Póliza de Privacidad",                                                                               // 30
  remove: "remover",                                                                                                   // 31
  resetYourPassword: "Resetear tu contraseña",                                                                         // 32
  setPassword: "Definir contraseña",                                                                                   // 33
  sign: "Ingresar",                                                                                                    // 34
  signIn: "Entrar",                                                                                                    // 35
  signin: "entrar",                                                                                                    // 36
  signOut: "Salir",                                                                                                    // 37
  signUp: "Registrarse",                                                                                               // 38
  signupCode: "Código de registro",                                                                                    // 39
  signUpWithYourEmailAddress: "Registrarse con tu email",                                                              // 40
  terms: "Términos de uso",                                                                                            // 41
  updateYourPassword: "Actualizar tu contraseña",                                                                      // 42
  username: "Usuario",                                                                                                 // 43
  usernameOrEmail: "Usuario o email",                                                                                  // 44
  "with": "con",                                                                                                       // 45
  maxAllowedLength: "Longitud máxima permitida",                                                                       // 46
  minRequiredLength: "Longitud máxima requerida",                                                                      // 47
  resendVerificationEmail: "Mandar email de nuevo",                                                                    // 48
  resendVerificationEmailLink_pre: "Email de verificación perdida?",                                                   // 49
  resendVerificationEmailLink_link: "Volver a mandar",                                                                 // 50
  enterPassword: "Introducir contraseña",                                                                              // 51
  enterNewPassword: "Introducir contraseña nueva",                                                                     // 52
  enterEmail: "Introducir email",                                                                                      // 53
  enterUsername: "Introducir nombre de usario",                                                                        // 54
  enterUsernameOrEmail: "Introducir nombre de usario o email",                                                         // 55
  orUse: "O usar",                                                                                                     // 56
  info: {                                                                                                              // 58
    emailSent: "Email enviado",                                                                                        // 59
    emailVerified: "Email verificado",                                                                                 // 60
    passwordChanged: "Contraseña cambiada",                                                                            // 61
    passwordReset: "Resetear contraseña"                                                                               // 62
  },                                                                                                                   // 59
  alert: {                                                                                                             // 64
    ok: 'Ok',                                                                                                          // 65
    type: {                                                                                                            // 66
      info: 'Aviso',                                                                                                   // 67
      error: 'Error',                                                                                                  // 68
      warning: 'Advertencia'                                                                                           // 69
    }                                                                                                                  // 67
  },                                                                                                                   // 65
  error: {                                                                                                             // 71
    emailRequired: "El email es requerido.",                                                                           // 72
    minChar: "7 caracteres mínimo.",                                                                                   // 73
    pwdsDontMatch: "Las contraseñas no coinciden",                                                                     // 74
    pwOneDigit: "mínimo un dígito.",                                                                                   // 75
    pwOneLetter: "mínimo una letra.",                                                                                  // 76
    signInRequired: "Debes iniciar sesión para hacer eso.",                                                            // 77
    signupCodeIncorrect: "El código de suscripción no coincide.",                                                      // 78
    signupCodeRequired: "Se requiere el código de suscripción.",                                                       // 79
    usernameIsEmail: "El usuario no puede ser el email.",                                                              // 80
    usernameRequired: "Se requiere un usuario.",                                                                       // 81
    accounts: {                                                                                                        // 84
      "Email already exists.": "El email ya existe.",                                                                  // 89
      "Email doesn't match the criteria.": "El email no coincide con los criterios.",                                  // 90
      "Invalid login token": "Token de inicio de sesión invalida",                                                     // 91
      "Login forbidden": "Inicio de sesión prohibido",                                                                 // 92
      "Service unknown": "Servicio desconocido",                                                                       // 94
      "Unrecognized options for login request": "Opciones desconocidas para solicitud de inicio de sesión",            // 95
      "User validation failed": "No se ha podido validar el usuario",                                                  // 96
      "Username already exists.": "El usuario ya existe.",                                                             // 97
      "You are not logged in.": "No estas autenticado.",                                                               // 98
      "You've been logged out by the server. Please log in again.": "Has sido desconectado por el servidor. Por favor ingresa de nuevo.",
      "Your session has expired. Please log in again.": "Tu sesión ha expirado. Por favor ingresa de nuevo.",          // 100
      "Already verified": "Ya ha sido verificada",                                                                     // 101
      "Invalid email or username": "Email o nombre de usuario no validos",                                             // 102
      "Internal server error": "Error interno del servidor",                                                           // 103
      "undefined": "Algo ha ido mal",                                                                                  // 104
      "No matching login attempt found": "Ningún intento de inicio de sesión coincidente se encuentra",                // 108
      "Password is old. Please reset your password.": "Contraseña es vieja. Por favor resetear la contraseña.",        // 112
      "Incorrect password": "Contraseña inválida. No estas autenticado.",                                              // 116
      "Invalid email": "Email inválida",                                                                               // 117
      "Must be logged in": "Debes ingresar",                                                                           // 118
      "Need to set a username or email": "Tienes que especificar un usuario o un email",                               // 119
      "old password format": "formato viejo de contraseña",                                                            // 120
      "Password may not be empty": "Contraseña no puede quedar vacía",                                                 // 121
      "Signups forbidden": "Registro prohibido",                                                                       // 122
      "Token expired": "Token expirado",                                                                               // 123
      "Token has invalid email address": "Token contiene un email inválido",                                           // 124
      "User has no password set": "Usuario no tiene contraseña",                                                       // 125
      "User not found": "Usuario no encontrado",                                                                       // 126
      "Verify email link expired": "El enlace para verificar el email ha expirado",                                    // 127
      "Verify email link is for unknown address": "El enlace para verificar el email contiene una dirección desconocida",
      "At least 1 digit, 1 lowercase and 1 uppercase": "Almenos tiene que contener 1 numero, 1 miniscula y 1 mayuscula",
      "Please verify your email first. Check the email and follow the link!": "Por favor compruebe su email primero. Siga el link que le ha sido enviado.",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Un nuevo correo te ha sido enviado. Si no ves el correo en tu bandeja comprueba tu carpeta de spam.",
      "Match failed": "Encontrar pareja coincidente ha fallado",                                                       // 134
      "Unknown error": "Error desconocido",                                                                            // 137
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Error, demasiadas peticiones. Por favor no vaya tan rapido. Tienes que esperar almenos 1 segundo antes de provar otra vez."
    }                                                                                                                  // 89
  }                                                                                                                    // 72
};                                                                                                                     // 6
T9n.map("es", es);                                                                                                     // 141
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/et.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var et;                                                                                                                // 4
et = {                                                                                                                 // 4
  t9Name: 'Estonian',                                                                                                  // 6
  add: "lisa",                                                                                                         // 8
  and: "ja",                                                                                                           // 9
  back: "tagasi",                                                                                                      // 10
  cancel: "Katkesta",                                                                                                  // 11
  changePassword: "Muuda salasõna",                                                                                    // 12
  choosePassword: "Vali salasõna",                                                                                     // 13
  clickAgree: "Vajutades nupule Registreeru, nõustud meie",                                                            // 14
  configure: "Seadista",                                                                                               // 15
  createAccount: "Loo konto",                                                                                          // 16
  currentPassword: "Praegune salasõna",                                                                                // 17
  dontHaveAnAccount: "Sul ei ole kontot?",                                                                             // 18
  email: "E-post",                                                                                                     // 19
  emailAddress: "E-posti aadress",                                                                                     // 20
  emailResetLink: "Saada lähestamise link",                                                                            // 21
  forgotPassword: "Unustasid salasõna?",                                                                               // 22
  ifYouAlreadyHaveAnAccount: "Kui Sul juba on konto",                                                                  // 23
  newPassword: "Uus salasõna",                                                                                         // 24
  newPasswordAgain: "Uus salasõna (uuesti)",                                                                           // 25
  optional: "Valikuline",                                                                                              // 26
  OR: "või",                                                                                                           // 27
  password: "salasõna",                                                                                                // 28
  passwordAgain: "Salasõna (uuesti)",                                                                                  // 29
  privacyPolicy: "Privaatsuspoliitika",                                                                                // 30
  remove: "eemalda",                                                                                                   // 31
  resetYourPassword: "Lähesta oma salasõna",                                                                           // 32
  setPassword: "Seadista salasõna",                                                                                    // 33
  sign: "Logi",                                                                                                        // 34
  signIn: "Logi sisse ",                                                                                               // 35
  signin: "logi sisse",                                                                                                // 36
  signOut: "Logi välja",                                                                                               // 37
  signUp: "Registreeru",                                                                                               // 38
  signupCode: "Registreerumiskood",                                                                                    // 39
  signUpWithYourEmailAddress: "Registreeru oma e-posti aadressiga",                                                    // 40
  terms: "Kasutustingimused",                                                                                          // 41
  updateYourPassword: "Uuenda oma salasõna",                                                                           // 42
  username: "Kasutajanimi",                                                                                            // 43
  usernameOrEmail: "Kasutaja või e-post",                                                                              // 44
  "with": "koos",                                                                                                      // 45
  maxAllowedLength: "Suurim lubatud pikkus",                                                                           // 46
  minRequiredLength: "Väikseim lubatud pikkus",                                                                        // 47
  resendVerificationEmail: "Saada e-kiri uuesti",                                                                      // 48
  resendVerificationEmailLink_pre: "Kinnitus e-kiri on kadunud?",                                                      // 49
  resendVerificationEmailLink_link: "Saada uuesti",                                                                    // 50
  enterPassword: "Sisesta salasõna",                                                                                   // 51
  enterNewPassword: "Sisesta uus salasõna",                                                                            // 52
  enterEmail: "Sisesta e-posti aadress",                                                                               // 53
  enterUsername: "Sisesta kasutajanimi",                                                                               // 54
  enterUsernameOrEmail: "Sisesta kasutajanimi või e-posti aadress",                                                    // 55
  orUse: "Või kasuta",                                                                                                 // 56
  info: {                                                                                                              // 58
    emailSent: "E-kiri saadetud",                                                                                      // 59
    emailVerified: "E-posti aadress kinnitatud",                                                                       // 60
    passwordChanged: "Salasõna muudetud",                                                                              // 61
    passwordReset: "Salasõna lähestatud"                                                                               // 62
  },                                                                                                                   // 59
  alert: {                                                                                                             // 64
    ok: 'OK',                                                                                                          // 65
    type: {                                                                                                            // 66
      info: 'Teate',                                                                                                   // 67
      error: 'Viga',                                                                                                   // 68
      warning: 'Hoiatus'                                                                                               // 69
    }                                                                                                                  // 67
  },                                                                                                                   // 65
  error: {                                                                                                             // 71
    emailRequired: "E-post aadress on kohustuslik.",                                                                   // 72
    minChar: "Salasõna peab olema vähemalt 7 märgi pikkune.",                                                          // 73
    pwdsDontMatch: "Salasõnad ei vasta",                                                                               // 74
    pwOneDigit: "Salasõna peab sisaldama vähemalt ühte numbrit.",                                                      // 75
    pwOneLetter: "Salasõna peab sisaldama vähemalt ühte tähte.",                                                       // 76
    signInRequired: "Selle jaoks pead olema sisse logitud.",                                                           // 77
    signupCodeIncorrect: "Registreerimiskood on vale.",                                                                // 78
    signupCodeRequired: "Registreerimiskood on kohustuslik.",                                                          // 79
    usernameIsEmail: "Kasutajanimi ei saa olla e-posti aadress.",                                                      // 80
    usernameRequired: "Kasutajanimi on kohustuslik.",                                                                  // 81
    accounts: {                                                                                                        // 84
      "Email already exists.": "See e-posti aadress on juba registreeritud.",                                          // 88
      "Email doesn't match the criteria.": "E-posti aadress ei vasta nõuetele.",                                       // 89
      "Invalid login token": "Vigane sisselogimise žetoon",                                                            // 90
      "Login forbidden": "Sisse logimine keelatud",                                                                    // 91
      "Service unknown": "Tundmatu teenus",                                                                            // 93
      "Unrecognized options for login request": "Tundmatud seaded sisselogimise palves",                               // 94
      "User validation failed": "Kasutaja kinnitamine ei õnnestunud",                                                  // 95
      "Username already exists.": "See kasutajanimi on juba registreeritud.",                                          // 96
      "You are not logged in.": "Sa ei ole sisse logitud.",                                                            // 97
      "You've been logged out by the server. Please log in again.": "Sa oled serveri poolt välja logitud. Palun logi uuesti sisse.",
      "Your session has expired. Please log in again.": "Sinu sessioon on aegunud. Palun logi uuesti sisse.",          // 99
      "Already verified": "Juba kinnitatud",                                                                           // 100
      "Invalid email or username": "Vale e-posti aadress või kasutajanimi",                                            // 101
      "Internal server error": "Sisemine serveri viga",                                                                // 102
      "undefined": "Midagi läks valesti",                                                                              // 103
      "No matching login attempt found": "Sobivat logimisproovi ei leitud",                                            // 107
      "Password is old. Please reset your password.": "Salasõna on vana. Palun lähesta oma salasõna.",                 // 111
      "Incorrect password": "Vale salasõna",                                                                           // 115
      "Invalid email": "Vale e-posti aadress",                                                                         // 116
      "Must be logged in": "Pead olema sisse logitud",                                                                 // 117
      "Need to set a username or email": "Vaja on seadistada kasutajanimi või e-post",                                 // 118
      "old password format": "vana salasõna formaat",                                                                  // 119
      "Password may not be empty": "Salasõna ei või olla tühi",                                                        // 120
      "Signups forbidden": "Registreerumine on suletud",                                                               // 121
      "Token expired": "Aegunud žetoon",                                                                               // 122
      "Token has invalid email address": "Žetoon on seotud vale e-posti aadressiga",                                   // 123
      "User has no password set": "Kasutajal on salasõna seadmata",                                                    // 124
      "User not found": "Sellist kasutajat ei leitud",                                                                 // 125
      "Verify email link expired": "Kinnitus e-kirja viide on aegunud",                                                // 126
      "Verify email link is for unknown address": "Kinnitus e-kirja viide on tundmatule aadressile",                   // 127
      "At least 1 digit, 1 lowercase and 1 uppercase": "Vähemalt 1 number, 1 väike täht ja 1 suur täht",               // 128
      "Please verify your email first. Check the email and follow the link!": "Palun kinnita oma e-posti aadress. E-kirjas vajuta viitele!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Sulle on saadetud uus e-kiri. Kui sa kirja ei näe, vaata palun rämpsposti kausta.",
      "Match failed": "Ei sobi",                                                                                       // 133
      "Unknown error": "Teadmata viga",                                                                                // 136
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Viga, liiga palju proovimisi. Palun võta aeg maha. Pead ootama vähemalt 1 sekundi, enne kui uuesti proovid."
    }                                                                                                                  // 88
  }                                                                                                                    // 72
};                                                                                                                     // 6
T9n.map("et", et);                                                                                                     // 140
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/es_ES.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var es_ES;                                                                                                             // 4
es_ES = {                                                                                                              // 4
  t9Name: 'Español-España',                                                                                            // 6
  add: "agregar",                                                                                                      // 8
  and: "y",                                                                                                            // 9
  back: "atrás",                                                                                                       // 10
  cancel: "Cancelar",                                                                                                  // 11
  changePassword: "Cambiar Contraseña",                                                                                // 12
  choosePassword: "Eligir Contraseña",                                                                                 // 13
  clickAgree: "Si haces clic en Crear Cuenta estás de acuerdo con la",                                                 // 14
  configure: "Configurar",                                                                                             // 15
  createAccount: "Crear cuenta",                                                                                       // 16
  currentPassword: "Contraseña actual",                                                                                // 17
  dontHaveAnAccount: "¿No estás registrado?",                                                                          // 18
  email: "Email",                                                                                                      // 19
  emailAddress: "Dirección de email",                                                                                  // 20
  emailResetLink: "Restaurar email",                                                                                   // 21
  forgotPassword: "¿Has olvidado tu contraseña?",                                                                      // 22
  ifYouAlreadyHaveAnAccount: "Ya tienes una cuenta, ",                                                                 // 23
  newPassword: "Nueva Contraseña",                                                                                     // 24
  newPasswordAgain: "Nueva Contraseña (repetición)",                                                                   // 25
  optional: "Opcional",                                                                                                // 26
  OR: "O",                                                                                                             // 27
  password: "Contraseña",                                                                                              // 28
  passwordAgain: "Contraseña (repetición)",                                                                            // 29
  privacyPolicy: "Póliza de Privacidad",                                                                               // 30
  remove: "remover",                                                                                                   // 31
  resetYourPassword: "Recuperar tu contraseña",                                                                        // 32
  setPassword: "Definir Contraseña",                                                                                   // 33
  sign: "Entrar",                                                                                                      // 34
  signIn: "Entrar",                                                                                                    // 35
  signin: "entra",                                                                                                     // 36
  signOut: "Salir",                                                                                                    // 37
  signUp: "Regístrate",                                                                                                // 38
  signupCode: "Código para registrarte",                                                                               // 39
  signUpWithYourEmailAddress: "Regístrate con tu email",                                                               // 40
  terms: "Términos de Uso",                                                                                            // 41
  updateYourPassword: "Actualizar tu contraseña",                                                                      // 42
  username: "Usuario",                                                                                                 // 43
  usernameOrEmail: "Usuario o email",                                                                                  // 44
  "with": "con",                                                                                                       // 45
  maxAllowedLength: "Longitud máxima permitida",                                                                       // 46
  minRequiredLength: "Longitud máxima requerida",                                                                      // 47
  resendVerificationEmail: "Mandar email de nuevo",                                                                    // 48
  resendVerificationEmailLink_pre: "Email de verificación perdida?",                                                   // 49
  resendVerificationEmailLink_link: "Volver a mandar",                                                                 // 50
  enterPassword: "Introducir contraseña",                                                                              // 51
  enterNewPassword: "Introducir contraseña nueva",                                                                     // 52
  enterEmail: "Introducir email",                                                                                      // 53
  enterUsername: "Introducir nombre de usario",                                                                        // 54
  enterUsernameOrEmail: "Introducir nombre de usario o email",                                                         // 55
  orUse: "O puedes usar",                                                                                              // 56
  info: {                                                                                                              // 58
    emailSent: "Email enviado",                                                                                        // 59
    emailVerified: "Email verificado",                                                                                 // 60
    passwordChanged: "Contraseña cambiado",                                                                            // 61
    passwordReset: "Resetar Contraseña"                                                                                // 62
  },                                                                                                                   // 59
  alert: {                                                                                                             // 64
    ok: 'Ok',                                                                                                          // 65
    type: {                                                                                                            // 66
      info: 'Aviso',                                                                                                   // 67
      error: 'Error',                                                                                                  // 68
      warning: 'Advertencia'                                                                                           // 69
    }                                                                                                                  // 67
  },                                                                                                                   // 65
  error: {                                                                                                             // 71
    emailRequired: "El email es necesario.",                                                                           // 72
    minChar: "7 carácteres mínimo.",                                                                                   // 73
    pwdsDontMatch: "Contraseñas no coninciden",                                                                        // 74
    pwOneDigit: "mínimo un dígito.",                                                                                   // 75
    pwOneLetter: "mínimo una letra.",                                                                                  // 76
    signInRequired: "Debes iniciar sesión para esta opción.",                                                          // 77
    signupCodeIncorrect: "Código de registro inválido.",                                                               // 78
    signupCodeRequired: "Se requiere un código de registro.",                                                          // 79
    usernameIsEmail: "El usuario no puede ser una dirección de correo.",                                               // 80
    usernameRequired: "Se quiere nombre de usuario.",                                                                  // 81
    accounts: {                                                                                                        // 84
      "Email already exists.": "El correo ya existe.",                                                                 // 89
      "Email doesn't match the criteria.": "El correo no coincide.",                                                   // 90
      "Invalid login token": "Token de inicio de sesión invalido",                                                     // 91
      "Login forbidden": "Inicio de sesión prohibido",                                                                 // 92
      "Service unknown": "Servicio desconocido",                                                                       // 94
      "Unrecognized options for login request": "Opciones desconocidas para solicitud de inicio de sesión",            // 95
      "User validation failed": "No se ha podido validar el usuario",                                                  // 96
      "Username already exists.": "El usuario ya existe.",                                                             // 97
      "You are not logged in.": "No estas conectado.",                                                                 // 98
      "You've been logged out by the server. Please log in again.": "Has sido desconectado por el servidor. Por favor inicie sesión de nuevo.",
      "Your session has expired. Please log in again.": "Tu sesión ha expirado. Por favor inicie sesión de nuevo.",    // 100
      "Already verified": "Ya ha sido verificada",                                                                     // 101
      "Invalid email or username": "Email o nombre de usuario no validos",                                             // 102
      "Internal server error": "Error interno del servidor",                                                           // 103
      "undefined": "Algo ha ido mal",                                                                                  // 104
      "No matching login attempt found": "Ningún intento de inicio de sesión coincidente se encuentra",                // 107
      "Password is old. Please reset your password.": "Contraseña es vieja. Por favor, resetea la contraseña.",        // 111
      "Incorrect password": "Contraseña inválida.",                                                                    // 115
      "Invalid email": "Email inválida",                                                                               // 116
      "Must be logged in": "Debes ingresar",                                                                           // 117
      "Need to set a username or email": "Tienes que especificar un usuario o un email",                               // 118
      "old password format": "formato viejo de contraseña",                                                            // 119
      "Password may not be empty": "Contraseña no puede quedar vacía",                                                 // 120
      "Signups forbidden": "Registro prohibido",                                                                       // 121
      "Token expired": "Token expirado",                                                                               // 122
      "Token has invalid email address": "Token contiene un email inválido",                                           // 123
      "User has no password set": "Usuario no tiene contraseña",                                                       // 124
      "User not found": "Usuario no encontrado",                                                                       // 125
      "Verify email link expired": "El enlace para verificar el email ha expirado",                                    // 126
      "Verify email link is for unknown address": "El enlace para verificar el email contiene una dirección desconocida",
      "At least 1 digit, 1 lowercase and 1 uppercase": "Almenos tiene que contener 1 numero, 1 miniscula y 1 mayuscula",
      "Please verify your email first. Check the email and follow the link!": "Por favor compruebe su email primero. Siga el link que le ha sido enviado.",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Un nuevo correo te ha sido enviado. Si no ves el correo en tu bandeja comprueba tu carpeta de spam.",
      "Match failed": "No ha habido ninguna coincidencia",                                                             // 133
      "Unknown error": "Error desconocido",                                                                            // 136
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Error, demasiadas peticiones. Por favor no vaya tan rapido. Tienes que esperar almenos 1 segundo antes de provar otra vez."
    }                                                                                                                  // 89
  }                                                                                                                    // 72
};                                                                                                                     // 6
T9n.map("es_ES", es_ES);                                                                                               // 140
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/fa.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var fa;                                                                                                                // 4
fa = {                                                                                                                 // 4
  add: "افزودن",                                                                                                       // 6
  and: "و",                                                                                                            // 7
  back: "برگشت",                                                                                                       // 8
  changePassword: "تعویض گذرواژه",                                                                                     // 9
  choosePassword: "انتخاب یک گذرواژه",                                                                                 // 10
  clickAgree: "با انتخاب ثبت‌نام، شما موافق هستید با",                                                                 // 11
  configure: "پیکربندی",                                                                                               // 12
  createAccount: "ایجاد یک حساب",                                                                                      // 13
  currentPassword: "گذرواژه کنونی",                                                                                    // 14
  dontHaveAnAccount: "یک حساب ندارید؟",                                                                                // 15
  email: "رایانامه",                                                                                                   // 16
  emailAddress: "آدرس رایانامه",                                                                                       // 17
  emailResetLink: "پیوند بازنشانی رایانامه",                                                                           // 18
  forgotPassword: "گذرواژه‌تان را فراموش کرده‌اید؟",                                                                   // 19
  ifYouAlreadyHaveAnAccount: "اگر هم‌اکنون یک حساب دارید",                                                             // 20
  newPassword: "گذرواژه جدید",                                                                                         // 21
  newPasswordAgain: "گذرواژه جدید (تکرار)",                                                                            // 22
  optional: "اختيارى",                                                                                                 // 23
  OR: "یا",                                                                                                            // 24
  password: "گذرواژه",                                                                                                 // 25
  passwordAgain: "گذرواژه (دوباره)",                                                                                   // 26
  privacyPolicy: "حریم خصوصی",                                                                                         // 27
  remove: "حذف",                                                                                                       // 28
  resetYourPassword: "بازنشانی گذرواژه شما",                                                                           // 29
  setPassword: "تنظیم گذرواژه",                                                                                        // 30
  sign: "نشان",                                                                                                        // 31
  signIn: "ورود",                                                                                                      // 32
  signin: "ورود",                                                                                                      // 33
  signOut: "خروج",                                                                                                     // 34
  signUp: "ثبت‌نام",                                                                                                   // 35
  signupCode: "کد ثبت‌نام",                                                                                            // 36
  signUpWithYourEmailAddress: "با آدرس رایانامه‌تان ثبت‌نام کنید",                                                     // 37
  terms: "قوانین استفاده",                                                                                             // 38
  updateYourPassword: "گذرواژه‌تان را به روز کنید",                                                                    // 39
  username: "نام کاربری",                                                                                              // 40
  usernameOrEmail: "نام کاربری یا رایانامه",                                                                           // 41
  "with": "با",                                                                                                        // 42
  info: {                                                                                                              // 45
    emailSent: "رایانامه ارسال شد",                                                                                    // 46
    emailVerified: "رایانامه تایید شد",                                                                                // 47
    passwordChanged: "گذرواژه تغییر کرد",                                                                              // 48
    passwordReset: "گذرواژه بازنشانی شد"                                                                               // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "رایانامه ضروری است.",                                                                              // 53
    minChar: "گذرواژه حداقل ۷ کاراکتر.",                                                                               // 54
    pwdsDontMatch: "گذرواژه‌ها تطابق ندارند",                                                                          // 55
    pwOneDigit: "گذرواژه باید لااقل یک رقم داشته باشد.",                                                               // 56
    pwOneLetter: "گذرواژه یک حرف نیاز دارد.",                                                                          // 57
    signInRequired: "برای انجام آن باید وارد شوید.",                                                                   // 58
    signupCodeIncorrect: "کد ثبت‌نام نادرست است.",                                                                     // 59
    signupCodeRequired: "کد ثبت‌نام ضروری است.",                                                                       // 60
    usernameIsEmail: "نام کاربری نمی‌توان آدرس رایانامه باشد.",                                                        // 61
    usernameRequired: "نام کاربری ضروری است.",                                                                         // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "رایانامه هم‌اکنون وجود دارد.",                                                         // 70
      "Email doesn't match the criteria.": "رایانامه با ضوابط تطابق ندارد.",                                           // 71
      "Invalid login token": "علامت ورود نامعتبر است",                                                                 // 72
      "Login forbidden": "ورود ممنوع است",                                                                             // 73
      "Service unknown": "سرویس ناشناس",                                                                               // 75
      "Unrecognized options for login request": "گزینه‌های نامشخص برای درخواست ورود",                                  // 76
      "User validation failed": "اعتبارسنجی کاربر ناموفق",                                                             // 77
      "Username already exists.": "نام کاربری هم‌اکنون وجود دارد.",                                                    // 78
      "You are not logged in.": "شما وارد نشده‌اید.",                                                                  // 79
      "You've been logged out by the server. Please log in again.": "شما توسط سرور خارج شده‌اید. لطفأ دوباره وارد شوید.",
      "Your session has expired. Please log in again.": "جلسه شما منقضی شده است. لطفا دوباره وارد شوید.",              // 81
      "No matching login attempt found": "تلاش ورود مطابق یافت نشد",                                                   // 85
      "Password is old. Please reset your password.": "گذرواژه قدیمی است. لطفأ گذرواژه‌تان را بازتنظیم کنید.",         // 89
      "Incorrect password": "گذرواژه نادرست",                                                                          // 93
      "Invalid email": "رایانامه نامعتبر",                                                                             // 94
      "Must be logged in": "باید وارد شوید",                                                                           // 95
      "Need to set a username or email": "یک نام کاربری یا ایمیل باید تنظیم شود",                                      // 96
      "old password format": "قالب گذرواژه قدیمی",                                                                     // 97
      "Password may not be empty": "گذرواژه نمی‌تواند خالی باشد",                                                      // 98
      "Signups forbidden": "ثبت‌نام ممنوع",                                                                            // 99
      "Token expired": "علامت رمز منقظی شده است",                                                                      // 100
      "Token has invalid email address": "علامت رمز دارای آدرس رایانامه نامعتبر است",                                  // 101
      "User has no password set": "کاربر گذرواژه‌ای تنظیم نکرده است",                                                  // 102
      "User not found": "کاربر یافت نشد",                                                                              // 103
      "Verify email link expired": "پیوند تایید رایانامه منقضی شده است",                                               // 104
      "Verify email link is for unknown address": "پیوند تایید رایانامه برای آدرس ناشناخته است",                       // 105
      "Match failed": "تطابق ناموفق",                                                                                  // 108
      "Unknown error": "خطای ناشناخته"                                                                                 // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("fa", fa);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/fi.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var fi;                                                                                                                // 4
fi = {                                                                                                                 // 4
  t9Name: 'Finnish',                                                                                                   // 6
  add: "lisää",                                                                                                        // 8
  and: "ja",                                                                                                           // 9
  back: "takaisin",                                                                                                    // 10
  cancel: "Peruuta",                                                                                                   // 11
  changePassword: "Vaihda salasana",                                                                                   // 12
  choosePassword: "Valitse salasana",                                                                                  // 13
  clickAgree: "Klikkaamalla Rekisteröidy, hyväksyt meidän",                                                            // 14
  configure: "Asetukset",                                                                                              // 15
  createAccount: "Luo tili",                                                                                           // 16
  currentPassword: "Nykyinen salasana",                                                                                // 17
  dontHaveAnAccount: "Eikö sinulla ole tiliä?",                                                                        // 18
  email: "Sähköposti",                                                                                                 // 19
  emailAddress: "Sähköpostiosoite",                                                                                    // 20
  emailResetLink: "Lähetä salasanan palautuslinkki sähköpostissa",                                                     // 21
  forgotPassword: "Unohditko salasanasi?",                                                                             // 22
  ifYouAlreadyHaveAnAccount: "Jos sinulla on jo tili",                                                                 // 23
  newPassword: "Uusi salasana",                                                                                        // 24
  newPasswordAgain: "Uusi salasana (uudelleen)",                                                                       // 25
  optional: "Valinnainen",                                                                                             // 26
  OR: "TAI",                                                                                                           // 27
  password: "Salasana",                                                                                                // 28
  passwordAgain: "Salasana (uudelleen)",                                                                               // 29
  privacyPolicy: "Tietosuojakäytäntö",                                                                                 // 30
  remove: "poista",                                                                                                    // 31
  resetYourPassword: "Nollaa salasanasi",                                                                              // 32
  setPassword: "Aseta salasana",                                                                                       // 33
  sign: "Kirjaudu",                                                                                                    // 34
  signIn: "Kirjaudu sisään",                                                                                           // 35
  signin: "kirjaudu sisään",                                                                                           // 36
  signOut: "Kirjaudu ulos",                                                                                            // 37
  signUp: "Rekisteröidy",                                                                                              // 38
  signupCode: "Rekisteröinti koodi",                                                                                   // 39
  signUpWithYourEmailAddress: "Rekisteröidy sähköpostiosoitteellasi",                                                  // 40
  terms: "Käyttöehdot",                                                                                                // 41
  updateYourPassword: "Päivitä salasanasi",                                                                            // 42
  username: "Käyttäjätunnus",                                                                                          // 43
  usernameOrEmail: "Käyttäjätunnus tai sähköposti",                                                                    // 44
  "with": "kanssa",                                                                                                    // 45
  maxAllowedLength: "Maksimi sallittu pituus",                                                                         // 46
  minRequiredLength: "Minimi sallittu pituus",                                                                         // 47
  resendVerificationEmail: "Lähetä sähköposti uudelleen",                                                              // 48
  resendVerificationEmailLink_pre: "Varmistus sähköposti kadonnut?",                                                   // 49
  resendVerificationEmailLink_link: "Lähetä uudelleen",                                                                // 50
  enterPassword: "Kirjoita salasana",                                                                                  // 51
  enterNewPassword: "Kirjoita uusi salasana",                                                                          // 52
  enterEmail: "Kirjoita sähköposti",                                                                                   // 53
  enterUsername: "Kirjoita käyttäjätunnus",                                                                            // 54
  enterUsernameOrEmail: "Kirjoita käyttäjätunnus tai sähköposti",                                                      // 55
  orUse: "Tai käytä",                                                                                                  // 56
  info: {                                                                                                              // 58
    emailSent: "Sähköposti lähetetty",                                                                                 // 59
    emailVerified: "Sähköposti varmistettu",                                                                           // 60
    passwordChanged: "Salasana vaihdettu",                                                                             // 61
    passwordReset: "Salasana nollattu"                                                                                 // 62
  },                                                                                                                   // 59
  alert: {                                                                                                             // 64
    ok: 'Ok',                                                                                                          // 65
    type: {                                                                                                            // 66
      info: 'Huomio',                                                                                                  // 67
      error: 'Virhe',                                                                                                  // 68
      warning: 'Varoitus'                                                                                              // 69
    }                                                                                                                  // 67
  },                                                                                                                   // 65
  error: {                                                                                                             // 71
    emailRequired: "Sähköposti vaaditaan.",                                                                            // 72
    minChar: "7 merkkiä minimi salasana.",                                                                             // 73
    pwdsDontMatch: "Salasanat eivät täsmää",                                                                           // 74
    pwOneDigit: "Salasanassa tulee olla vähintään yksi numero.",                                                       // 75
    pwOneLetter: "Salasana vaatii 1 kirjaimen.",                                                                       // 76
    signInRequired: "Sinun täytyy olla kirjautuneena sisään tehdäksesi tuon.",                                         // 77
    signupCodeIncorrect: "Rekisteröinti koodi on virheellinen.",                                                       // 78
    signupCodeRequired: "Rekisteröinti koodi vaaditaan.",                                                              // 79
    usernameIsEmail: "Käyttäjätunnus ei voi olla sähköpostiosoite.",                                                   // 80
    usernameRequired: "Käyttäjätunnus vaaditaan.",                                                                     // 81
    accounts: {                                                                                                        // 84
      "Email already exists.": "Sähköposti on jo olemassa.",                                                           // 88
      "Email doesn't match the criteria.": "Sähköposti ei täytä kriteeriä.",                                           // 89
      "Invalid login token": "Virheellinen kirjautumis token",                                                         // 90
      "Login forbidden": "Kirjautuminen kielletty",                                                                    // 91
      "Service unknown": "Tuntematon palvelu",                                                                         // 93
      "Unrecognized options for login request": "Tunnistamattomat valinnat kirjautumispyynnössä",                      // 94
      "User validation failed": "Käyttäjän varmistus epäonnistui",                                                     // 95
      "Username already exists.": "Käyttäjänimi on jo olemassa.",                                                      // 96
      "You are not logged in.": "Et ole kirjautuneena sisään.",                                                        // 97
      "You've been logged out by the server. Please log in again.": "Palvelin on kirjannut sinut ulos. Ole hyvä ja kirjaudu uudelleen.",
      "Your session has expired. Please log in again.": "Istuntosi on vanhentunut. Ole hyvä ja kirjaudu uudelleen.",   // 99
      "Already verified": "On jo varmistettu",                                                                         // 100
      "Invalid email or username": "Virheellinen sähköposti tai käyttäjätunnus",                                       // 101
      "Internal server error": "Sisäinen palvelinvirhe",                                                               // 102
      "undefined": "Jotain meni väärin",                                                                               // 103
      "No matching login attempt found": "Ei löytynyt täsmäävää kirjautumisyritystä",                                  // 107
      "Password is old. Please reset your password.": "Salasana on vanha. Ole hyvä ja nollaa salasanasi.",             // 111
      "Incorrect password": "Virheellinen salasana",                                                                   // 115
      "Invalid email": "Virheellinen sähköposti",                                                                      // 116
      "Must be logged in": "Täytyy olla kirjautuneena sisään",                                                         // 117
      "Need to set a username or email": "Tarvitsee määrittää käyttäjätunnus tai sähköposti",                          // 118
      "old password format": "vanha salasana muoto",                                                                   // 119
      "Password may not be empty": "Salasana ei voi olla tyhjä",                                                       // 120
      "Signups forbidden": "Rekisteröityminen kielletty",                                                              // 121
      "Token expired": "Token vanhentui",                                                                              // 122
      "Token has invalid email address": "Token sisältää virheellisen sähköpostiosoitteen",                            // 123
      "User has no password set": "Käyttäjälle ei ole salasanaa määritettynä",                                         // 124
      "User not found": "Käyttäjää ei löyty",                                                                          // 125
      "Verify email link expired": "Varmistus sähköposti linkki on vanhentunut",                                       // 126
      "Verify email link is for unknown address": "Varmistus sähköposti linkki on tuntemattomalle osoitteelle",        // 127
      "At least 1 digit, 1 lowercase and 1 uppercase": "Ainakin 1 numero, 1 pieni ja 1 iso kirjain",                   // 128
      "Please verify your email first. Check the email and follow the link!": "Ole hyvä ja varmista sähköpostisi ensin. Tarkista sähköpostisi ja seuraa linkkiä!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Uusi sähköposti on lähetetty sinulle. Jos sähköposti ei näy saapuneissa, tarkista roskaposti kansio.",
      "Match failed": "Eivät täsmää",                                                                                  // 133
      "Unknown error": "Tuntematon virhe",                                                                             // 136
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Virhe, liian monta pyyntöä. Ole hyvä ja hidasta. Sinun täytyy odottaa 1 sekunti ennenkuin yrität uudelleen."
    }                                                                                                                  // 88
  }                                                                                                                    // 72
};                                                                                                                     // 6
T9n.map("fi", fi);                                                                                                     // 140
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/fr.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var fr;                                                                                                                // 4
fr = {                                                                                                                 // 4
  t9Name: 'Français',                                                                                                  // 6
  add: "Ajouter",                                                                                                      // 8
  and: "et",                                                                                                           // 9
  back: "retour",                                                                                                      // 10
  changePassword: "Modifier le mot de passe",                                                                          // 11
  choosePassword: "Choisir le mot de passe",                                                                           // 12
  clickAgree: "En cliquant sur « S'enregistrer », vous acceptez nos",                                                  // 13
  configure: "Configurer",                                                                                             // 14
  createAccount: "Créer un compte",                                                                                    // 15
  currentPassword: "Mot de passe actuel",                                                                              // 16
  dontHaveAnAccount: "Vous n'avez pas de compte ?",                                                                    // 17
  email: "E-mail",                                                                                                     // 18
  emailAddress: "Adresse e-mail",                                                                                      // 19
  emailResetLink: "Envoyer l'e-mail de réinitialisation",                                                              // 20
  forgotPassword: "Mot de passe oublié ?",                                                                             // 21
  ifYouAlreadyHaveAnAccount: "Si vous avez déjà un compte",                                                            // 22
  newPassword: "Nouveau mot de passe",                                                                                 // 23
  newPasswordAgain: "Confirmer le nouveau mot de passe",                                                               // 24
  optional: "Facultatif",                                                                                              // 25
  OR: "OU",                                                                                                            // 26
  password: "Mot de passe",                                                                                            // 27
  passwordAgain: "Confirmer le mot de passe",                                                                          // 28
  privacyPolicy: "Politique de confidentialité",                                                                       // 29
  remove: "Supprimer",                                                                                                 // 30
  resetYourPassword: "Reinitialiser votre mot de passe",                                                               // 31
  setPassword: "Renseigner le mot de passe",                                                                           // 32
  sign: "S'enregistrer",                                                                                               // 33
  signIn: "Se connecter",                                                                                              // 34
  signin: "se connecter",                                                                                              // 35
  signOut: "Se déconnecter",                                                                                           // 36
  signUp: "S'enregistrer",                                                                                             // 37
  signupCode: "Code d'inscription",                                                                                    // 38
  signUpWithYourEmailAddress: "S'enregistrer avec votre adresse e-mail",                                               // 39
  terms: "Conditions d'utilisation",                                                                                   // 40
  updateYourPassword: "Mettre à jour le mot de passe",                                                                 // 41
  username: "Nom d'utilisateur",                                                                                       // 42
  usernameOrEmail: "Nom d'utilisateur ou adresse e-mail",                                                              // 43
  "with": "avec",                                                                                                      // 44
  "Verification email lost?": "Vous n'avez pas reçu votre email de vérification?",                                     // 46
  "Send again": "Recevoir un nouvel email",                                                                            // 47
  "Send the verification email again": "Recevoir un nouvel email de vérification",                                     // 48
  "Send email again": "Renvoyer un email",                                                                             // 49
  "Minimum required length: 6": "Veuillez entrer au moins 6 caractères",                                               // 50
  "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Un nouvel email vient de vous être envoyé. Si vous ne le trouvez pas dans votre boite de réception, vérifiez dans vos spams.",
  "Required Field": "Ce champ est obligatoire",                                                                        // 52
  "Successful Registration! Please check your email and follow the instructions.": "Votre compte est enregistré. Vous allez recevoir un email contenant les instructions pour valider votre compte",
  info: {                                                                                                              // 55
    emailSent: "E-mail envoyé",                                                                                        // 56
    emailVerified: "Adresse e-mail verifiée",                                                                          // 57
    passwordChanged: "Mot de passe modifié",                                                                           // 58
    passwordReset: "Mot de passe réinitialisé",                                                                        // 59
    emailSent: "L'email est envoyé",                                                                                   // 60
    emailVerified: "L'email est vérifié",                                                                              // 61
    passwordChanged: "Le mot de passe a été modifié",                                                                  // 62
    passwordReset: "Le mot de passe a été mis à jour"                                                                  // 63
  },                                                                                                                   // 56
  error: {                                                                                                             // 66
    emailRequired: "Une adresse e-mail est requise.",                                                                  // 67
    minChar: "Votre mot de passe doit contenir au moins 7 caractères.",                                                // 68
    pwdsDontMatch: "Les mots de passe ne correspondent pas",                                                           // 69
    pwOneDigit: "Votre mot de passe doit contenir au moins un chiffre.",                                               // 70
    pwOneLetter: "Votre mot de passe doit contenir au moins une lettre.",                                              // 71
    signInRequired: "Vous devez être connecté pour continuer.",                                                        // 72
    signupCodeIncorrect: "Le code d'enregistrement est incorrect.",                                                    // 73
    signupCodeRequired: "Un code d'inscription est requis.",                                                           // 74
    usernameIsEmail: "Le nom d'utilisateur ne peut être le même que l'adresse email.",                                 // 75
    usernameRequired: "Un nom d'utilisateur est requis.",                                                              // 76
    accounts: {                                                                                                        // 79
      "Email already exists.": "Adresse e-mail déjà utilisée.",                                                        // 84
      "Email doesn't match the criteria.": "L'adresse e-mail ne correspond pas aux critères.",                         // 85
      "Invalid login token": "Jeton d'authentification invalide",                                                      // 86
      "Login forbidden": "Votre identifiant ou votre mot de passe est incorrect",                                      // 87
      "Service unknown": "Service inconnu",                                                                            // 89
      "Unrecognized options for login request": "Options inconnues pour la requête d'authentification",                // 90
      "User validation failed": "Échec de la validation de l'utilisateur",                                             // 91
      "Username already exists.": "Nom d'utilisateur déjà utilisé.",                                                   // 92
      "You are not logged in.": "Vous n'êtes pas connecté.",                                                           // 93
      "You've been logged out by the server. Please log in again.": "Vous avez été déconnecté par le serveur. Veuillez vous reconnecter.",
      "Your session has expired. Please log in again.": "Votre session a expiré. Veuillez vous reconnecter.",          // 95
      "No matching login attempt found": "Aucune tentative d'authentification ne correspond",                          // 99
      "Password is old. Please reset your password.": "Votre mot de passe est trop ancien. Veuillez le modifier.",     // 103
      "Incorrect password": "Mot de passe incorrect",                                                                  // 107
      "Invalid email": "Adresse e-mail invalide",                                                                      // 108
      "Must be logged in": "Vous devez être connecté",                                                                 // 109
      "Need to set a username or email": "Vous devez renseigner un nom d'utilisateur ou une adresse e-mail",           // 110
      "old password format": "Ancien format de mot de passe",                                                          // 111
      "Password may not be empty": "Le mot de passe ne peut être vide",                                                // 112
      "Signups forbidden": "Vous ne pouvez pas créer de compte",                                                       // 113
      "Token expired": "Jeton expiré",                                                                                 // 114
      "Token has invalid email address": "Le jeton contient une adresse e-mail invalide",                              // 115
      "User has no password set": "L'utilisateur n'a pas de mot de passe",                                             // 116
      "User not found": "Utilisateur inconnu",                                                                         // 117
      "Verify email link expired": "Lien de vérification d'e-mail expiré",                                             // 118
      "Please verify your email first. Check the email and follow the link!": "Votre email n'est pas validé. Merci de cliquer sur le lien que vous avez reçu",
      "Verify email link is for unknown address": "Le lien de vérification d'e-mail réfère à une adresse inconnue",    // 120
      "Match failed": "La correspondance a échoué",                                                                    // 123
      "Unknown error": "Erreur inconnue"                                                                               // 126
    }                                                                                                                  // 84
  }                                                                                                                    // 67
};                                                                                                                     // 6
T9n.map("fr", fr);                                                                                                     // 129
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/he.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var he;                                                                                                                // 5
he = {                                                                                                                 // 5
  add: "הוסף",                                                                                                         // 7
  and: "ו",                                                                                                            // 8
  back: "חזרה",                                                                                                        // 9
  changePassword: "שינוי סיסמא",                                                                                       // 10
  choosePassword: "בחירת סיסמא",                                                                                       // 11
  clickAgree: "על ידי לחיצה על הירשם, הינך מסכים",                                                                     // 12
  configure: "הגדרות",                                                                                                 // 13
  createAccount: "הוספת חשבון",                                                                                        // 14
  currentPassword: "סיסמא נוכחית",                                                                                     // 15
  dontHaveAnAccount: "אין לך חשבון?",                                                                                  // 16
  email: "דוא\"ל",                                                                                                     // 17
  emailAddress: "דוא\"ל",                                                                                              // 18
  emailResetLink: "שלח קישור לאיפוס סיסמא",                                                                            // 19
  forgotPassword: "שכחת סיסמא?",                                                                                       // 20
  ifYouAlreadyHaveAnAccount: "אם יש לך חשבון",                                                                         // 21
  newPassword: "סיסמא חדשה",                                                                                           // 22
  newPasswordAgain: "סיסמא חדשה (שוב)",                                                                                // 23
  optional: "רשות",                                                                                                    // 24
  OR: "או",                                                                                                            // 25
  password: "סיסמא",                                                                                                   // 26
  passwordAgain: "סיסמא (שוב)",                                                                                        // 27
  privacyPolicy: "למדיניות הפרטיות",                                                                                   // 28
  remove: "הסרה",                                                                                                      // 29
  resetYourPassword: "איפוס סיסמא",                                                                                    // 30
  setPassword: "עדכון סיסמא",                                                                                          // 31
  signIn: "כניסה",                                                                                                     // 33
  signin: "כניסה",                                                                                                     // 34
  signOut: "יציאה",                                                                                                    // 35
  signUp: "הרשמה לחשבון",                                                                                              // 36
  signupCode: "קוד הרשמה",                                                                                             // 37
  signUpWithYourEmailAddress: "הירשם באמצעות הדוא\"ל",                                                                 // 38
  terms: "לתנאי השימוש",                                                                                               // 39
  updateYourPassword: "עדכון סיסמא",                                                                                   // 40
  username: "שם משתמש",                                                                                                // 41
  usernameOrEmail: "שם משמש או דוא\"ל",                                                                                // 42
  "with": "עם",                                                                                                        // 43
  info: {                                                                                                              // 46
    emailSent: "נשלחה הודעה לדוא\"ל",                                                                                  // 47
    emailVerified: "כתובת הדוא\"ל וודאה בהצלחה",                                                                       // 48
    passwordChanged: "סיסמתך שונתה בהצלחה",                                                                            // 49
    passwordReset: "סיסמתך אופסה בהצלחה"                                                                               // 50
  },                                                                                                                   // 47
  error: {                                                                                                             // 53
    emailRequired: "חובה להזין כתובת דוא\"ל",                                                                          // 54
    minChar: "חובה להזין סיסמא בעלת 7 תווים לפחות.",                                                                   // 55
    pwdsDontMatch: "הסיסמאות אינן זהות.",                                                                              // 56
    pwOneDigit: "הסיסמא חייבת לכלול ספרה אחת לפחות.",                                                                  // 57
    pwOneLetter: "הסיסמא חייבת לכלול אות אחת לפחות.",                                                                  // 58
    signInRequired: "חובה להיכנס למערכת כדי לבצע פעולה זו.",                                                           // 59
    signupCodeIncorrect: "קוד ההרשמה שגוי.",                                                                           // 60
    signupCodeRequired: "חובה להזין את קוד ההרשמה.",                                                                   // 61
    usernameIsEmail: "של המשתמש לא יכול להיות כתובת דוא\"ל.",                                                          // 62
    usernameRequired: "חובה להזין שם משתמש.",                                                                          // 63
    accounts: {                                                                                                        // 66
      "Email already exists.": "הדוא\"ל כבר רשום לחשבון.",                                                             // 71
      "Email doesn't match the criteria.": "הדוא\"ל לא מקיים את הקריטריונים.",                                         // 72
      "Invalid login token": "Token כניסה שגוי",                                                                       // 73
      "Login forbidden": "הכניסה נאסרה",                                                                               // 74
      "Service unknown": "Service לא ידוע",                                                                            // 76
      "Unrecognized options for login request": "נסיון הכניסה כלל אופציות לא מזוהות",                                  // 77
      "User validation failed": "אימות המשתמש נכשל",                                                                   // 78
      "Username already exists.": "שם המשתמש כבר קיים.",                                                               // 79
      "You are not logged in.": "לא נכנסת לחשבון.",                                                                    // 80
      "You've been logged out by the server. Please log in again.": "השרת הוציא אותך מהמערכת. נא להיכנס לחשבונך שוב.",
      "Your session has expired. Please log in again.": "ה-session שלך פג תוקף. נא להיכנס לחשבונך שוב.",               // 82
      "No matching login attempt found": "לא נמצא נסיון כניסה מתאים",                                                  // 86
      "Password is old. Please reset your password.": "סיסמתך ישנה. נא להחליך אותה.",                                  // 90
      "Incorrect password": "סיסמא שגויה",                                                                             // 94
      "Invalid email": "דוא\"ל שגוי",                                                                                  // 95
      "Must be logged in": "חובה להיכנס למערכת כדי לבצע פעולה זו.",                                                    // 96
      "Need to set a username or email": "חובה להגדיר שם משתמש או דוא\"ל",                                             // 97
      "old password format": "פורמט סיסמא ישן",                                                                        // 98
      "Password may not be empty": "הסיסמא לא יכולה להיות ריקה",                                                       // 99
      "Signups forbidden": "אסור להירשם",                                                                              // 100
      "Token expired": "ה-token פג תוקף",                                                                              // 101
      "Token has invalid email address": "ה-token מכיל כתובת דוא\"ל שגוייה",                                           // 102
      "User has no password set": "למשתמש אין סיסמא",                                                                  // 103
      "User not found": "המשתמש לא נמצא",                                                                              // 104
      "Verify email link expired": "קישור וידוי הדוא\"ל פג תוקף",                                                      // 105
      "Verify email link is for unknown address": "קישור וידוי הדוא\"ל הוא לכתובת לא ידועה",                           // 106
      "Match failed": "ההתאמה נכשלה",                                                                                  // 109
      "Unknown error": "שגיאה לא ידועה"                                                                                // 112
    }                                                                                                                  // 71
  }                                                                                                                    // 54
};                                                                                                                     // 7
T9n.map("he", he);                                                                                                     // 115
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/hr.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var hr;                                                                                                                // 4
hr = {                                                                                                                 // 4
  add: "dodaj",                                                                                                        // 6
  and: "i",                                                                                                            // 7
  back: "nazad",                                                                                                       // 8
  changePassword: "Promjeni zaporku",                                                                                  // 9
  choosePassword: "Izaberi zaporku",                                                                                   // 10
  clickAgree: "Klikom na Registracija, prihvatate naše",                                                               // 11
  configure: "Podesi",                                                                                                 // 12
  createAccount: "Napravite račun",                                                                                    // 13
  currentPassword: "Trenutna zaporka",                                                                                 // 14
  dontHaveAnAccount: "Vi nemate račun?",                                                                               // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Email adresa",                                                                                        // 17
  emailResetLink: "Email reset link",                                                                                  // 18
  forgotPassword: "Zaboravili ste zaporku?",                                                                           // 19
  ifYouAlreadyHaveAnAccount: "Ako već imate račun",                                                                    // 20
  newPassword: "Nova zaporka",                                                                                         // 21
  newPasswordAgain: "Nova zaporka (ponovno)",                                                                          // 22
  optional: "neobavezno",                                                                                              // 23
  OR: "ili",                                                                                                           // 24
  password: "Zaporka",                                                                                                 // 25
  passwordAgain: "Zaporka (ponovno)",                                                                                  // 26
  privacyPolicy: "Izjava o privatnosti",                                                                               // 27
  remove: "ukloni",                                                                                                    // 28
  resetYourPassword: "Resetirajte",                                                                                    // 29
  setPassword: "Postavite zaporku",                                                                                    // 30
  sign: "Prijava",                                                                                                     // 31
  signIn: "Prijavi se",                                                                                                // 32
  signin: "prijavi se",                                                                                                // 33
  signOut: "Odjavi se",                                                                                                // 34
  signUp: "Registracija",                                                                                              // 35
  signupCode: "Registracijski kod",                                                                                    // 36
  signUpWithYourEmailAddress: "Registrirajte se sa vašom email adresom",                                               // 37
  terms: "Uslovi korištenja",                                                                                          // 38
  updateYourPassword: "Ažurirajte lozinku",                                                                            // 39
  username: "Korisničko ime",                                                                                          // 40
  usernameOrEmail: "Korisničko ime ili lozinka",                                                                       // 41
  "with": "sa",                                                                                                        // 42
  info: {                                                                                                              // 45
    emailSent: "Email je poslan",                                                                                      // 46
    emailVerified: "Email je verificiran",                                                                             // 47
    passwordChanged: "Zaproka promjenjena",                                                                            // 48
    passwordReset: "Zaporka resetirana"                                                                                // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email je potreban.",                                                                               // 53
    minChar: "Zaporka mora sadržavati više od 7 znakova.",                                                             // 54
    pwdsDontMatch: "Zaporke se ne poklapaju.",                                                                         // 55
    pwOneDigit: "Zaporka mora sadržavati barem jednu brojku.",                                                         // 56
    pwOneLetter: "Zaporka mora sadržavati barem jedno slovo.",                                                         // 57
    signInRequired: "Morate biti prijavljeni za to.",                                                                  // 58
    signupCodeIncorrect: "Registracijski kod je netočan.",                                                             // 59
    signupCodeRequired: "Registracijski kod je potreban.",                                                             // 60
    usernameIsEmail: "Korisničko ime ne može biti email.",                                                             // 61
    usernameRequired: "Korisničko ime je potrebno.",                                                                   // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Email već postoji.",                                                                   // 70
      "Email doesn't match the criteria.": "Email ne zadovoljava kriterij.",                                           // 71
      "Invalid login token": "Nevažeći  token za prijavu",                                                             // 72
      "Login forbidden": "Prijava zabranjena",                                                                         // 73
      "Service unknown": "Servis nepoznat",                                                                            // 75
      "Unrecognized options for login request": "Neprepoznate opcije zahtjeva za prijavu",                             // 76
      "User validation failed": "Provjera valjanosti za korisnika neuspješna.",                                        // 77
      "Username already exists.": "Korisnik već postoji.",                                                             // 78
      "You are not logged in.": "Niste prijavljeni.",                                                                  // 79
      "You've been logged out by the server. Please log in again.": "Odjavljeni ste sa servera. Molimo Vas ponovno se prijavite.",
      "Your session has expired. Please log in again.": "Vaša sesija je istekla. Molimo prijavite se ponovno.",        // 81
      "No matching login attempt found": "Pokušaj prijave se ne podudara sa podatcima u bazi.",                        // 85
      "Password is old. Please reset your password.": "Zaporka je stara. Molimo resetujte zaporku.",                   // 89
      "Incorrect password": "Netočna zaporka",                                                                         // 93
      "Invalid email": "Nevažeći email",                                                                               // 94
      "Must be logged in": "Morate biti prijavljeni",                                                                  // 95
      "Need to set a username or email": "Morate postaviti korisničko ime ili email",                                  // 96
      "old password format": "stari format zaporke",                                                                   // 97
      "Password may not be empty": "Zaporka ne može biti prazna",                                                      // 98
      "Signups forbidden": "Prijave zabranjenje",                                                                      // 99
      "Token expired": "Token je istekao",                                                                             // 100
      "Token has invalid email address": "Token ima nevažeću email adresu",                                            // 101
      "User has no password set": "Korisnik nema postavljenu zaporku",                                                 // 102
      "User not found": "Korisnik nije pronađen",                                                                      // 103
      "Verify email link expired": "Link za verifikaciju emaila je istekao",                                           // 104
      "Verify email link is for unknown address": "Link za verifikaciju emaila je za nepoznatu adresu",                // 105
      "Match failed": "Usporedba neuspjela",                                                                           // 108
      "Unknown error": "Nepoznata pogreška"                                                                            // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("hr", hr);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/hu.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var hu;                                                                                                                // 4
hu = {                                                                                                                 // 4
  add: "hozzáadás",                                                                                                    // 6
  and: "és",                                                                                                           // 7
  back: "vissza",                                                                                                      // 8
  changePassword: "Jelszó megváltoztatása",                                                                            // 9
  choosePassword: "Válassz egy jelszót",                                                                               // 10
  clickAgree: "A regisztráció gombra kattintva egyetértesz a mi",                                                      // 11
  configure: "Beállítás",                                                                                              // 12
  createAccount: "Felhasználó létrehozása",                                                                            // 13
  currentPassword: "Jelenlegi jelszó",                                                                                 // 14
  dontHaveAnAccount: "Nincs még felhasználód?",                                                                        // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Email cím",                                                                                           // 17
  emailResetLink: "Visszaállító link küldése",                                                                         // 18
  forgotPassword: "Elfelejtetted a jelszavadat?",                                                                      // 19
  ifYouAlreadyHaveAnAccount: "Ha már van felhasználód, ",                                                              // 20
  newPassword: "Új jelszó",                                                                                            // 21
  newPasswordAgain: "Új jelszó (ismét)",                                                                               // 22
  optional: "Opcionális",                                                                                              // 23
  OR: "VAGY",                                                                                                          // 24
  password: "Jelszó",                                                                                                  // 25
  passwordAgain: "Jelszó (ismét)",                                                                                     // 26
  privacyPolicy: "Adatvédelmi irányelvek",                                                                             // 27
  remove: "eltávolítás",                                                                                               // 28
  resetYourPassword: "Jelszó visszaállítása",                                                                          // 29
  setPassword: "Jelszó beállítása",                                                                                    // 30
  sign: "Bejelentkezés",                                                                                               // 31
  signIn: "Bejelentkezés",                                                                                             // 32
  signin: "jelentkezz be",                                                                                             // 33
  signOut: "Kijelentkezés",                                                                                            // 34
  signUp: "Regisztráció",                                                                                              // 35
  signupCode: "Regisztrációs kód",                                                                                     // 36
  signUpWithYourEmailAddress: "Regisztráció email címmel",                                                             // 37
  terms: "Használati feltételek",                                                                                      // 38
  updateYourPassword: "Jelszó módosítása",                                                                             // 39
  username: "Felhasználónév",                                                                                          // 40
  usernameOrEmail: "Felhasználónév vagy email",                                                                        // 41
  "with": "-",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "Email elküldve",                                                                                       // 46
    emailVerified: "Email cím igazolva",                                                                               // 47
    passwordChanged: "Jelszó megváltoztatva",                                                                          // 48
    passwordReset: "Jelszó visszaállítva"                                                                              // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email cím megadása kötelező.",                                                                     // 53
    minChar: "A jelszónak legalább 7 karakter hoszúnak kell lennie.",                                                  // 54
    pwdsDontMatch: "A jelszavak nem egyeznek",                                                                         // 55
    pwOneDigit: "A jelszónak legalább egy számjegyet tartalmaznia kell.",                                              // 56
    pwOneLetter: "A jelszónak legalább egy betűt tartalmaznia kell.",                                                  // 57
    signInRequired: "A művelet végrehajtásához be kell jelentkezned.",                                                 // 58
    signupCodeIncorrect: "A regisztrációs kód hibás.",                                                                 // 59
    signupCodeRequired: "A regisztrációs kód megadása kötelező.",                                                      // 60
    usernameIsEmail: "A felhasználónév nem lehet egy email cím.",                                                      // 61
    usernameRequired: "Felhasználónév megadása kötelező.",                                                             // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "A megadott email cím már létezik.",                                                    // 70
      "Email doesn't match the criteria.": "Email cím nem felel meg a feltételeknek.",                                 // 71
      "Invalid login token": "Érvénytelen belépési token",                                                             // 72
      "Login forbidden": "Belépés megtagadva",                                                                         // 73
      "Service unknown": "Ismeretlen szolgáltatás",                                                                    // 75
      "Unrecognized options for login request": "Ismeretlen beállítások a belépési kérelemhez",                        // 76
      "User validation failed": "Felhasználó azonosítás sikertelen",                                                   // 77
      "Username already exists.": "A felhasználónév már létezik.",                                                     // 78
      "You are not logged in.": "Nem vagy bejelentkezve.",                                                             // 79
      "You've been logged out by the server. Please log in again.": "A szerver kijelentkeztetett. Kérjük, jelentkezz be újra.",
      "Your session has expired. Please log in again.": "A munkamenet lejárt. Kérjük, jelentkezz be újra.",            // 81
      "No matching login attempt found": "Nem található megegyező belépési próbálkozás",                               // 85
      "Password is old. Please reset your password.": "A jelszó túl régi. Kérjük, változtasd meg a jelszavad.",        // 89
      "Incorrect password": "Helytelen jelszó",                                                                        // 93
      "Invalid email": "Érvénytelen email cím",                                                                        // 94
      "Must be logged in": "A művelet végrehajtásához bejelentkezés szükséges",                                        // 95
      "Need to set a username or email": "Felhasználónév vagy email cím beállítása kötelező",                          // 96
      "old password format": "régi jelszó formátum",                                                                   // 97
      "Password may not be empty": "A jelszó nem lehet üres",                                                          // 98
      "Signups forbidden": "Regisztráció megtagadva",                                                                  // 99
      "Token expired": "Token lejárt",                                                                                 // 100
      "Token has invalid email address": "A token érvénytelen email címet tartalmaz",                                  // 101
      "User has no password set": "A felhasználóhoz nincs jelszó beállítva",                                           // 102
      "User not found": "Felhasználó nem található",                                                                   // 103
      "Verify email link expired": "Igazoló email link lejárt",                                                        // 104
      "Verify email link is for unknown address": "Az igazoló email link ismeretlen címhez tartozik",                  // 105
      "Match failed": "Megegyeztetés sikertelen",                                                                      // 108
      "Unknown error": "Ismeretlen hiba"                                                                               // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("hu", hu);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/id.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var id;                                                                                                                // 4
id = {                                                                                                                 // 4
  add: "tambah",                                                                                                       // 6
  and: "dan",                                                                                                          // 7
  back: "kembali",                                                                                                     // 8
  changePassword: "Ganti Password",                                                                                    // 9
  choosePassword: "Masukkan Password",                                                                                 // 10
  clickAgree: "Dengan Anda mendaftar, Anda setuju dengan",                                                             // 11
  configure: "Mengaturkan",                                                                                            // 12
  createAccount: "Buat Account",                                                                                       // 13
  currentPassword: "Password Anda Saat Ini",                                                                           // 14
  dontHaveAnAccount: "Tidak punya account?",                                                                           // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Alamat email",                                                                                        // 17
  emailResetLink: "Link untuk email reset",                                                                            // 18
  forgotPassword: "Lupa password?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Jika Anda sudah punya akun",                                                             // 20
  newPassword: "Password Baru",                                                                                        // 21
  newPasswordAgain: "Password Baru (ulang)",                                                                           // 22
  optional: "Opsional",                                                                                                // 23
  OR: "ATAU",                                                                                                          // 24
  password: "Password",                                                                                                // 25
  passwordAgain: "Password (ulang)",                                                                                   // 26
  privacyPolicy: "Kebijakan Privasi",                                                                                  // 27
  remove: "hapus",                                                                                                     // 28
  resetYourPassword: "Reset password anda",                                                                            // 29
  setPassword: "Masukkan Password",                                                                                    // 30
  sign: "Sign",                                                                                                        // 31
  signIn: "Sign In",                                                                                                   // 32
  signin: "sign in",                                                                                                   // 33
  signOut: "Sign Out",                                                                                                 // 34
  signUp: "Mendaftar",                                                                                                 // 35
  signupCode: "Kode Registrasi",                                                                                       // 36
  signUpWithYourEmailAddress: "Mendaftar dengan alamat email Anda",                                                    // 37
  terms: "Persyaratan Layanan",                                                                                        // 38
  updateYourPassword: "Perbarui password Anda",                                                                        // 39
  username: "Username",                                                                                                // 40
  usernameOrEmail: "Username atau email",                                                                              // 41
  "with": "dengan",                                                                                                    // 42
  info: {                                                                                                              // 45
    emailSent: "Email terkirim",                                                                                       // 46
    emailVerified: "Email diverifikasi",                                                                               // 47
    passwordChanged: "Password terganti",                                                                              // 48
    passwordReset: "Password direset"                                                                                  // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Alamat email dibutuhkan.",                                                                         // 53
    minChar: "Minimum password 7 karakter.",                                                                           // 54
    pwdsDontMatch: "Password yang diulang tidak sama.",                                                                // 55
    pwOneDigit: "Password harus ada minimum 1 angka.",                                                                 // 56
    pwOneLetter: "Password harus ada minimum 1 huruf.",                                                                // 57
    signInRequired: "Anda harus sign in untuk melakukan itu.",                                                         // 58
    signupCodeIncorrect: "Kode registrasi salah.",                                                                     // 59
    signupCodeRequired: "Kode registrasi dibutuhkan.",                                                                 // 60
    usernameIsEmail: "Username Anda tidak bisa sama dengan email address.",                                            // 61
    usernameRequired: "Username dibutuhkan.",                                                                          // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Alamat email sudah dipakai.",                                                          // 70
      "Email doesn't match the criteria.": "Alamat email tidak sesuai dengan kriteria.",                               // 71
      "Invalid login token": "Login token tidak valid",                                                                // 72
      "Login forbidden": "Login dilarang",                                                                             // 73
      "Service unknown": "Layanan unknown",                                                                            // 75
      "Unrecognized options for login request": "Options tidak tersedia untuk permintaan login",                       // 76
      "User validation failed": "Validasi user gagal",                                                                 // 77
      "Username already exists.": "Username sudah dipakai.",                                                           // 78
      "You are not logged in.": "Anda belum login.",                                                                   // 79
      "You've been logged out by the server. Please log in again.": "Anda belum dilogout oleh server. Silahkan coba login lagi.",
      "Your session has expired. Please log in again.": "Session Anda telah kadaluarsa. Silahkan coba login lagi.",    // 81
      "No matching login attempt found": "Usaha login tidak ditemukan.",                                               // 85
      "Password is old. Please reset your password.": "Password Anda terlalu tua. Silahkan ganti password Anda.",      // 89
      "Incorrect password": "Password salah",                                                                          // 93
      "Invalid email": "Alamat email tidak valid",                                                                     // 94
      "Must be logged in": "Anda harus login",                                                                         // 95
      "Need to set a username or email": "Anda harus masukkan username atau email",                                    // 96
      "old password format": "format password lama",                                                                   // 97
      "Password may not be empty": "Password tidak boleh kosong",                                                      // 98
      "Signups forbidden": "Signup dilarang",                                                                          // 99
      "Token expired": "Token telah kadaluarsa",                                                                       // 100
      "Token has invalid email address": "Token memberikan alamat email yang tidak valid",                             // 101
      "User has no password set": "User belum memasukkan password",                                                    // 102
      "User not found": "User tidak ditemukan",                                                                        // 103
      "Verify email link expired": "Link untuk verifikasi alamat email telah kadaluarsa",                              // 104
      "Verify email link is for unknown address": "Link untuk verifikasi alamat email memberikan alamat email yang tidak dikenalkan",
      "Match failed": "Mencocokan gagal",                                                                              // 108
      "Unknown error": "Error tidak dikenalkan"                                                                        // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("id", id);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/it.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var it;                                                                                                                // 4
it = {                                                                                                                 // 4
  t9Name: 'Italiano',                                                                                                  // 6
  add: "aggiungi",                                                                                                     // 8
  and: "e",                                                                                                            // 9
  back: "indietro",                                                                                                    // 10
  changePassword: "Cambia Password",                                                                                   // 11
  choosePassword: "Scegli una Password",                                                                               // 12
  clickAgree: "Cliccando Registrati, accetti la nostra",                                                               // 13
  configure: "Configura",                                                                                              // 14
  createAccount: "Crea un Account",                                                                                    // 15
  currentPassword: "Password Corrente",                                                                                // 16
  dontHaveAnAccount: "Non hai un account?",                                                                            // 17
  email: "Email",                                                                                                      // 18
  emailAddress: "Indirizzo Email",                                                                                     // 19
  emailResetLink: "Invia Link di Reset",                                                                               // 20
  forgotPassword: "Hai dimenticato la password?",                                                                      // 21
  ifYouAlreadyHaveAnAccount: "Se hai già un account",                                                                  // 22
  newPassword: "Nuova Password",                                                                                       // 23
  newPasswordAgain: "Nuova Password (di nuovo)",                                                                       // 24
  optional: "Opzionale",                                                                                               // 25
  OR: "OPPURE",                                                                                                        // 26
  password: "Password",                                                                                                // 27
  passwordAgain: "Password (di nuovo)",                                                                                // 28
  privacyPolicy: "Privacy Policy",                                                                                     // 29
  remove: "rimuovi",                                                                                                   // 30
  resetYourPassword: "Reimposta la password",                                                                          // 31
  setPassword: "Imposta Password",                                                                                     // 32
  sign: "Accedi",                                                                                                      // 33
  signIn: "Accedi",                                                                                                    // 34
  signin: "accedi",                                                                                                    // 35
  signOut: "Esci",                                                                                                     // 36
  signUp: "Registrati",                                                                                                // 37
  signupCode: "Codice di Registrazione",                                                                               // 38
  signUpWithYourEmailAddress: "Registrati con il tuo indirizzo email",                                                 // 39
  terms: "Termini di Servizio",                                                                                        // 40
  updateYourPassword: "Aggiorna la password",                                                                          // 41
  username: "Username",                                                                                                // 42
  usernameOrEmail: "Nome utente o email",                                                                              // 43
  "with": "con",                                                                                                       // 44
  "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Ti è stata inviata una nuova email. Se non trovi l' email nella tua posta in arrivo controllate che non sia stata spostata nella cartella SPAM.",
  "Already verified": "Gi\à verificato",                                                                               // 47
  "At least 1 digit, 1 lowercase and 1 uppercase": "Almeno 1 numero, 1 carattere minuscolo e 1 maiuscolo",             // 48
  "Invalid email": "Email non valida",                                                                                 // 49
  "Please verify your email first. Check the email and follow the link!": "Per favore, verifica prima la tua email. Controlla la tua email e segui il collegamento che ti è stato inviato.",
  "Required Field": "Campo richiesto",                                                                                 // 51
  "Send again": "Invia di nuovo",                                                                                      // 52
  "Send email again": "Invia di nuovo l' email",                                                                       // 53
  "Send the verification email again": "Invia di nuovo l' email di verifica",                                          // 54
  "Verification email lost?": "Hai smarrito l' email di verifica?",                                                    // 55
  info: {                                                                                                              // 57
    emailSent: "Email inviata",                                                                                        // 58
    emailVerified: "Email verificata",                                                                                 // 59
    passwordChanged: "Password cambiata",                                                                              // 60
    passwordReset: "Password reimpostata"                                                                              // 61
  },                                                                                                                   // 58
  error: {                                                                                                             // 63
    emailRequired: "L'Email è obbligatoria.",                                                                          // 64
    minChar: "La Password deve essere di almeno 7 caratteri.",                                                         // 65
    pwdsDontMatch: "Le Password non corrispondono",                                                                    // 66
    pwOneDigit: "La Password deve contenere almeno un numero.",                                                        // 67
    pwOneLetter: "La Password deve contenere 1 lettera.",                                                              // 68
    signInRequired: "Per fare questo devi accedere.",                                                                  // 69
    signupCodeIncorrect: "Codice di Registrazione errato.",                                                            // 70
    signupCodeRequired: "Il Codice di Registrazione è obbligatorio.",                                                  // 71
    usernameIsEmail: "Il Nome Utente non può essere un indirizzo email.",                                              // 72
    usernameRequired: "Il Nome utente è obbligatorio.",                                                                // 73
    accounts: {                                                                                                        // 75
      "Email already exists.": "Indirizzo email già esistente.",                                                       // 80
      "Email doesn't match the criteria.": "L'indirizzo email non soddisfa i requisiti.",                              // 81
      "Invalid login token": "Codice di accesso non valido",                                                           // 82
      "Login forbidden": "Accesso non consentito",                                                                     // 83
      "Service unknown": "Servizio sconosciuto",                                                                       // 85
      "Unrecognized options for login request": "Opzioni per la richiesta di accesso non ricunosciute",                // 86
      "User validation failed": "Validazione utente fallita",                                                          // 87
      "Username already exists.": "Nome utente già esistente.",                                                        // 88
      "You are not logged in.": "Non hai effettuato l'accesso.",                                                       // 89
      "You've been logged out by the server. Please log in again.": "Sei stato disconnesso dal server. Per favore accedi di nuovo.",
      "Your session has expired. Please log in again.": "La tua sessione è scaduta. Per favore accedi di nuovo.",      // 91
      "No matching login attempt found": "Tentativo di accesso corrispondente non trovato",                            // 94
      "Password is old. Please reset your password.": "La password è vecchia. Per favore reimposta la tua password.",  // 97
      "Incorrect password": "Password non corretta",                                                                   // 100
      "Must be logged in": "Devi aver eseguito l'accesso",                                                             // 101
      "Need to set a username or email": "È necessario specificare un nome utente o un indirizzo email",               // 102
      "old password format": "vecchio formato password",                                                               // 103
      "Password may not be empty": "La password non può essere vuota",                                                 // 104
      "Signups forbidden": "Registrazioni non consentite",                                                             // 105
      "Token expired": "Codice scaduto",                                                                               // 106
      "Token has invalid email address": "Il codice ha un indirizzo email non valido",                                 // 107
      "User has no password set": "L'utente non ha una password impostata",                                            // 108
      "User not found": "Utente non trovato",                                                                          // 109
      "Verify email link expired": "Link per la verifica dell'email scaduto",                                          // 110
      "Verify email link is for unknown address": "Il link per la verifica dell'email fa riferimento ad un indirizzo sconosciuto",
      "Match failed": "Riscontro fallito",                                                                             // 114
      "Unknown error": "Errore Sconosciuto"                                                                            // 117
    }                                                                                                                  // 80
  }                                                                                                                    // 64
};                                                                                                                     // 6
T9n.map("it", it);                                                                                                     // 119
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ja.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ja;                                                                                                                // 4
ja = {                                                                                                                 // 4
  t9Name: '日本語',                                                                                                       // 6
  add: "アカウント連携：",                                                                                                     // 8
  and: "と",                                                                                                            // 9
  back: "戻る",                                                                                                          // 10
  changePassword: "パスワードを変更する",                                                                                        // 11
  choosePassword: "パスワードを選ぶ",                                                                                          // 12
  clickAgree: "アカウント登録をクリックすると、次の内容に同意したことになります。",                                                                     // 13
  configure: "設定する",                                                                                                   // 14
  createAccount: "新しいアカウントの登録",                                                                                        // 15
  currentPassword: "現在のパスワード",                                                                                         // 16
  dontHaveAnAccount: "まだアカウントをお持ちでない場合は",                                                                              // 17
  Email: "メールアドレス",                                                                                                    // 18
  email: "メールアドレス",                                                                                                    // 19
  emailAddress: "メールアドレス",                                                                                             // 20
  emailResetLink: "パスワードリセットのメールを送る",                                                                                  // 21
  forgotPassword: "パスワードをお忘れですか？",                                                                                     // 22
  ifYouAlreadyHaveAnAccount: "既にアカウントをお持ちの場合は",                                                                        // 23
  newPassword: "新しいパスワード",                                                                                             // 24
  newPasswordAgain: "新しいパスワード（確認）",                                                                                    // 25
  optional: "オプション",                                                                                                   // 26
  OR: "または",                                                                                                           // 27
  password: "パスワード",                                                                                                   // 28
  passwordAgain: "パスワード（確認）",                                                                                          // 29
  privacyPolicy: "プライバシーポリシー",                                                                                         // 30
  remove: "連携の解除：",                                                                                                    // 31
  resetYourPassword: "パスワードのリセット",                                                                                     // 32
  setPassword: "パスワードを設定する",                                                                                           // 33
  sign: "署名",                                                                                                          // 34
  signIn: "ログイン",                                                                                                      // 35
  signin: "ログイン",                                                                                                      // 36
  signOut: "ログアウト",                                                                                                    // 37
  signUp: "アカウント登録",                                                                                                   // 38
  signupCode: "登録用コード",                                                                                                // 39
  signUpWithYourEmailAddress: "メールアドレスで登録する",                                                                          // 40
  terms: "利用規約",                                                                                                       // 41
  updateYourPassword: "パスワードを変更する",                                                                                    // 42
  username: "ユーザー名",                                                                                                   // 43
  usernameOrEmail: "ユーザー名またはメールアドレス",                                                                                  // 44
  "with": "：",                                                                                                         // 45
  maxAllowedLength: "最大文字数",                                                                                           // 46
  minRequiredLength: "最低文字数",                                                                                          // 47
  resendVerificationEmail: "認証メールの再送",                                                                                 // 48
  resendVerificationEmailLink_pre: "認証メールが届いていない場合は",                                                                  // 49
  resendVerificationEmailLink_link: "再送",                                                                              // 50
  info: {                                                                                                              // 52
    emailSent: "メールを送りました",                                                                                            // 53
    emailVerified: "メールアドレスを確認しました",                                                                                   // 54
    passwordChanged: "パスワードを変更しました",                                                                                   // 55
    passwordReset: "パスワードをリセットしました"                                                                                    // 56
  },                                                                                                                   // 53
  error: {                                                                                                             // 59
    emailRequired: "メールアドレスを入力してください。",                                                                                // 60
    minChar: "パスワードの文字数が足りません。",                                                                                       // 61
    pwdsDontMatch: "パスワードが一致しません。",                                                                                    // 62
    pwOneDigit: "パスワードに1文字以上の数字を含めてください。",                                                                             // 63
    pwOneLetter: "パスワードに1文字以上のアルファベットを含めてください。",                                                                       // 64
    signInRequired: "その操作にはログインが必要です。",                                                                                // 65
    signupCodeIncorrect: "登録用コードが間違っています。",                                                                            // 66
    signupCodeRequired: "登録用コードが必要です。",                                                                                // 67
    usernameIsEmail: "ユーザー名にメールアドレスは使えません。",                                                                           // 68
    usernameRequired: "ユーザー名が必要です。",                                                                                   // 69
    accounts: {                                                                                                        // 72
      "Email already exists.": "そのメールアドレスは既に登録されています。",                                                                // 76
      "Email doesn't match the criteria.": "正しいメールアドレスを入力してください。",                                                     // 77
      "Invalid login token": "無効なログイントークンです。",                                                                         // 78
      "Login forbidden": "ログインできません。",                                                                                 // 79
      "Service unknown": "不明なサービスです",                                                                                  // 81
      "Unrecognized options for login request": "不明なログインオプションです",                                                      // 82
      "User validation failed": "ユーザ認証に失敗しました",                                                                        // 83
      "Username already exists.": "そのユーザー名は既に使われています。",                                                                // 84
      "You are not logged in.": "ログインしていません。",                                                                         // 85
      "You've been logged out by the server. Please log in again.": "既にログアウトしています。再度ログインしてください。",                      // 86
      "Your session has expired. Please log in again.": "セッションが切れました。再度ログインしてください。",                                   // 87
      "Already verified": "認証済です",                                                                                     // 88
      "No matching login attempt found": "対応するログイン試行が見つかりません",                                                         // 92
      "Password is old. Please reset your password.": "古いパスワードです。パスワードをリセットしてください。",                                   // 96
      "Incorrect password": "パスワードが正しくありません",                                                                          // 100
      "Invalid email": "無効なメールアドレスです",                                                                                 // 101
      "Must be logged in": "ログインが必要です",                                                                                // 102
      "Need to set a username or email": "ユーザー名かメールアドレスを入力してください",                                                     // 103
      "old password format": "古いパスワード形式です",                                                                            // 104
      "Password may not be empty": "パスワードを入力してください",                                                                   // 105
      "Signups forbidden": "アカウントを登録できません",                                                                            // 106
      "Token expired": "無効なトークンです",                                                                                    // 107
      "Token has invalid email address": "トークンに無効なメールアドレスが含まれています",                                                    // 108
      "User has no password set": "パスワードが設定されていません",                                                                   // 109
      "User not found": "ユーザー名が見つかりません",                                                                               // 110
      "Verify email link expired": "期限の切れた認証メールのリンクです",                                                                // 111
      "Verify email link is for unknown address": "不明なメールアドレスに対する認証メールのリンクです",                                         // 112
      "At least 1 digit, 1 lowercase and 1 uppercase": "数字、小文字、大文字をそれぞれ1文字以上入力してください",                                 // 113
      "Please verify your email first. Check the email and follow the link!": "まず認証メールが届いているか確認して、リンクを押してください！",       // 114
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "新しいメールを送信しました。もしメールが届いていなければ、迷惑メールに分類されていないか確認してください。",
      "Match failed": "一致しません",                                                                                        // 118
      "Unknown error": "不明なエラー"                                                                                        // 121
    }                                                                                                                  // 76
  }                                                                                                                    // 60
};                                                                                                                     // 6
T9n.map("ja", ja);                                                                                                     // 124
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/kh.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var kh;                                                                                                                // 4
kh = {                                                                                                                 // 4
  add: "បន្ថែម",                                                                                                       // 6
  and: "និង",                                                                                                          // 7
  back: "ត្រឡប់ក្រោយ",                                                                                                 // 8
  changePassword: "ផ្លាស់ប្តូរពាក្យសម្ងាត់",                                                                           // 9
  choosePassword: "ជ្រើសពាក្យសម្ងាត់",                                                                                 // 10
  clickAgree: "សូមចុះឈ្មោះ បើអ្នកយល់ព្រម",                                                                             // 11
  configure: "កំណត់រចនាសម្ព័ន្ធ",                                                                                      // 12
  createAccount: "បង្កើតគណនី",                                                                                         // 13
  currentPassword: "ពាក្យសម្ងាត់បច្ចុប្បន្ន",                                                                          // 14
  dontHaveAnAccount: "មិនមានគណនីទេឬ?",                                                                                 // 15
  email: "អ៊ីម៉ែល",                                                                                                    // 16
  emailAddress: "អាសយដ្ឋានអ៊ីម៉ែល",                                                                                    // 17
  emailResetLink: "អ៊ីម៉ែលតំណភ្ជាប់ សម្រាប់កំណត់ឡើងវិញ",                                                               // 18
  forgotPassword: "ភ្លេចពាក្យសម្ងាត់?",                                                                                // 19
  ifYouAlreadyHaveAnAccount: "បើអ្នកមានគណនីមួយរួចទៅហើយ",                                                               // 20
  newPassword: "ពាក្យសម្ងាត់ថ្មី",                                                                                     // 21
  newPasswordAgain: "ពាក្យសម្ងាត់ថ្មី (ម្ដងទៀត)",                                                                      // 22
  optional: "ជម្រើស",                                                                                                  // 23
  OR: "ឬ",                                                                                                             // 24
  password: "ពាក្យសម្ងាត់",                                                                                            // 25
  passwordAgain: "ពាក្យសម្ងាត់ (ម្ដងទៀត)",                                                                             // 26
  privacyPolicy: "គោលការណ៍ភាពឯកជន",                                                                                    // 27
  remove: "លុប",                                                                                                       // 28
  resetYourPassword: "កំណត់ពាក្យសម្ងាត់ឡើងវិញ",                                                                        // 29
  setPassword: "កំណត់ពាក្យសម្ងាត់",                                                                                    // 30
  sign: "ចូលគណនី",                                                                                                     // 31
  signIn: "ពិនិត្យចូល",                                                                                                // 32
  signin: "ចូល",                                                                                                       // 33
  signOut: "ចាកចេញ",                                                                                                   // 34
  signUp: "ចុះឈ្មោះ",                                                                                                  // 35
  signupCode: "លេខ​កូដចុះឈ្មោះ",                                                                                       // 36
  signUpWithYourEmailAddress: "ចុះឈ្មោះជាមួយអាសយដ្ឋានអ៊ីមែល",                                                          // 37
  terms: "លក្ខខណ្ឌនៃការប្រើប្រាស់",                                                                                    // 38
  updateYourPassword: "ធ្វើបច្ចុប្បន្នភាពពាក្យសម្ងាត់",                                                                // 39
  username: "ឈ្មោះអ្នកប្រើ",                                                                                           // 40
  usernameOrEmail: "ឈ្មោះអ្នកប្រើ ឬអ៊ីម៉ែល",                                                                           // 41
  "with": "ជាមួយនឹង",                                                                                                  // 42
  info: {                                                                                                              // 45
    emailSent: "អ៊ីម៉ែលដែលបានផ្ញើរ",                                                                                   // 46
    emailVerified: "អ៊ីម៉ែលបានផ្ទៀងផ្ទាត់",                                                                            // 47
    passwordChanged: "ពាក្យសម្ងាត់បាន​ផ្លាស់ប្តូរ",                                                                    // 48
    passwordReset: "កំណត់ពាក្យសម្ងាត់ឡើងវិញ"                                                                           // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "អ៊ីម៉ែលត្រូវបានទាមទារ",                                                                            // 53
    minChar: "ពាក្យសម្ងាត់អប្បបរមា ៧ តួអក្សរលេខ",                                                                      // 54
    pwdsDontMatch: "ពាក្យសម្ងាត់មិនត្រូវគ្នា",                                                                         // 55
    pwOneDigit: "ពាក្យសម្ងាត់ត្រូវតែមានយ៉ាងហោចណាស់ ១ តួលេខ",                                                           // 56
    pwOneLetter: "ពាក្យសម្ងាត់ត្រូវតែមានយ៉ាងហោចណាស់ ១ តួអក្សរ​",                                                       // 57
    signInRequired: "អ្នកត្រូវតែបានចូលគណនី ដើម្បីធ្វើការងារផ្សេងៗ",                                                    // 58
    signupCodeIncorrect: "លេខកូដការចុះឈ្មោះមិនត្រឹមត្រូវ",                                                             // 59
    signupCodeRequired: "លេខកូដការចុះឈ្មោះត្រូវបានទាមទារ",                                                             // 60
    usernameIsEmail: "ឈ្មោះអ្នកប្រើមិនអាចជាអាសយដ្ឋានអ៊ីមែល",                                                           // 61
    usernameRequired: "ឈ្មោះអ្នកប្រើត្រូវបានទាមទារ",                                                                   // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "អ៊ីម៉ែលមានរួចហើយ",                                                                     // 70
      "Email doesn't match the criteria.": "អ៊ីម៉ែលមិនផ្គូផ្គងនឹងលក្ខណៈវិនិច្ឆ័យ",                                     // 71
      "Invalid login token": "សញ្ញាសម្ងាត់ចូលមិនត្រឹមត្រូវ",                                                           // 72
      "Login forbidden": "បានហាមឃាត់ការចូល",                                                                           // 73
      "Service unknown": "សេវាមិនស្គាល់",                                                                              // 75
      "Unrecognized options for login request": "មិនស្គាល់ជម្រើសសម្រាប់សំណើកត់ត្រាចូល",                                // 76
      "User validation failed": "សុពលភាពរបស់អ្នកប្រើបានបរាជ័យ",                                                        // 77
      "Username already exists.": "ឈ្មោះអ្នកប្រើមាន​រួចហើយ",                                                           // 78
      "You are not logged in.": "អ្នកមិនបានចូលគណនីទេ",                                                                 // 79
      "You've been logged out by the server. Please log in again.": "អ្នកបានចាកចេញ ពីគណនី, សូមចូលម្តងទៀត",             // 80
      "Your session has expired. Please log in again.": "សុពលភាពរបស់អ្នកបានផុតកំណត់, សូមចូលម្តងទៀត",                   // 81
      "No matching login attempt found": "គ្មានការផ្គូផ្គងចូលត្រូវបានរកឃើញ",                                           // 85
      "Password is old. Please reset your password.": "ពាក្យសម្ងាត់គឺចាស់,​ សូមកំណត់ពាក្យសម្ងាត់ឡើងវិញ",               // 89
      "Incorrect password": "ពាក្យសម្ងាត់មិនត្រឹមត្រូវ",                                                               // 93
      "Invalid email": "អ៊ីម៉ែលមិនត្រឹមត្រូវ",                                                                         // 94
      "Must be logged in": "ត្រូវតែចូលគណនី",                                                                           // 95
      "Need to set a username or email": "ត្រូវកំណត់ឈ្មោះអ្នកប្រើ​ ឬអ៊ីម៉ែល",                                          // 96
      "old password format": "ទ្រង់ទ្រាយពាក្យសម្ងាត់ចាស់",                                                             // 97
      "Password may not be empty": "ពាក្យសម្ងាត់ប្រហែលជាមិនអាចទទេ",                                                    // 98
      "Signups forbidden": "ការចូលត្រូវបានហាមឃាត់",                                                                    // 99
      "Token expired": "សញ្ញាសម្ងាត់ផុតកំណត់",                                                                         // 100
      "Token has invalid email address": "សញ្ញាសម្ងាត់ដែលមានអាសយដ្ឋានអ៊ីមែលមិនត្រឹមត្រូវ",                             // 101
      "User has no password set": "អ្នកប្រើមិនមានសំណុំពាក្យសម្ងាត់",                                                   // 102
      "User not found": "រកមិនឃើញអ្នកប្រើ",                                                                            // 103
      "Verify email link expired": "ផ្ទៀងផ្ទាត់តំណភ្ជាប់អ៊ីម៉ែលផុតកំណត់",                                              // 104
      "Verify email link is for unknown address": "ផ្ទៀងផ្ទាត់តំណភ្ជាប់អ៊ីម៉ែល គឺសម្រាប់អាសយដ្ឋានមិនស្គាល់",           // 105
      "Match failed": "ការផ្ទៀងផ្ទាត់បានបរាជ័យ",                                                                       // 108
      "Unknown error": "មិនស្គាល់កំហុស"                                                                                // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("kh", kh);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ko.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ko;                                                                                                                // 1
ko = {                                                                                                                 // 1
  add: "추가",                                                                                                           // 3
  and: "그리고",                                                                                                          // 4
  back: "뒤로",                                                                                                          // 5
  changePassword: "비밀번호 변경",                                                                                           // 6
  choosePassword: "비밀번호 선택",                                                                                           // 7
  clickAgree: "클릭함으로써 위 약관에 동의합니다",                                                                                    // 8
  configure: "설정",                                                                                                     // 9
  createAccount: "계정 생성",                                                                                              // 10
  currentPassword: "현재 비밀번호",                                                                                          // 11
  dontHaveAnAccount: "계정이 없으세요?",                                                                                      // 12
  email: "이메일",                                                                                                        // 13
  emailAddress: "이메일 주소",                                                                                              // 14
  emailResetLink: "이메일 리셋 링크",                                                                                         // 15
  forgotPassword: "비밀번호를 잊으셨나요?",                                                                                      // 16
  ifYouAlreadyHaveAnAccount: "이미 계정이 있으시면",                                                                            // 17
  newPassword: "새 비밀번호",                                                                                               // 18
  newPasswordAgain: "새 비밀번호(확인)",                                                                                      // 19
  optional: "선택",                                                                                                      // 20
  OR: "혹은",                                                                                                            // 21
  password: "비밀번호",                                                                                                    // 22
  passwordAgain: "비밀번호 (확인)",                                                                                          // 23
  privacyPolicy: "개인정보보호정책",                                                                                           // 24
  remove: "삭제",                                                                                                        // 25
  resetYourPassword: "비밀번호 초기화",                                                                                       // 26
  setPassword: "비밀번호 선택",                                                                                              // 27
  sign: "로그인",                                                                                                         // 28
  signIn: "로그인",                                                                                                       // 29
  signin: "로그인",                                                                                                       // 30
  signOut: "로그아웃",                                                                                                     // 31
  signUp: "회원가입",                                                                                                      // 32
  signupCode: "회원가입 코드",                                                                                               // 33
  signUpWithYourEmailAddress: "이메일로 가입하기",                                                                             // 34
  terms: "약관",                                                                                                         // 35
  updateYourPassword: "비밀번호 업데이트",                                                                                     // 36
  username: "아이디",                                                                                                     // 37
  usernameOrEmail: "아이디 혹은 이메일",                                                                                       // 38
  "with": "와",                                                                                                         // 39
  info: {                                                                                                              // 41
    emailSent: "이메일 발송",                                                                                               // 42
    emailVerified: "이메일 인증성공",                                                                                         // 43
    passwordChanged: "비밀번호 변경됨",                                                                                       // 44
    passwordReset: "비밀번호 초기화",                                                                                         // 45
    error: {                                                                                                           // 47
      emailRequired: "이메일이 필요합니다.",                                                                                    // 48
      minChar: "비밀번호는 최소 7자 이상입니다.",                                                                                   // 49
      pwdsDontMatch: "비밀번호가 일치하지 않습니다",                                                                                // 50
      pwOneDigit: "비밀번호에 숫자 하나 이상이 필요합니다.",                                                                            // 51
      pwOneLetter: "비밀번호에 문자 하나 이상이 필요합니다.",                                                                           // 52
      signInRequired: "로그인이 필요한 서비스입니다.",                                                                              // 53
      signupCodeIncorrect: "가입 코드가 맞지 않습니다.",                                                                          // 54
      signupCodeRequired: "가입 코드가 필요합니다.",                                                                             // 55
      usernameIsEmail: "아이디와 이메일은 달라야 합니다.",                                                                           // 56
      usernameRequired: "아이디가 필요합니다.",                                                                                 // 57
      accounts: {                                                                                                      // 59
        "Email already exists.": "중복된 이메일입니다.",                                                                        // 64
        "Email doesn't match the criteria.": "이메일이 요구 조건에 맞지 않습니다.",                                                   // 65
        "Invalid login token": "잘못된 로그인 토큰",                                                                           // 66
        "Login forbidden": "허용되지 않은 로그인",                                                                              // 67
        "Service unknown": "알 수 없는 서비스",                                                                               // 69
        "Unrecognized options for login request": "알 수 없는 로그인 요청 정보입니다",                                               // 70
        "User validation failed": "인증 실패",                                                                             // 71
        "Username already exists.": "중복된 아이디입니다.",                                                                     // 72
        "You are not logged in.": "로그인 상태가 아닙니다.",                                                                     // 73
        "You've been logged out by the server. Please log in again.": "서버에 의해 로그아웃되었습니다. 다시 로그인해주세요.",                 // 74
        "Your session has expired. Please log in again.": "세션이 만료되었습니다. 다시 로그인해주세요.",                                  // 75
        "No matching login attempt found": "해당 로그인 시도를 찾지 못했습니다",                                                      // 79
        "Password is old. Please reset your password.": "오래된 비밀번호입니다. 변경해주세요.",                                        // 83
        "Incorrect password": "잘못된 비밀번호입니다",                                                                           // 87
        "Invalid email": "잘못된 이메일 주소입니다",                                                                              // 88
        "Must be logged in": "로그인이 필요합니다",                                                                             // 89
        "Need to set a username or email": "아이디나 이메일을 입력해주세요",                                                         // 90
        "old password format": "오래된 비밀번호 형식입니다",                                                                       // 91
        "Password may not be empty": "비밀번호를 입력해주세요",                                                                   // 92
        "Signups forbidden": "가입이 거부되었습니다",                                                                            // 93
        "Token expired": "토큰이 만료되었습니다",                                                                                // 94
        "Token has invalid email address": "토큰에 포함된 이메일 주소가 유효하지 않습니다",                                                // 95
        "User has no password set": "설정된 암호가 없습니다",                                                                    // 96
        "User not found": "사용자를 찾을 수 없습니다",                                                                            // 97
        "Verify email link expired": "확인 코드가 만료되었습니다",                                                                 // 98
        "Verify email link is for unknown address": "알 수 없는 인증 메일 주소입니다",                                              // 99
        "Match failed": "매치되지 않습니다",                                                                                   // 102
        "Unknown error": "알 수 없는 오류"                                                                                   // 105
      }                                                                                                                // 64
    }                                                                                                                  // 48
  }                                                                                                                    // 42
};                                                                                                                     // 3
T9n.map("ko", ko);                                                                                                     // 107
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/nl.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var nl;                                                                                                                // 4
nl = {                                                                                                                 // 4
  add: "toevoegen",                                                                                                    // 6
  and: "en",                                                                                                           // 7
  back: "terug",                                                                                                       // 8
  changePassword: "Wachtwoord wijzigen",                                                                               // 9
  choosePassword: "Wachtwoord kiezen",                                                                                 // 10
  clickAgree: "Door te registreren accepteert u onze",                                                                 // 11
  configure: "Configureer",                                                                                            // 12
  createAccount: "Account aanmaken",                                                                                   // 13
  currentPassword: "Huidig wachtwoord",                                                                                // 14
  dontHaveAnAccount: "Nog geen account?",                                                                              // 15
  email: "E-mail",                                                                                                     // 16
  emailAddress: "E-mailadres",                                                                                         // 17
  emailResetLink: "Verzenden",                                                                                         // 18
  forgotPassword: "Wachtwoord vergeten?",                                                                              // 19
  ifYouAlreadyHaveAnAccount: "Heeft u al een account?",                                                                // 20
  newPassword: "Nieuw wachtwoord",                                                                                     // 21
  newPasswordAgain: "Nieuw wachtwoord (herhalen)",                                                                     // 22
  optional: "Optioneel",                                                                                               // 23
  OR: "OF",                                                                                                            // 24
  password: "Wachtwoord",                                                                                              // 25
  passwordAgain: "Wachtwoord (herhalen)",                                                                              // 26
  privacyPolicy: "privacyverklaring",                                                                                  // 27
  remove: "verwijderen",                                                                                               // 28
  resetYourPassword: "Wachtwoord resetten",                                                                            // 29
  setPassword: "Wachtwoord instellen",                                                                                 // 30
  sign: "Aanmelden",                                                                                                   // 31
  signIn: "Aanmelden",                                                                                                 // 32
  signin: "Aanmelden",                                                                                                 // 33
  signOut: "Afmelden",                                                                                                 // 34
  signUp: "Registreren",                                                                                               // 35
  signupCode: "Registratiecode",                                                                                       // 36
  signUpWithYourEmailAddress: "Met e-mailadres registreren",                                                           // 37
  terms: "gebruiksvoorwaarden",                                                                                        // 38
  updateYourPassword: "Wachtwoord veranderen",                                                                         // 39
  username: "Gebruikersnaam",                                                                                          // 40
  usernameOrEmail: "Gebruikersnaam of e-mailadres",                                                                    // 41
  "with": "met",                                                                                                       // 42
  info: {                                                                                                              // 45
    emailSent: "E-mail verzonden",                                                                                     // 46
    emailVerified: "E-mail geverifieerd",                                                                              // 47
    PasswordChanged: "Wachtwoord gewijzigd",                                                                           // 48
    PasswordReset: "Wachtwoord gereset"                                                                                // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "E-mailadres is verplicht",                                                                         // 53
    minChar: "Wachtwoord moet tenminste 7 tekens lang zijn.",                                                          // 54
    pwdsDontMatch: "Wachtwoorden zijn niet gelijk.",                                                                   // 55
    pwOneDigit: "Wachtwoord moet tenminste 1 cijfer bevatten.",                                                        // 56
    pwOneLetter: "Wachtwoord moet tenminste 1 letter bevatten.",                                                       // 57
    signInRequired: "U moet aangemeld zijn.",                                                                          // 58
    signupCodeIncorrect: "Registratiecode is ongeldig.",                                                               // 59
    signupCodeRequired: "Registratiecode is verplicht.",                                                               // 60
    usernameIsEmail: "Gebruikersnaam is gelijk aan e-mail.",                                                           // 61
    usernameRequired: "Gebruikersnaam is verplicht.",                                                                  // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Dit e-mailadres is al in gebruik.",                                                    // 70
      "Email doesn't match the criteria.": "e-mail voldoet niet aan de voorwaarden.",                                  // 71
      "Invalid login token": "Ongeldig inlogtoken",                                                                    // 72
      "Login forbidden": "Aanmelding geweigerd",                                                                       // 73
      "Service unknown": "Sevice onbekend",                                                                            // 75
      "Unrecognized options for login request": "Onbekende optie voor inlogverzoek",                                   // 76
      "User validation failed": "Gebruikersvalidatie mislukt",                                                         // 77
      "Username already exists.": "Gebruikersnaam bestaat al.",                                                        // 78
      "You are not logged in.": "U bent niet ingelogd.",                                                               // 79
      "You've been logged out by the server. Please log in again.": "U bent door de server afgemeld. Meld a.u.b. opnieuw aan.",
      "Your session has expired. Please log in again.": "Uw sessie is verlopen. Meld a.u.b. opnieuw aan.",             // 81
      "No matching login attempt found": "Geen overeenkomstig inlogverzoek gevonden.",                                 // 85
      "Password is old. Please reset your Password.": "Wachtwoord is verlopen. Reset a.u.b. uw wachtwoord.",           // 89
      "Incorrect password": "Onjuist wachtwoord",                                                                      // 93
      "Invalid email": "Ongeldig e-mailadres",                                                                         // 94
      "Must be logged in": "U moet aangemeld zijn",                                                                    // 95
      "Need to set a username or email": "Gebruikersnaam of e-mailadres moet ingesteld zijn",                          // 96
      "Password may not be empty": "Wachtwoord mag niet leeg zijn",                                                    // 98
      "Signups forbidden": "Registratie verboden",                                                                     // 99
      "Token expired": "Token is verlopen",                                                                            // 100
      "Token has invalid email address": "Token heeft ongeldig e-mailadres",                                           // 101
      "User has no Password set": "Geen wachtwoord ingesteld voor gebruiker",                                          // 102
      "User not found": "Gebruiker niet gevonden",                                                                     // 103
      "Verify email link expired": "Verificatielink is verlopen",                                                      // 104
      "Verify email link is for unknown address": "Verificatielink is voor onbekend e-mailadres",                      // 105
      "Match failed": "Geen match",                                                                                    // 108
      "Unknown error": "Onbekende fout"                                                                                // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("nl", nl);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/no_NB.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var no_NB;                                                                                                             // 4
no_NB = {                                                                                                              // 4
  add: "legg til",                                                                                                     // 6
  and: "og",                                                                                                           // 7
  back: "tilbake",                                                                                                     // 8
  changePassword: "Bytt passord",                                                                                      // 9
  choosePassword: "Velg passord",                                                                                      // 10
  clickAgree: "Ved å klikke meld på godtar du vår",                                                                    // 11
  configure: "Konfigurer",                                                                                             // 12
  createAccount: "Oprett konto",                                                                                       // 13
  currentPassword: "Nåværende passord",                                                                                // 14
  dontHaveAnAccount: "Har du ikke en konto?",                                                                          // 15
  email: "E-post",                                                                                                     // 16
  emailAddress: "E-postadresse",                                                                                       // 17
  emailResetLink: "Epost nullstillingslenke",                                                                          // 18
  forgotPassword: "Glemt passord?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Hvis du allerede har en konto",                                                          // 20
  newPassword: "Nytt passord",                                                                                         // 21
  newPasswordAgain: "Gjengi nytt passord",                                                                             // 22
  optional: "Frivillig",                                                                                               // 23
  OR: "eller",                                                                                                         // 24
  password: "Passord",                                                                                                 // 25
  passwordAgain: "Gjengi passord",                                                                                     // 26
  privacyPolicy: "Personvern",                                                                                         // 27
  remove: "fjern",                                                                                                     // 28
  resetYourPassword: "Nullstill passord",                                                                              // 29
  setPassword: "Sett passord",                                                                                         // 30
  sign: "Logg",                                                                                                        // 31
  signIn: "Logg inn",                                                                                                  // 32
  signin: "Logg inn",                                                                                                  // 33
  signOut: "Logg ut",                                                                                                  // 34
  signUp: "Meld på",                                                                                                   // 35
  signupCode: "Påmeldingskode",                                                                                        // 36
  signUpWithYourEmailAddress: "Meld på med din e-postadresse",                                                         // 37
  terms: "Betingelser for bruk",                                                                                       // 38
  updateYourPassword: "Oppdater passord",                                                                              // 39
  username: "Brukernavn",                                                                                              // 40
  usernameOrEmail: "Brukernavn eller e-epost",                                                                         // 41
  "with": "med",                                                                                                       // 42
  info: {                                                                                                              // 45
    emailSent: "E-post sendt",                                                                                         // 46
    emailVerified: "E-post bekreftet",                                                                                 // 47
    passwordChanged: "Passord endret",                                                                                 // 48
    passwordReset: "Passord nullstillt"                                                                                // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "E-post obligatorisk.",                                                                             // 53
    minChar: "Passordet må ha minst 7 tegn.",                                                                          // 54
    pwdsDontMatch: "Passordene er ikke like.",                                                                         // 55
    pwOneDigit: "Passordet må ha minst ett tall.",                                                                     // 56
    pwOneLetter: "Passordet må ha minst en bokstav.",                                                                  // 57
    signInRequired: "Du må være logget inn for å gjøre dette.",                                                        // 58
    signupCodeIncorrect: "Påmelding gikk galt.",                                                                       // 59
    signupCodeRequired: "Påmeldingskode kreves.",                                                                      // 60
    usernameIsEmail: "Brukernavn kan ikke være en e-postadresse.",                                                     // 61
    usernameRequired: "Brukernavn må utfylles.",                                                                       // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "E-postadressen finnes allerede.",                                                      // 70
      "Email doesn't match the criteria.": "E-postadressen møter ikke kriteriet.",                                     // 71
      "Invalid login token": "Ugyldig innloggingstegn",                                                                // 72
      "Login forbidden": "Innlogging forbudt",                                                                         // 73
      "Service unknown": "Ukjent tjeneste",                                                                            // 75
      "Unrecognized options for login request": "Ukjendte valg ved innloggingsforsøk",                                 // 76
      "User validation failed": "Brukergodkjenning gikk galt",                                                         // 77
      "Username already exists.": "Brukernavnet finnes allerede.",                                                     // 78
      "You are not logged in.": "Du er ikke logget inn.",                                                              // 79
      "You've been logged out by the server. Please log in again.": "Tjeneren loggt deg ut. Logg inn på ny.",          // 80
      "Your session has expired. Please log in again.": "Din økt er utløpt. Logg inn på ny.",                          // 81
      "No matching login attempt found": "Fant ingen samsvarende innloggingsførsøk",                                   // 85
      "Password is old. Please reset your password.": "Passordet er for gammelt. Nullstill passordet ditt.",           // 89
      "Incorrect password": "Feil passord",                                                                            // 93
      "Invalid email": "Ugyldig e-postadresse",                                                                        // 94
      "Must be logged in": "Du må være innlogget",                                                                     // 95
      "Need to set a username or email": "Oppgi brukernavn eller e-postadresse",                                       // 96
      "old password format": "gammelt passordformat",                                                                  // 97
      "Password may not be empty": "Passord må være utfyllt",                                                          // 98
      "Signups forbidden": "Påmeldinger ikke tillatt",                                                                 // 99
      "Token expired": "Økten er utløpt",                                                                              // 100
      "Token has invalid email address": "Innloggingstegnet har ugyldig e-postadresse",                                // 101
      "User has no password set": "Brukeren har ikke angitt passord",                                                  // 102
      "User not found": "Bruker ikke funnet",                                                                          // 103
      "Verify email link expired": "Lenke for e-postbekreftelse er utløpt",                                            // 104
      "Verify email link is for unknown address": "Lenke for e-postbekreftelse er for en ukjent adresse",              // 105
      "Match failed": "Ikke samsvar",                                                                                  // 108
      "Unknown error": "Ukjent feil"                                                                                   // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("no_NB", no_NB);                                                                                               // 114
T9n.map("no-NB", no_NB);                                                                                               // 115
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/pl.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var pl;                                                                                                                // 3
pl = {                                                                                                                 // 3
  t9Name: 'Polski',                                                                                                    // 5
  add: "dodaj",                                                                                                        // 7
  and: "i",                                                                                                            // 8
  back: "powrót",                                                                                                      // 9
  cancel: "Anuluj",                                                                                                    // 10
  changePassword: "Zmień hasło",                                                                                       // 11
  choosePassword: "Wybierz hasło",                                                                                     // 12
  clickAgree: "Klikając na Zarejestruj się zgadzasz się z naszą",                                                      // 13
  configure: "Konfiguruj",                                                                                             // 14
  createAccount: "Utwórz konto",                                                                                       // 15
  currentPassword: "Aktualne hasło",                                                                                   // 16
  dontHaveAnAccount: "Nie masz konta?",                                                                                // 17
  email: "E-mail",                                                                                                     // 18
  emailAddress: "Adres e-mail",                                                                                        // 19
  emailResetLink: "Wyślij e-mail z linkiem do zmiany hasła",                                                           // 20
  forgotPassword: "Zapomniałeś hasła?",                                                                                // 21
  ifYouAlreadyHaveAnAccount: "Jeżeli już masz konto",                                                                  // 22
  newPassword: "Nowe hasło",                                                                                           // 23
  newPasswordAgain: "Nowe hasło (powtórz)",                                                                            // 24
  optional: "Nieobowiązkowe",                                                                                          // 25
  OR: "LUB",                                                                                                           // 26
  password: "Hasło",                                                                                                   // 27
  passwordAgain: "Hasło (powtórz)",                                                                                    // 28
  privacyPolicy: "polityką prywatności",                                                                               // 29
  remove: "usuń",                                                                                                      // 30
  resetYourPassword: "Ustaw nowe hasło",                                                                               // 31
  setPassword: "Ustaw hasło",                                                                                          // 32
  sign: "Podpisz",                                                                                                     // 33
  signIn: "Zaloguj się",                                                                                               // 34
  signin: "zaloguj się",                                                                                               // 35
  signOut: "Wyloguj się",                                                                                              // 36
  signUp: "Zarejestruj się",                                                                                           // 37
  signupCode: "Kod rejestracji",                                                                                       // 38
  signUpWithYourEmailAddress: "Zarejestruj się używając adresu e-mail",                                                // 39
  terms: "warunkami korzystania z serwisu",                                                                            // 40
  updateYourPassword: "Zaktualizuj swoje hasło",                                                                       // 41
  username: "Nazwa użytkownika",                                                                                       // 42
  usernameOrEmail: "Nazwa użytkownika lub adres e-mail",                                                               // 43
  "with": "z",                                                                                                         // 44
  maxAllowedLength: "Maksymalna dopuszczalna długość",                                                                 // 45
  minRequiredLength: "Minimalna wymagana długość",                                                                     // 46
  resendVerificationEmail: "Wyślij maila ponownie",                                                                    // 47
  resendVerificationEmailLink_pre: "Zgubiłeś mail weryfikacyjny?",                                                     // 48
  resendVerificationEmailLink_link: "Wyślij ponownie",                                                                 // 49
  enterPassword: "Wprowadź hasło",                                                                                     // 50
  enterNewPassword: "Wprowadź nowe hasło",                                                                             // 51
  enterEmail: "Wprowadź adres e-mail",                                                                                 // 52
  enterUsername: "Wprowadź nazwę użytkownika",                                                                         // 53
  enterUsernameOrEmail: "Wprowadź nazwę użytkownika lub adres e-mail",                                                 // 54
  orUse: "Lub użyj",                                                                                                   // 55
  info: {                                                                                                              // 57
    emailSent: "Adres e-mail wysłany",                                                                                 // 58
    emailVerified: "Adres e-mail zweryfikowany",                                                                       // 59
    passwordChanged: "Hasło zmienione",                                                                                // 60
    passwordReset: "Hasło wyzerowane"                                                                                  // 61
  },                                                                                                                   // 58
  alert: {                                                                                                             // 63
    ok: 'Ok',                                                                                                          // 64
    type: {                                                                                                            // 65
      info: 'Uwaga',                                                                                                   // 66
      error: 'Błąd',                                                                                                   // 67
      warning: 'Ostrzeżenie'                                                                                           // 68
    }                                                                                                                  // 66
  },                                                                                                                   // 64
  error: {                                                                                                             // 70
    emailRequired: "Wymagany jest adres e-mail.",                                                                      // 71
    minChar: "7 znaków to minimalna długość hasła.",                                                                   // 72
    pwdsDontMatch: "Hasła są różne",                                                                                   // 73
    pwOneDigit: "Hasło musi zawierać przynajmniej jedną cyfrę.",                                                       // 74
    pwOneLetter: "Hasło musi zawierać 1 literę.",                                                                      // 75
    signInRequired: "Musisz być zalogowany, aby to zrobić.",                                                           // 76
    signupCodeIncorrect: "Kod rejestracji jest nieprawidłowy.",                                                        // 77
    signupCodeRequired: "Wymagany jest kod rejestracji.",                                                              // 78
    usernameIsEmail: "Adres e-mail nie może być nazwą użytkownika.",                                                   // 79
    usernameRequired: "Wymagana jest nazwa użytkownika.",                                                              // 80
    accounts: {                                                                                                        // 83
      "Email already exists.": "Adres e-mail już istnieje.",                                                           // 87
      "Email doesn't match the criteria.": "Adres e-mail nie spełnia kryteriów.",                                      // 88
      "Invalid login token": "Błędny token logowania",                                                                 // 89
      "Login forbidden": "Logowanie zabronione",                                                                       // 90
      "Service unknown": "Nieznana usługa",                                                                            // 92
      "Unrecognized options for login request": "Nieznane parametry w żądaniu logowania",                              // 93
      "User validation failed": "Niepoprawna nazwa użytkownika",                                                       // 94
      "Username already exists.": "Nazwa użytkownika już istnieje.",                                                   // 95
      "You are not logged in.": "Nie jesteś zalogowany.",                                                              // 96
      "You've been logged out by the server. Please log in again.": "Zostałeś wylogowane przez serwer. Zaloguj się ponownie.",
      "Your session has expired. Please log in again.": "Twoja sesja wygasła. Zaloguj się ponownie.",                  // 98
      "Already verified": "Już zweryfikowano",                                                                         // 99
      "Invalid email or username": "Niewłaściwy adress e-mail lub nazwa użytkownika",                                  // 100
      "Internal server error": "Błąd wewnętrzny serwera",                                                              // 101
      "undefined": "Ups, coś poszło nie tak",                                                                          // 102
      "No matching login attempt found": "Nie dopasowano danych logowania",                                            // 106
      "Password is old. Please reset your password.": "Hasło jest stare. Proszę wyzerować hasło.",                     // 110
      "Incorrect password": "Niepoprawne hasło",                                                                       // 114
      "Invalid email": "Błędny adres e-mail",                                                                          // 115
      "Must be logged in": "Musisz być zalogowany",                                                                    // 116
      "Need to set a username or email": "Wymagane ustawienie nazwy użytkownika lub adresu e-mail",                    // 117
      "old password format": "stary format hasła",                                                                     // 118
      "Password may not be empty": "Hasło nie może być puste",                                                         // 119
      "Signups forbidden": "Rejestracja zabroniona",                                                                   // 120
      "Token expired": "Token wygasł",                                                                                 // 121
      "Token has invalid email address": "Token ma niewłaściwy adres e-mail",                                          // 122
      "User has no password set": "Użytkownik nie ma ustawionego hasła",                                               // 123
      "User not found": "Nie znaleziono użytkownika",                                                                  // 124
      "Verify email link expired": "Link weryfikacyjny wygasł",                                                        // 125
      "Verify email link is for unknown address": "Link weryfikacyjny jest dla nieznanego adresu",                     // 126
      "At least 1 digit, 1 lowercase and 1 uppercase": "Przynajmniej jedna cyfra, 1 mała i 1 duża litera",             // 127
      "Please verify your email first. Check the email and follow the link!": "Proszę najpierw zweryfikowac adres e-mail. Sprawdź swojego maila i podążaj za linkiem!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Nowy e-mail został wysłany na twój adres. Jeśli wiadomość nie pojawi się w skrzynce odbiorczej, proszę sprawdzić w folderze ze sapmem.",
      "Match failed": "Błędne dopasowanie",                                                                            // 132
      "Unknown error": "Nieznany błąd",                                                                                // 135
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Błąd, zbyt dużo żądań. Proszę zwolnić. Prosimy odczekać 1 sekundę przed kolejną próbą."
    }                                                                                                                  // 87
  }                                                                                                                    // 71
};                                                                                                                     // 5
T9n.map("pl", pl);                                                                                                     // 139
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/pt.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var pt;                                                                                                                // 3
pt = {                                                                                                                 // 3
  t9Name: 'Português',                                                                                                 // 5
  add: "Adicionar",                                                                                                    // 7
  and: "e",                                                                                                            // 8
  back: "Voltar",                                                                                                      // 9
  cancel: "Cancelar",                                                                                                  // 10
  changePassword: "Alterar senha",                                                                                     // 11
  choosePassword: "Escolha uma senha",                                                                                 // 12
  clickAgree: "Ao clicar em Criar Conta, você estará reconhecendo que aceita nossos Termos de Uso",                    // 13
  configure: "Configurar",                                                                                             // 14
  createAccount: "Criar Conta",                                                                                        // 15
  currentPassword: "Senha Atual",                                                                                      // 16
  dontHaveAnAccount: "Não tem conta?",                                                                                 // 17
  email: "E-mail",                                                                                                     // 18
  emailAddress: "Endereço de e-mail",                                                                                  // 19
  emailResetLink: "E-mail com link para gerar Nova Senha",                                                             // 20
  forgotPassword: "Esqueceu sua senha?",                                                                               // 21
  ifYouAlreadyHaveAnAccount: "Se você já tem uma conta",                                                               // 22
  newPassword: "Nova Senha",                                                                                           // 23
  newPasswordAgain: "Nova Senha (novamente)",                                                                          // 24
  optional: "Opcional",                                                                                                // 25
  OR: "OU",                                                                                                            // 26
  password: "Senha",                                                                                                   // 27
  passwordAgain: "Senha (novamente)",                                                                                  // 28
  privacyPolicy: "Política de Privacidade",                                                                            // 29
  remove: "remover",                                                                                                   // 30
  resetYourPassword: "Gerar nova senha",                                                                               // 31
  setPassword: "Cadastrar Senha",                                                                                      // 32
  sign: "Entrar",                                                                                                      // 33
  signIn: "Entrar",                                                                                                    // 34
  signin: "entrar",                                                                                                    // 35
  signOut: "Sair",                                                                                                     // 36
  signUp: "Criar conta",                                                                                               // 37
  signupCode: "Código de Registro",                                                                                    // 38
  signUpWithYourEmailAddress: "Criar conta utilizando seu endereço de e-mail",                                         // 39
  terms: "Termos de Uso",                                                                                              // 40
  updateYourPassword: "Atualizar senha",                                                                               // 41
  username: "Nome de usuário",                                                                                         // 42
  usernameOrEmail: "Usuário ou e-mail",                                                                                // 43
  "with": "com",                                                                                                       // 44
  maxAllowedLength: "Tamanho máximo permitido",                                                                        // 45
  minRequiredLength: "Tamanho Mínimo requerido",                                                                       // 46
  resendVerificationEmail: "Reenviar e-mail de verificação",                                                           // 47
  resendVerificationEmailLink_pre: "Perdeu o e-mail de verificação?",                                                  // 48
  resendVerificationEmailLink_link: "Enviar novamente",                                                                // 49
  enterPassword: "Digite a senha",                                                                                     // 50
  enterNewPassword: "Digite a nova senha",                                                                             // 51
  enterEmail: "Digite o e-mail",                                                                                       // 52
  enterUsername: "Digite o nome de usuário",                                                                           // 53
  enterUsernameOrEmail: "Digite o nome de usuário ou e-mail",                                                          // 54
  orUse: "Ou use",                                                                                                     // 55
  info: {                                                                                                              // 57
    emailSent: "E-mail enviado",                                                                                       // 58
    emailVerified: "E-mail verificado",                                                                                // 59
    passwordChanged: "Senha atualizada",                                                                               // 60
    passwordReset: "Senha alterada"                                                                                    // 61
  },                                                                                                                   // 58
  alert: {                                                                                                             // 63
    ok: 'Ok',                                                                                                          // 64
    type: {                                                                                                            // 65
      info: 'Aviso',                                                                                                   // 66
      error: 'Erro',                                                                                                   // 67
      warning: 'Atenção'                                                                                               // 68
    }                                                                                                                  // 66
  },                                                                                                                   // 64
  error: {                                                                                                             // 70
    emailRequired: "E-mail é obrigatório.",                                                                            // 71
    minChar: "Senha requer um mínimo de 7 caracteres.",                                                                // 72
    pwdsDontMatch: "Senhas não coincidem",                                                                             // 73
    pwOneDigit: "A Senha deve conter pelo menos um dígito.",                                                           // 74
    pwOneLetter: "A Senha deve conter pelo menos uma letra.",                                                          // 75
    signInRequired: "Você precisa estar logado para fazer isso.",                                                      // 76
    signupCodeIncorrect: "Código de acesso incorreto.",                                                                // 77
    signupCodeRequired: "É necessário um código de acesso.",                                                           // 78
    usernameIsEmail: "Nome de usuário não pode ser um endereço de e-mail.",                                            // 79
    usernameRequired: "Nome de usuário é obrigatório.",                                                                // 80
    accounts: {                                                                                                        // 83
      "Email already exists.": "E-mail já existe.",                                                                    // 87
      "Email doesn't match the criteria.": "E-mail inválido.",                                                         // 88
      "Invalid login token": "Token de login inválido",                                                                // 89
      "Login forbidden": "Login não permitido",                                                                        // 90
      "Service unknown": "Serviço desconhecido",                                                                       // 92
      "Unrecognized options for login request": "Opções desconhecidas para solicitação de login",                      // 93
      "User validation failed": "Validação de usuário falhou",                                                         // 94
      "Username already exists.": "Nome de usuário já existe.",                                                        // 95
      "You are not logged in.": "Você não está logado.",                                                               // 96
      "You've been logged out by the server. Please log in again.": "Você foi desconectado pelo servidor. Por favor, efetue login novamente.",
      "Your session has expired. Please log in again.": "Sua sessão expirou. Por favor, efetue login novamente.",      // 98
      "Already verified": "Já verificado",                                                                             // 99
      "Invalid email or username": "Nome de usuário ou e-mail inválido",                                               // 100
      "Internal server error": "Erro interno do servidor",                                                             // 101
      "undefined": "Algo não está certo",                                                                              // 102
      "No matching login attempt found": "Não foi encontrada nenhuma tentativa de login que coincida.",                // 106
      "Password is old. Please reset your password.": "Senha expirou. Por favor, cadastre uma nova senha.",            // 110
      "Incorrect password": "Senha incorreta",                                                                         // 114
      "Invalid email": "E-mail inválido",                                                                              // 115
      "Must be logged in": "É necessário efetuar login",                                                               // 116
      "Need to set a username or email": "É necessário configurar um Nome de Usuário ou E-mail",                       // 117
      "old password format": "Formato de senha antigo",                                                                // 118
      "Password may not be empty": "Senha não pode estar em branco",                                                   // 119
      "Signups forbidden": "Não permitido Criar Conta",                                                                // 120
      "Token expired": "Token expirou",                                                                                // 121
      "Token has invalid email address": "Token tem endereço de e-mail inválido",                                      // 122
      "User has no password set": "Usuário não possui senha cadastrada",                                               // 123
      "User not found": "Usuário não encontrado",                                                                      // 124
      "Verify email link expired": "O link de verificação de e-mail expirou",                                          // 125
      "Verify email link is for unknown address": "O link de verificação de e-mail está configurado para um endereço desconhecido",
      "At least 1 digit, 1 lowercase and 1 uppercase": "Pelo menos 1 número, 1 letra minúscula and 1 maiúscula",       // 127
      "Please verify your email first. Check the email and follow the link!": "Por favor, verifique seu e-mail primeiro. Verifique o e-mail e abra o link!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "Um novo e-mail foi enviado para você. Se o e-mail não aparecer na sua caixa de entrada, verifique a sua caixa de spam.",
      "Match failed": "Senhas não coincidem",                                                                          // 132
      "Unknown error": "Erro desconhecido",                                                                            // 135
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "Erro, muitas tentativas. Por favor, diminua o ritmo. Você deve aguardar 1 segundo antes de tentar novamente."
    }                                                                                                                  // 87
  }                                                                                                                    // 71
};                                                                                                                     // 5
T9n.map("pt", pt);                                                                                                     // 139
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/pt_PT.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var pt_PT;                                                                                                             // 4
pt_PT = {                                                                                                              // 4
  add: "adicionar",                                                                                                    // 6
  and: "e",                                                                                                            // 7
  back: "voltar",                                                                                                      // 8
  changePassword: "Alterar palavra-passe",                                                                             // 9
  choosePassword: "Escolha uma palavra-passe",                                                                         // 10
  clickAgree: "Ao clicar em Registar, está a aceitar os nossos",                                                       // 11
  configure: "Configurar",                                                                                             // 12
  createAccount: "Criar uma Conta",                                                                                    // 13
  currentPassword: "Palavra-passe Atual",                                                                              // 14
  dontHaveAnAccount: "Não tem conta?",                                                                                 // 15
  email: "E-mail",                                                                                                     // 16
  emailAddress: "Endereço de e-mail",                                                                                  // 17
  emailResetLink: "Enviar e-mail para redefinir a palavra-passe",                                                      // 18
  forgotPassword: "Esqueci-me da palavra-passe",                                                                       // 19
  ifYouAlreadyHaveAnAccount: "Se já tem uma conta",                                                                    // 20
  newPassword: "Nova Palavra-passe",                                                                                   // 21
  newPasswordAgain: "Nova Palavra-passe (novamente)",                                                                  // 22
  optional: "Opcional",                                                                                                // 23
  OR: "OU",                                                                                                            // 24
  password: "Palavra-passe",                                                                                           // 25
  passwordAgain: "Palavra-passe (novamente)",                                                                          // 26
  privacyPolicy: "Política de Privacidade",                                                                            // 27
  remove: "remover",                                                                                                   // 28
  resetYourPassword: "Redefinir a palavra-passe",                                                                      // 29
  setPassword: "Definir Palavra-passe",                                                                                // 30
  sign: "Iniciar",                                                                                                     // 31
  signIn: "Iniciar Sessão",                                                                                            // 32
  signin: "iniciar sessão",                                                                                            // 33
  signOut: "Sair",                                                                                                     // 34
  signUp: "Criar conta",                                                                                               // 35
  signupCode: "Código de Registo",                                                                                     // 36
  signUpWithYourEmailAddress: "Registar com o endereço de e-mail",                                                     // 37
  terms: "Termos de Uso",                                                                                              // 38
  updateYourPassword: "Alterar a palavra-passe",                                                                       // 39
  username: "Nome do ulilizador",                                                                                      // 40
  usernameOrEmail: "Ulilizador ou e-mail",                                                                             // 41
  "with": "com",                                                                                                       // 42
  info: {                                                                                                              // 45
    emailSent: "E-mail enviado",                                                                                       // 46
    emailVerified: "E-mail verificado",                                                                                // 47
    passwordChanged: "Palavra-passe alterada",                                                                         // 48
    passwordReset: "Palavra-passe redefinida"                                                                          // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "O e-mail é obrigatório.",                                                                          // 53
    minChar: "A palavra-passe tem de ter no mínimo 7 caracteres.",                                                     // 54
    pwdsDontMatch: "As palavra-passes não coincidem",                                                                  // 55
    pwOneDigit: "A palavra-passe tem de conter pelo menos um dígito.",                                                 // 56
    pwOneLetter: "A palavra-passe tem de conter pelo menos uma letra.",                                                // 57
    signInRequired: "É necessário iniciar sessão para fazer isso.",                                                    // 58
    signupCodeIncorrect: "Código de registo incorreto.",                                                               // 59
    signupCodeRequired: "É necessário um código de registo.",                                                          // 60
    usernameIsEmail: "O nome do utilizador não pode ser um endereço de e-mail.",                                       // 61
    usernameRequired: "O nome de usuário é obrigatório.",                                                              // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "O e-mail já existe.",                                                                  // 70
      "Email doesn't match the criteria.": "E-mail inválido.",                                                         // 71
      "Invalid login token": "Token de início de sessão inválido",                                                     // 72
      "Login forbidden": "Início de sessão impedido",                                                                  // 73
      "Service unknown": "Serviço desconhecido",                                                                       // 75
      "Unrecognized options for login request": "Pedido de início de sessão com opções não reconhecidas",              // 76
      "User validation failed": "A validação do utilizador falhou",                                                    // 77
      "Username already exists.": "O nome do utilizador já existe.",                                                   // 78
      "You are not logged in.": "Não tem sessão iniciada.",                                                            // 79
      "You've been logged out by the server. Please log in again.": "Sessão terminada pelo servidor. Por favor, inicie sessão novamente.",
      "Your session has expired. Please log in again.": "A sua sessão expirou. Por favor, inicie sessão novamente.",   // 81
      "No matching login attempt found": "Não foi encontrada nenhuma tentativa de início de sessão que coincida.",     // 85
      "Password is old. Please reset your password.": "A palavra-passe é antiga. Por favor, redefina a sua palavra-passe.",
      "Incorrect password": "Palavra-passe incorreta",                                                                 // 93
      "Invalid email": "E-mail inválido",                                                                              // 94
      "Must be logged in": "É necessário iniciar sessão",                                                              // 95
      "Need to set a username or email": "É necessário definir um nome de utilizador ou e-mail",                       // 96
      "old password format": "Formato de palavra-passe antigo",                                                        // 97
      "Password may not be empty": "A palavra-passe não pode estar em branco",                                         // 98
      "Signups forbidden": "Criação de contas proibida",                                                               // 99
      "Token expired": "O token expirou",                                                                              // 100
      "Token has invalid email address": "O token tem um endereço de e-mail inválido",                                 // 101
      "User has no password set": "O utilizador não defeniu a palavra-passe",                                          // 102
      "User not found": "Utilizador não encontrado",                                                                   // 103
      "Verify email link expired": "O link de verificação de e-mail expirou",                                          // 104
      "Verify email link is for unknown address": "O link de verificação de e-mail está definido para um endereço desconhecido",
      "Match failed": "Comparação falhou",                                                                             // 108
      "Unknown error": "Erro desconhecido"                                                                             // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("pt_PT", pt_PT);                                                                                               // 114
T9n.map("pt-PT", pt_PT);                                                                                               // 115
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ro.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ro;                                                                                                                // 4
ro = {                                                                                                                 // 4
  add: "adaugă",                                                                                                       // 6
  and: "și",                                                                                                           // 7
  back: "înapoi",                                                                                                      // 8
  changePassword: "Schimbare parolă",                                                                                  // 9
  choosePassword: "Alege o parolă",                                                                                    // 10
  clickAgree: "Click pe Register, sunteți de acord",                                                                   // 11
  configure: "Configurare",                                                                                            // 12
  createAccount: "Creați un cont",                                                                                     // 13
  currentPassword: "Parola curentă",                                                                                   // 14
  dontHaveAnAccount: "Nu ai un cont?",                                                                                 // 15
  email: "E-mail",                                                                                                     // 16
  emailAddress: "Adresa de e-mail",                                                                                    // 17
  emailResetLink: "Link de resetare parolă",                                                                           // 18
  forgotPassword: "Ți-ai uitat parola?",                                                                               // 19
  ifYouAlreadyHaveAnAccount: "Dacă ai deja un cont",                                                                   // 20
  newPassword: "Parolă nouă",                                                                                          // 21
  newPasswordAgain: "Parolă nouă (din nou)",                                                                           // 22
  optional: "Opțional",                                                                                                // 23
  OR: "SAU",                                                                                                           // 24
  password: "Parolă",                                                                                                  // 25
  passwordAgain: "Parolă (din nou)",                                                                                   // 26
  privacyPolicy: "Politica de confidentialitate",                                                                      // 27
  remove: "Elimină",                                                                                                   // 28
  resetYourPassword: "Schimbati parola",                                                                               // 29
  setPassword: "Setati parola",                                                                                        // 30
  sign: "Înregistrează",                                                                                               // 31
  signIn: "Autentificare",                                                                                             // 32
  signin: "Autentificare",                                                                                             // 33
  signOut: "Deconectare",                                                                                              // 34
  signUp: "Înregistrare",                                                                                              // 35
  signupCode: "Codul de înregistrare",                                                                                 // 36
  signUpWithYourEmailAddress: "Înregistrați-vă adresa de e-mail",                                                      // 37
  terms: "Condiții de utilizare",                                                                                      // 38
  updateYourPassword: "Actualizați parola dvs.",                                                                       // 39
  username: "Nume utilizator",                                                                                         // 40
  usernameOrEmail: "Nume utilizator sau e-mail",                                                                       // 41
  "with": "cu",                                                                                                        // 42
  info: {                                                                                                              // 45
    emailSent: "Email trimis",                                                                                         // 46
    emailVerified: "Email verificat",                                                                                  // 47
    passwordChanged: "Parola a fost schimbata",                                                                        // 48
    passwordReset: "Resetare parola"                                                                                   // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Introduceti Email-ul.",                                                                            // 53
    minChar: "Parolă minima de 7 caractere ",                                                                          // 54
    pwdsDontMatch: "Parolele nu se potrivesc",                                                                         // 55
    pwOneDigit: "Parola trebuie să contină cel puțin o cifră.",                                                        // 56
    pwOneLetter: "Parola necesită o scrisoare.",                                                                       // 57
    signInRequired: "Autentificare.",                                                                                  // 58
    signupCodeIncorrect: "Codul de înregistrare este incorectă.",                                                      // 59
    signupCodeRequired: "Aveti nevoie de cod de înregistrare.",                                                        // 60
    usernameIsEmail: "Numele de utilizator nu poate fi o adresă de e-mail.",                                           // 61
    usernameRequired: "Introduceti numele de utilizator.",                                                             // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "E-mail există deja.",                                                                  // 70
      "Email doesn't match the criteria.": "E-mail nu se potrivește cu criteriile.",                                   // 71
      "Invalid login token": "Token invalid",                                                                          // 72
      "Login forbidden": "Autentificare interzisă",                                                                    // 73
      "Service unknown": "Service necunoscut",                                                                         // 75
      "Unrecognized options for login request": "Opțiuni nerecunoscute de cerere de conectare",                        // 76
      "User validation failed": "Validare utilizator nereușit",                                                        // 77
      "Username already exists.": "Numele de utilizator existent.",                                                    // 78
      "You are not logged in.": "Nu sunteti autentificat.",                                                            // 79
      "You've been logged out by the server. Please log in again.": "Ați fost deconectat de către server rugam sa va logati din nou.",
      "Your session has expired. Please log in again.": "Sesiunea a expirat rugam sa va logati din nou.",              // 81
      "No matching login attempt found": "Autentificare nereusită",                                                    // 85
      "Password is old. Please reset your password.": "Parola expirata, Vă rugăm să resetati parola.",                 // 89
      "Incorrect password": "Parola incorectă",                                                                        // 93
      "Invalid email": "E-mail invalid",                                                                               // 94
      "Must be logged in": "Trebuie sa fii logat",                                                                     // 95
      "Need to set a username or email": "Adaugati un nume utilizator sau un e-mail",                                  // 96
      "old password format": "Parola cu format vechi",                                                                 // 97
      "Password may not be empty": "Parola nu poate fi gol",                                                           // 98
      "Signups forbidden": "Înscrieri interzisă",                                                                      // 99
      "Token expired": "Token expirat",                                                                                // 100
      "Token has invalid email address": "Token are adresă de email invalidă",                                         // 101
      "User has no password set": "Utilizator nu are parola setată",                                                   // 102
      "User not found": "Utilizator nu a fost găsit",                                                                  // 103
      "Verify email link expired": "Link-ul de e-mail a expirat",                                                      // 104
      "Verify email link is for unknown address": "Link-ul de e-mail nu corespunde",                                   // 105
      "Match failed": "Potrivire nereușită",                                                                           // 108
      "Unknown error": "Eroare necunoscută"                                                                            // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("ro", ro);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/ru.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ru;                                                                                                                // 4
ru = {                                                                                                                 // 4
  add: "добавить",                                                                                                     // 6
  and: "и",                                                                                                            // 7
  back: "назад",                                                                                                       // 8
  changePassword: "Сменить пароль",                                                                                    // 9
  choosePassword: "Придумайте пароль",                                                                                 // 10
  clickAgree: "Нажав на Регистрация, вы соглашаетесь с условиями",                                                     // 11
  configure: "Конфигурировать",                                                                                        // 12
  createAccount: "Создать аккаунт",                                                                                    // 13
  currentPassword: "Текущий пароль",                                                                                   // 14
  dontHaveAnAccount: "Нет аккаунта?",                                                                                  // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Email",                                                                                               // 17
  emailResetLink: "Отправить ссылку для сброса",                                                                       // 18
  forgotPassword: "Забыли пароль?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Если у вас уже есть аккаунт",                                                            // 20
  newPassword: "Новый пароль",                                                                                         // 21
  newPasswordAgain: "Новый пароль (еще раз)",                                                                          // 22
  optional: "Необязательно",                                                                                           // 23
  OR: "ИЛИ",                                                                                                           // 24
  password: "Пароль",                                                                                                  // 25
  passwordAgain: "Пароль (еще раз)",                                                                                   // 26
  privacyPolicy: "Политики безопасности",                                                                              // 27
  remove: "Удалить",                                                                                                   // 28
  resetYourPassword: "Сбросить пароль",                                                                                // 29
  setPassword: "Установить пароль",                                                                                    // 30
  sign: "Подпись",                                                                                                     // 31
  signIn: "Войти",                                                                                                     // 32
  signin: "войти",                                                                                                     // 33
  signOut: "Выйти",                                                                                                    // 34
  signUp: "Регистрация",                                                                                               // 35
  signupCode: "Регистрационный код",                                                                                   // 36
  signUpWithYourEmailAddress: "Зарегистрируйтесь с вашим email адресом",                                               // 37
  terms: "Условиями пользования",                                                                                      // 38
  updateYourPassword: "Обновить пароль",                                                                               // 39
  username: "Имя пользователя",                                                                                        // 40
  usernameOrEmail: "Имя пользователя или email",                                                                       // 41
  "with": "через",                                                                                                     // 42
  info: {                                                                                                              // 45
    emailSent: "Email отправлен",                                                                                      // 46
    emailVerified: "Email прошел проверку",                                                                            // 47
    passwordChanged: "Пароль изменен",                                                                                 // 48
    passwordReset: "Пароль сброшен"                                                                                    // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email обязательно.",                                                                               // 53
    minChar: "Минимальное кол-во символов для пароля 7.",                                                              // 54
    pwdsDontMatch: "Пароли не совпадают",                                                                              // 55
    pwOneDigit: "В пароле должна быть хотя бы одна цифра.",                                                            // 56
    pwOneLetter: "В пароле должна быть хотя бы одна буква.",                                                           // 57
    signInRequired: "Необходимо войти для чтобы продолжить.",                                                          // 58
    signupCodeIncorrect: "Неправильный регистрационный код.",                                                          // 59
    signupCodeRequired: "Необходим регистрационый код.",                                                               // 60
    usernameIsEmail: "Имя пользователя не может быть адресом email.",                                                  // 61
    usernameRequired: "Имя пользователя обязательно.",                                                                 // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Email уже существует",                                                                 // 70
      "Email doesn't match the criteria.": "Email не соответствует критериям.",                                        // 71
      "Invalid login token": "Неверный токен для входа",                                                               // 72
      "Login forbidden": "Вход запрещен",                                                                              // 73
      "Service unknown": "Cервис неизвестен",                                                                          // 75
      "Unrecognized options for login request": "Неизвестные параметры для запроса входа",                             // 76
      "User validation failed": "Проверка пользователя неудалась",                                                     // 77
      "Username already exists.": "Пользователь существует.",                                                          // 78
      "You are not logged in.": "Вы не вошли.",                                                                        // 79
      "You've been logged out by the server. Please log in again.": "Сервер инициировал выход. Пожалуйста войдите еще раз.",
      "Your session has expired. Please log in again.": "Ваша сессия устарела. Пожалуйста войдите еще раз.",           // 81
      "No matching login attempt found": "Не было найдено соответствующей попытки войти",                              // 85
      "Password is old. Please reset your password.": "Пароль устарел. Пожалуйста, сбросьте Ваш пароль.",              // 89
      "Incorrect password": "Неправильный пароль",                                                                     // 93
      "Invalid email": "Несуществующий Email",                                                                         // 94
      "Must be logged in": "Необходимо войти",                                                                         // 95
      "Need to set a username or email": "Необходимо имя пользователя или email",                                      // 96
      "old password format": "старый формат пароля",                                                                   // 97
      "Password may not be empty": "Пароль не может быть пустым",                                                      // 98
      "Signups forbidden": "Регистрация отключена",                                                                    // 99
      "Token expired": "Время действия токена истекло",                                                                // 100
      "Token has invalid email address": "У токена неправильный email адрес",                                          // 101
      "User has no password set": "У пользователя не установлен пароль",                                               // 102
      "User not found": "Пользователь не найден",                                                                      // 103
      "Verify email link expired": "Ссылка подтверждения email устарела",                                              // 104
      "Verify email link is for unknown address": "Ссылка подтверждения email для неизвестного адреса",                // 105
      "Match failed": "Не совпадают",                                                                                  // 108
      "Unknown error": "Неизвестная ошибка"                                                                            // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("ru", ru);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/sk.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var sk;                                                                                                                // 4
sk = {                                                                                                                 // 4
  add: "pridať",                                                                                                       // 6
  and: "a",                                                                                                            // 7
  back: "späť",                                                                                                        // 8
  changePassword: "Zmena hesla",                                                                                       // 9
  choosePassword: "Zvoľte si heslo",                                                                                   // 10
  clickAgree: "Stlačením tlačidla \"Registrovať\" akceptujete",                                                        // 11
  configure: "Nastaviť",                                                                                               // 12
  createAccount: "Vytvoriť konto",                                                                                     // 13
  currentPassword: "Súčasné heslo",                                                                                    // 14
  dontHaveAnAccount: "Nemáte účet?",                                                                                   // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Emailová adresa",                                                                                     // 17
  emailResetLink: "Odoslať na email overovací odkaz",                                                                  // 18
  forgotPassword: "Zabudli ste heslo?",                                                                                // 19
  ifYouAlreadyHaveAnAccount: "Ak už máte vytvorený účet prejdite na",                                                  // 20
  newPassword: "Nové heslo",                                                                                           // 21
  newPasswordAgain: "Nové heslo (opakujte)",                                                                           // 22
  optional: "Voliteľné",                                                                                               // 23
  OR: "alebo",                                                                                                         // 24
  password: "Heslo",                                                                                                   // 25
  passwordAgain: "Heslo (opakujte)",                                                                                   // 26
  privacyPolicy: "pravidlá ochrany súkromia",                                                                          // 27
  remove: "odstrániť",                                                                                                 // 28
  resetYourPassword: "Obnovenie hesla",                                                                                // 29
  setPassword: "Nastaviť heslo",                                                                                       // 30
  sign: "Prihlásiť",                                                                                                   // 31
  signIn: "Prihlásenie",                                                                                               // 32
  signin: "prihlásenie",                                                                                               // 33
  signOut: "Odhlásiť",                                                                                                 // 34
  signUp: "Registrovať",                                                                                               // 35
  signupCode: "Registračný kód",                                                                                       // 36
  signUpWithYourEmailAddress: "Registrácia pomocou emailovej adresy",                                                  // 37
  terms: "pravidlá požívania",                                                                                         // 38
  updateYourPassword: "Aktualizovať heslo",                                                                            // 39
  username: "Užívateľské meno",                                                                                        // 40
  usernameOrEmail: "Užívateľské meno alebo email",                                                                     // 41
  "with": "s",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "Email odoslaný",                                                                                       // 46
    emailVerified: "Email bol overený",                                                                                // 47
    passwordChanged: "Heslo bolo zmenené",                                                                             // 48
    passwordReset: "Obnova hesla"                                                                                      // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email je vyžadovaný.",                                                                             // 53
    minChar: "minimálne 7 znakov heslo.",                                                                              // 54
    pwdsDontMatch: "Heslá sa nezhodujú",                                                                               // 55
    pwOneDigit: "Heslo musí mať aspoň jeden znak.",                                                                    // 56
    pwOneLetter: "Heslo musí mať aspoň 1 znak..",                                                                      // 57
    signInRequired: "Je vyžadované prihlásenie na túto akciu.",                                                        // 58
    signupCodeIncorrect: "Registračný kód je nesprávny.",                                                              // 59
    signupCodeRequired: "Je vyžadovaný registračný kód.",                                                              // 60
    usernameIsEmail: "Užvateľské meno nemôže byť email.",                                                              // 61
    usernameRequired: "Je vyžadované užívateľské meno.",                                                               // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Email už bol registrovaný.",                                                           // 70
      "Email doesn't match the criteria.": "Email nevyhovuje kritériam.",                                              // 71
      "Invalid login token": "Neplatný token prihlásenia",                                                             // 72
      "Login forbidden": "Prihlásenie neuspešné",                                                                      // 73
      "Service unknown": "Neznáma služba",                                                                             // 75
      "Unrecognized options for login request": "Neroznali sa podmienky pre požiadavku prihlásenia",                   // 76
      "User validation failed": "Overenie užívateľa zlyhalo",                                                          // 77
      "Username already exists.": "Užívateľ už existuje.",                                                             // 78
      "You are not logged in.": "Vyžaduje sa prihlásenie.",                                                            // 79
      "You've been logged out by the server. Please log in again.": "Boli ste odhlásený/á zo servera. Prosím prihláste sa znova.",
      "Your session has expired. Please log in again.": "Vaše príhlásenie expirovalo. Prosím prihláste sa znova.",     // 81
      "No matching login attempt found": "Prihlásenie nesúhlasí",                                                      // 85
      "Password is old. Please reset your password.": "Heslo je zastaralé. Prosím obnovte si ho.",                     // 89
      "Incorrect password": "Nesprávne heslo",                                                                         // 93
      "Invalid email": "Nesprávaný email",                                                                             // 94
      "Must be logged in": "Je vyžadované prihlásenie",                                                                // 95
      "Need to set a username or email": "Je potrebné nastaviť užívateľské meno a email",                              // 96
      "old password format": "formát starého hesla",                                                                   // 97
      "Password may not be empty": "Heslo nesmie byť prázdne",                                                         // 98
      "Signups forbidden": "Prihlásenie je zakázané",                                                                  // 99
      "Token expired": "Token expiroval",                                                                              // 100
      "Token has invalid email address": "Token obsahuje nesprávnu emailovú adresu",                                   // 101
      "User has no password set": "Užívateľ nemá nastavené heslo",                                                     // 102
      "User not found": "Užívateľ sa nenašiel",                                                                        // 103
      "Verify email link expired": "Odkazu pre overenie emailu vypršala platnosť.",                                    // 104
      "Verify email link is for unknown address": "Overovací odkaz je z nenámej adresy",                               // 105
      "Match failed": "Nezhodné",                                                                                      // 108
      "Unknown error": "Neznáma chyba"                                                                                 // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("sk", sk);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/sl.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var sl;                                                                                                                // 4
sl = {                                                                                                                 // 4
  add: "dodaj",                                                                                                        // 6
  and: "in",                                                                                                           // 7
  back: "nazaj",                                                                                                       // 8
  changePassword: "Spremeni geslo",                                                                                    // 9
  choosePassword: "Izberi geslo",                                                                                      // 10
  clickAgree: "S klikom na Registracija se strinjaš",                                                                  // 11
  configure: "Nastavi",                                                                                                // 12
  createAccount: "Nova registracija",                                                                                  // 13
  currentPassword: "Trenutno geslo",                                                                                   // 14
  dontHaveAnAccount: "Nisi registriran(a)?",                                                                           // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Email naslov",                                                                                        // 17
  emailResetLink: "Pošlji ponastavitveno povezavo",                                                                    // 18
  forgotPassword: "Pozabljeno geslo?",                                                                                 // 19
  ifYouAlreadyHaveAnAccount: "Če si že registriran(a),",                                                               // 20
  newPassword: "Novo geslo",                                                                                           // 21
  newPasswordAgain: "Novo geslo (ponovno)",                                                                            // 22
  optional: "Po želji",                                                                                                // 23
  OR: "ALI",                                                                                                           // 24
  password: "Geslo",                                                                                                   // 25
  passwordAgain: "Geslo (ponovno)",                                                                                    // 26
  privacyPolicy: "z našimi pogoji uporabe",                                                                            // 27
  remove: "briši",                                                                                                     // 28
  resetYourPassword: "Ponastavi geslo",                                                                                // 29
  setPassword: "Nastavi geslo",                                                                                        // 30
  sign: "Prijava",                                                                                                     // 31
  signIn: "Prijava",                                                                                                   // 32
  signin: "se prijavi",                                                                                                // 33
  signOut: "Odjava",                                                                                                   // 34
  signUp: "Registracija",                                                                                              // 35
  signupCode: "Prijavna koda",                                                                                         // 36
  signUpWithYourEmailAddress: "Prijava z email naslovom",                                                              // 37
  terms: "Pogoji uporabe",                                                                                             // 38
  updateYourPassword: "Spremeni geslo",                                                                                // 39
  username: "Uporabniško ime",                                                                                         // 40
  usernameOrEmail: "Uporabniško ime ali email",                                                                        // 41
  "with": "z",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "E-pošta poslana",                                                                                      // 46
    emailVerified: "Email naslov preverjen",                                                                           // 47
    passwordChanged: "Geslo spremenjeno",                                                                              // 48
    passwordReset: "Geslo ponastavljeno"                                                                               // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email je obvezen vnos.",                                                                           // 53
    minChar: "Geslo mora imeti vsaj sedem znakov.",                                                                    // 54
    pwdsDontMatch: "Gesli se ne ujemata",                                                                              // 55
    pwOneDigit: "V geslu mora biti vsaj ena številka.",                                                                // 56
    pwOneLetter: "V geslu mora biti vsaj ena črka.",                                                                   // 57
    signInRequired: "Za to moraš biti prijavljen(a).",                                                                 // 58
    signupCodeIncorrect: "Prijavna koda je napačna.",                                                                  // 59
    signupCodeRequired: "Prijavna koda je obvezen vnos.",                                                              // 60
    usernameIsEmail: "Uporabniško ime ne more biti email naslov.",                                                     // 61
    usernameRequired: "Uporabniško ime je obvezen vnos.",                                                              // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Email že obstaja.",                                                                    // 70
      "Email doesn't match the criteria.": "Email ne odgovarja kriterijem.",                                           // 71
      "Invalid login token": "Napačen prijavni žeton",                                                                 // 72
      "Login forbidden": "Prijava ni dovoljena",                                                                       // 73
      "Service unknown": "Neznana storitev",                                                                           // 75
      "Unrecognized options for login request": "Neznane možnosti v prijavnem zahtevku",                               // 76
      "User validation failed": "Preverjanje uporabnika neuspešno",                                                    // 77
      "Username already exists.": "Uporabniško ime že obstaja",                                                        // 78
      "You are not logged in.": "Nisi prijavljen(a).",                                                                 // 79
      "You've been logged out by the server. Please log in again.": "Odjavljen(a) si s strežnika. Ponovi prijavo.",    // 80
      "Your session has expired. Please log in again.": "Seja je potekla. Ponovi prijavo.",                            // 81
      "No matching login attempt found": "Prijava ne obstaja",                                                         // 85
      "Password is old. Please reset your password.": "Geslo je staro. Zamenjaj ga.",                                  // 89
      "Incorrect password": "Napačno geslo",                                                                           // 93
      "Invalid email": "Napačen email",                                                                                // 94
      "Must be logged in": "Moraš biti prijavljane(a)",                                                                // 95
      "Need to set a username or email": "Prijava ali email sta obvezna",                                              // 96
      "old password format": "stara oblika gesla",                                                                     // 97
      "Password may not be empty": "Geslo ne sme biti prazno",                                                         // 98
      "Signups forbidden": "Prijave onemogočene",                                                                      // 99
      "Token expired": "Žeton je potekel",                                                                             // 100
      "Token has invalid email address": "Žeton vsebuje napačen email",                                                // 101
      "User has no password set": "Uporabnik nima gesla",                                                              // 102
      "User not found": "Uporabnik ne obstaja",                                                                        // 103
      "Verify email link expired": "Povezava za potrditev je potekla",                                                 // 104
      "Verify email link is for unknown address": "Povezava za potrditev vsebuje neznan naslov",                       // 105
      "Match failed": "Prijava neuspešna",                                                                             // 108
      "Unknown error": "Neznana napaka"                                                                                // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("sl", sl);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/sv.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var sv;                                                                                                                // 4
sv = {                                                                                                                 // 4
  add: "lägg till",                                                                                                    // 6
  and: "och",                                                                                                          // 7
  back: "tillbaka",                                                                                                    // 8
  cancel: "Avbryt",                                                                                                    // 9
  changePassword: "Ändra lösenord",                                                                                    // 10
  choosePassword: "Välj lösenord",                                                                                     // 11
  clickAgree: "När du väljer att bli medlem så godkänner du också vår",                                                // 12
  configure: "Konfigurera",                                                                                            // 13
  createAccount: "Skapa ett konto",                                                                                    // 14
  currentPassword: "Nuvarande lösenord",                                                                               // 15
  dontHaveAnAccount: "Har du inget konto?",                                                                            // 16
  email: "E-postadress",                                                                                               // 17
  emailAddress: "E-postadress",                                                                                        // 18
  emailResetLink: "Återställningslänk för e-post",                                                                     // 19
  forgotPassword: "Glömt ditt lösenord?",                                                                              // 20
  ifYouAlreadyHaveAnAccount: "Är du redan medlem?",                                                                    // 21
  newPassword: "Nytt lösenord",                                                                                        // 22
  newPasswordAgain: "Nytt lösenord (upprepa)",                                                                         // 23
  optional: "Valfri",                                                                                                  // 24
  OR: "ELLER",                                                                                                         // 25
  password: "Lösenord",                                                                                                // 26
  passwordAgain: "Lösenord (upprepa)",                                                                                 // 27
  privacyPolicy: "integritetspolicy",                                                                                  // 28
  remove: "ta bort",                                                                                                   // 29
  resetYourPassword: "Återställ ditt lösenord",                                                                        // 30
  setPassword: "Välj lösenord",                                                                                        // 31
  sign: "Logga",                                                                                                       // 32
  signIn: "Logga in",                                                                                                  // 33
  signin: "logga in",                                                                                                  // 34
  signOut: "Logga ut",                                                                                                 // 35
  signUp: "Bli medlem",                                                                                                // 36
  signupCode: "Registreringskod",                                                                                      // 37
  signUpWithYourEmailAddress: "Bli medlem med e-postadress",                                                           // 38
  terms: "användarvillkor",                                                                                            // 39
  updateYourPassword: "Uppdatera ditt lösenord",                                                                       // 40
  username: "Användarnamn",                                                                                            // 41
  usernameOrEmail: "Användarnamn eller e-postadress",                                                                  // 42
  "with": "med",                                                                                                       // 43
  enterPassword: "Lösenord",                                                                                           // 44
  enterNewPassword: "Nytt lösenord",                                                                                   // 45
  enterEmail: "E-post",                                                                                                // 46
  enterUsername: "Användarnamn",                                                                                       // 47
  enterUsernameOrEmail: "Användarnamn eller e-post",                                                                   // 48
  orUse: "Eller använd",                                                                                               // 49
  info: {                                                                                                              // 52
    emailSent: "E-post skickades",                                                                                     // 53
    emailVerified: "E-post verifierades",                                                                              // 54
    passwordChanged: "Lösenordet har ändrats",                                                                         // 55
    passwordReset: "Återställ lösenordet"                                                                              // 56
  },                                                                                                                   // 53
  alert: {                                                                                                             // 58
    ok: 'Ok',                                                                                                          // 59
    type: {                                                                                                            // 60
      info: 'Info',                                                                                                    // 61
      error: 'Fel',                                                                                                    // 62
      warning: 'Varning'                                                                                               // 63
    }                                                                                                                  // 61
  },                                                                                                                   // 59
  error: {                                                                                                             // 65
    emailRequired: "Det krävs en e-postaddress.",                                                                      // 66
    minChar: "Det krävs minst 7 tecken i ditt lösenord.",                                                              // 67
    pwdsDontMatch: "Lösenorden matchar inte.",                                                                         // 68
    pwOneDigit: "Lösenordet måste ha minst 1 siffra.",                                                                 // 69
    pwOneLetter: "Lösenordet måste ha minst 1 bokstav.",                                                               // 70
    signInRequired: "Inloggning krävs här.",                                                                           // 71
    signupCodeIncorrect: "Registreringskoden är felaktig.",                                                            // 72
    signupCodeRequired: "Det krävs en registreringskod.",                                                              // 73
    usernameIsEmail: "Användarnamnet kan inte vara en e-postadress.",                                                  // 74
    usernameRequired: "Det krävs ett användarnamn.",                                                                   // 75
    accounts: {                                                                                                        // 78
      "Email already exists.": "E-postadressen finns redan.",                                                          // 83
      "Email doesn't match the criteria.": "E-postadressen uppfyller inte kriterierna.",                               // 84
      "Invalid login token": "Felaktig login-token",                                                                   // 85
      "Login forbidden": "Inloggning tillåts ej",                                                                      // 86
      "Service unknown": "Okänd service",                                                                              // 88
      "Unrecognized options for login request": "Okända val för inloggningsförsöket",                                  // 89
      "User validation failed": "Validering av användare misslyckades",                                                // 90
      "Username already exists.": "Användarnamn finns redan.",                                                         // 91
      "You are not logged in.": "Du är inte inloggad.",                                                                // 92
      "You've been logged out by the server. Please log in again.": "Du har loggats ut av servern. Vänligen logga in igen.",
      "Your session has expired. Please log in again.": "Din session har gått ut. Vänligen ligga in igen.",            // 94
      "Invalid email or username": "Ogiltig e-post eller användarnamn",                                                // 95
      "Internal server error": "Internt server problem",                                                               // 96
      "undefined": "Något gick fel",                                                                                   // 97
      "No matching login attempt found": "Inget matchande loginförsök kunde hittas",                                   // 101
      "Password is old. Please reset your password.": "Ditt lösenord är gammalt. Vänligen återställ ditt lösenord.",   // 105
      "Incorrect password": "Felaktigt lösenord",                                                                      // 109
      "Invalid email": "Ogiltig e-postadress",                                                                         // 110
      "Must be logged in": "Måste vara inloggad",                                                                      // 111
      "Need to set a username or email": "Ett användarnamn eller en e-postadress krävs.",                              // 112
      "old password format": "gammalt lösenordsformat",                                                                // 113
      "Password may not be empty": "Lösenordet får inte vara tomt",                                                    // 114
      "Signups forbidden": "Registrering förbjuden",                                                                   // 115
      "Token expired": "Token har gått ut",                                                                            // 116
      "Token has invalid email address": "Token har ogiltig e-postadress",                                             // 117
      "User has no password set": "Användaren har inget lösenord",                                                     // 118
      "User not found": "Användaren hittades inte",                                                                    // 119
      "Verify email link expired": "Länken för att verifera e-postadress har gått ut",                                 // 120
      "Verify email link is for unknown address": "Länken för att verifiera e-postadress är för en okänd adress.",     // 121
      "Match failed": "Matchning misslyckades",                                                                        // 124
      "Unknown error": "Okänt fel"                                                                                     // 127
    }                                                                                                                  // 83
  }                                                                                                                    // 66
};                                                                                                                     // 6
T9n.map("sv", sv);                                                                                                     // 130
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/th.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var th;                                                                                                                // 5
th = {                                                                                                                 // 5
  t9Name: 'Thai',                                                                                                      // 7
  add: "เพิ่ม",                                                                                                        // 9
  and: "และ",                                                                                                          // 10
  back: "ย้อนกลับ",                                                                                                    // 11
  cancel: "ยกเลิก",                                                                                                    // 12
  changePassword: "เปลี่ยนรหัสผ่าน",                                                                                   // 13
  choosePassword: "เลือกรหัสผ่าน",                                                                                     // 14
  clickAgree: "ด้วยการคลิกสมัครและยอมรับ",                                                                             // 15
  configure: "กำหนดค่า",                                                                                               // 16
  createAccount: "สร้างบัญชี",                                                                                         // 17
  currentPassword: "รหัสปัจจุบัน",                                                                                     // 18
  dontHaveAnAccount: "ยังไม่มีบัญชีใช่ไหม",                                                                            // 19
  email: "อีเมล์",                                                                                                     // 20
  emailAddress: "ที่อยู่อีเมล์",                                                                                       // 21
  emailResetLink: "อีเมล์สำหรับรหัสใหม่",                                                                              // 22
  forgotPassword: "คุณลืมรหัสใช่ไหม",                                                                                  // 23
  ifYouAlreadyHaveAnAccount: "ถ้าคุณมีบัญชีแล้ว",                                                                      // 24
  newPassword: "รหัสใหม่",                                                                                             // 25
  newPasswordAgain: "รหัสใหม่ (อีกครั้ง)",                                                                             // 26
  optional: "ไม่จำเป็น",                                                                                               // 27
  OR: "หรือ",                                                                                                          // 28
  password: "รหัสผ่าน",                                                                                                // 29
  passwordAgain: "รหัสผ่าน (อีกครั้ง)",                                                                                // 30
  privacyPolicy: "นโยบายความเป็นส่วนตัว",                                                                              // 31
  remove: "ลบ",                                                                                                        // 32
  resetYourPassword: "ตั้งรหัสผ่านใหม่",                                                                               // 33
  setPassword: "ตั้งรหัสผ่าน",                                                                                         // 34
  sign: "สัญลักษณ์",                                                                                                   // 35
  signIn: "เข้าสู่ระบบ",                                                                                               // 36
  signin: "เข้าสู่ระบบ",                                                                                               // 37
  signOut: "ออกจากระบบ",                                                                                               // 38
  signUp: "สมัคร",                                                                                                     // 39
  signupCode: "รหัสการลงทะเบียน",                                                                                      // 40
  signUpWithYourEmailAddress: "สมัครด้วยอีเมล์",                                                                       // 41
  terms: "ข้อกำหนดใช้งาน",                                                                                             // 42
  updateYourPassword: "แก้ไขรหัสของคุณ",                                                                               // 43
  username: "ชื่อผู้ใช้งาน",                                                                                           // 44
  usernameOrEmail: "ชื่อผู้ใช้งานหรืออีเมล์",                                                                          // 45
  "with": "กับ",                                                                                                       // 46
  maxAllowedLength: "ความยาวสูงสุดที่อนุญาต",                                                                          // 47
  minRequiredLength: "ความยาวต่ำสุดที่อนุญาต",                                                                         // 48
  resendVerificationEmail: "ส่งอีเมล์อีกครั้ง",                                                                        // 49
  resendVerificationEmailLink_pre: "อีเมล์ยืนยัน",                                                                     // 50
  resendVerificationEmailLink_link: "ส่งอีกครั้ง",                                                                     // 51
  enterPassword: "ป้อนรหัสผ่าน",                                                                                       // 52
  enterNewPassword: "ป้อนรหัสผ่านใหม่",                                                                                // 53
  enterEmail: "ป้อนอีเมล์",                                                                                            // 54
  enterUsername: "ป้อนชื่อผู้ใช้งาน",                                                                                  // 55
  enterUsernameOrEmail: "ป้อนชื่อผู้ใช้งานหรืออีเมล์",                                                                 // 56
  orUse: "หรือใช้",                                                                                                    // 57
  info: {                                                                                                              // 59
    emailSent: "ส่งอีเมล์",                                                                                            // 60
    emailVerified: "ตรวจสอบอีเมล์",                                                                                    // 61
    passwordChanged: "รหัสผ่านเปลี่ยนแล้ว",                                                                            // 62
    passwordReset: "ตั้งค่ารหัสผ่าน"                                                                                   // 63
  },                                                                                                                   // 60
  alert: {                                                                                                             // 65
    ok: 'ตกลง',                                                                                                        // 66
    type: {                                                                                                            // 67
      info: 'แจ้งให้ทราบ',                                                                                             // 68
      error: 'ผิดพลาด',                                                                                                // 69
      warning: 'เตือน'                                                                                                 // 70
    }                                                                                                                  // 68
  },                                                                                                                   // 66
  error: {                                                                                                             // 72
    emailRequired: "ต้องกรอกอีเมล์",                                                                                   // 73
    minChar: "รหัสผ่านต้องมีอย่างน้อย 7 ตัวอักษร",                                                                     // 74
    pwdsDontMatch: "รหัสผ่านไม่ตรงกัน",                                                                                // 75
    pwOneDigit: "รหัสผ่านต้องมีอย่างน้อยหนึ่งหลัก",                                                                    // 76
    pwOneLetter: "รหัสผ่านต้องมีตัวอักษร 1 ตัว",                                                                       // 77
    signInRequired: "คุณต้องลงนามในการกระทำว่า",                                                                       // 78
    signupCodeIncorrect: "รหัสการลงทะเบียนไม่ถูกต้อง",                                                                 // 79
    signupCodeRequired: "ต้องการรหัสลงทะเบียน",                                                                        // 80
    usernameIsEmail: "ชื่อผู้ใช้งานไม่สามารถเป็นที่อยู่อีเมล์",                                                        // 81
    usernameRequired: "ต้องการชื่อผู้ใช้งาน",                                                                          // 82
    accounts: {                                                                                                        // 85
      "Email already exists.": "อีเมล์มีอยู่แล้ว",                                                                     // 89
      "Email doesn't match the criteria.": "รูปแบบอีเมล์ไม่ถูกต้อง",                                                   // 90
      "Invalid login token": "หลักฐานการเข้าสู่ระบบไม่ถูกต้อง",                                                        // 91
      "Login forbidden": "ไม่อนุญาตให้เข้าสู่ระบบ",                                                                    // 92
      "Service unknown": "บริการที่ไม่รู้จัก",                                                                         // 94
      "Unrecognized options for login request": "ตัวเลือกที่ไม่รู้จักสำหรับคำขอเข้าสู่ระบบ",                           // 95
      "User validation failed": "การตรวจสอบผู้ใช้ล้มเหลว",                                                             // 96
      "Username already exists.": "ชื่อผู้ใช้มีอยู่แล้ว",                                                              // 97
      "You are not logged in.": "คุณยังไม่ได้เข้าสู่ระบบ",                                                             // 98
      "You've been logged out by the server. Please log in again.": "คุณได้ออกจากระบบโดยเซิร์ฟเวอร์ กรุณาเข้าสู่ระบบอีกครั้ง",
      "Your session has expired. Please log in again.": "session ของคุณหมดอายุ กรุณาเข้าสู่ระบบอีกครั้ง",              // 100
      "Already verified": "ยืนยันแล้ว",                                                                                // 101
      "Invalid email or username": "อีเมลหรือชื่อผู้ใช้ไม่ถูกต้อง",                                                    // 102
      "Internal server error": "ข้อผิดพลาดภายในเซิร์ฟเวอร์",                                                           // 103
      "undefined": "มีบางอย่างผิดพลาด",                                                                                // 104
      "No matching login attempt found": "ไม่พบการเข้าสู่ระบบ",                                                        // 108
      "Password is old. Please reset your password.": "รหัสผ่านเก่า โปรดตั้งค่ารหัสผ่านของคุณใหม่",                    // 112
      "Incorrect password": "รหัสผ่านผิดพลาด",                                                                         // 116
      "Invalid email": "อีเมล์ผิดพลาด",                                                                                // 117
      "Must be logged in": "ต้องเข้าสู่ระบบ",                                                                          // 118
      "Need to set a username or email": "จำเป็นที่จะต้องตั้งชื่อผู้ใช้หรืออีเมล์",                                    // 119
      "old password format": "รูปแบบรหัสผ่านเดิม",                                                                     // 120
      "Password may not be empty": "รหัสผ่านไม่เป็นค่าว่าง",                                                           // 121
      "Signups forbidden": "ไม่อนุญาตให้สมัคร",                                                                        // 122
      "Token expired": "Token หมดอายุ",                                                                                // 123
      "Token has invalid email address": "Token มีที่อยู่อีเมลไม่ถูกต้อง",                                             // 124
      "User has no password set": "ผู้ใช้ยังไม่มีการตั้งรหัสผ่าน",                                                     // 125
      "User not found": "ไม่พบชื่อผู้ใช้",                                                                             // 126
      "Verify email link expired": "ตรวจสอบการลิงค์อีเมลหมดอายุ",                                                      // 127
      "Verify email link is for unknown address": "ไม่รู้จักลิงค์ตรวจสอบอีเมล์",                                       // 128
      "At least 1 digit, 1 lowercase and 1 uppercase": "อย่างน้อย 1 หลัก 1 ตัวอักษรเล็ก และ 1 ตัวอักษรใหญ่",           // 129
      "Please verify your email first. Check the email and follow the link!": "โปรดยืนยันอีเมลของคุณก่อน ตรวจสอบอีเมลและทำตามลิงค์!",
      "A new email has been sent to you. If the email doesn't show up in your inbox, be sure to check your spam folder.": "อีเมลใหม่ได้ถูกส่งไปให้คุณแล้ว ถ้าอีเมลไม่แสดงในกล่องจดหมายของคุณให้ตรวจสอบโฟลเดอร์ spam ของคุณ",
      "Match failed": "จับคู่ล้มเหลว",                                                                                 // 134
      "Unknown error": "ไม่รู้ข้อผิดพลาด",                                                                             // 137
      "Error, too many requests. Please slow down. You must wait 1 seconds before trying again.": "ผิดพลาด ตอนนี้มีการร้องขอมากเกินไปโปรดรอ 1 วินาทีก่อนค่อยทำอีกครั้ง"
    }                                                                                                                  // 89
  }                                                                                                                    // 73
};                                                                                                                     // 7
T9n.map("th", th);                                                                                                     // 141
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/tr.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var tr;                                                                                                                // 4
tr = {                                                                                                                 // 4
  add: "ekle",                                                                                                         // 6
  and: "ve",                                                                                                           // 7
  back: "geri",                                                                                                        // 8
  changePassword: "Şifre Değiştir",                                                                                    // 9
  choosePassword: "Şifre Belirle",                                                                                     // 10
  clickAgree: "Kayıta tıklayarak kabul etmiş olacağınız",                                                              // 11
  configure: "Yapılandır",                                                                                             // 12
  createAccount: "Hesap Oluştur",                                                                                      // 13
  currentPassword: "Mevcut Şifre",                                                                                     // 14
  dontHaveAnAccount: "Hesabın yok mu?",                                                                                // 15
  email: "Eposta",                                                                                                     // 16
  emailAddress: "Eposta Adresi",                                                                                       // 17
  emailResetLink: "Email Reset Link",                                                                                  // 18
  forgotPassword: "Şifreni mi unuttun?",                                                                               // 19
  ifYouAlreadyHaveAnAccount: "Zaten bir hesabın varsa",                                                                // 20
  newPassword: "Yeni Şifre",                                                                                           // 21
  newPasswordAgain: "Yeni Şifre (tekrar)",                                                                             // 22
  optional: "İsteğe Bağlı",                                                                                            // 23
  OR: "VEYA",                                                                                                          // 24
  password: "Şifre",                                                                                                   // 25
  passwordAgain: "Şifre (tekrar)",                                                                                     // 26
  privacyPolicy: "Gizlilik Politikası",                                                                                // 27
  remove: "kaldır",                                                                                                    // 28
  resetYourPassword: "Şifreni sıfırla",                                                                                // 29
  setPassword: "Şifre Belirle",                                                                                        // 30
  sign: "Giriş",                                                                                                       // 31
  signIn: "Giriş",                                                                                                     // 32
  signin: "Giriş",                                                                                                     // 33
  signOut: "Çıkış",                                                                                                    // 34
  signUp: "Kayıt",                                                                                                     // 35
  signupCode: "Kayıt Kodu",                                                                                            // 36
  signUpWithYourEmailAddress: "Eposta adresin ile kaydol",                                                             // 37
  terms: "Kullanım Şartları",                                                                                          // 38
  updateYourPassword: "Şifreni güncelle",                                                                              // 39
  username: "Kullanıcı adı",                                                                                           // 40
  usernameOrEmail: "Kullanıcı adı veya şifre",                                                                         // 41
  "with": "için",                                                                                                      // 42
  info: {                                                                                                              // 45
    emailSent: "Eposta iletildi",                                                                                      // 46
    emailVerified: "Eposta doğrulandı",                                                                                // 47
    passwordChanged: "Şifre değişti",                                                                                  // 48
    passwordReset: "Şifre sıfırlandı"                                                                                  // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Eposta gerekli.",                                                                                  // 53
    minChar: "En az 7 karakterli şifre.",                                                                              // 54
    pwdsDontMatch: "Şifreler uyuşmuyor",                                                                               // 55
    pwOneDigit: "Şifre en az bir rakam içermeli.",                                                                     // 56
    pwOneLetter: "Şifre bir harf gerektiriyor.",                                                                       // 57
    signInRequired: "Bunun için önce giriş yapmış olmalısın.",                                                         // 58
    signupCodeIncorrect: "Kayıt kodu hatalı.",                                                                         // 59
    signupCodeRequired: "Kayıt kodu gerekli.",                                                                         // 60
    usernameIsEmail: "Kullanıcı adı bir eposta adresi olamaz.",                                                        // 61
    usernameRequired: "Kullanıcı adı gerekli.",                                                                        // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Eposta zaten kayıtlı.",                                                                // 70
      "Email doesn't match the criteria.": "Eposta kriterleri karşılamıyor.",                                          // 71
      "Invalid login token": "Geçersiz giriş işaretçisi",                                                              // 72
      "Login forbidden": "Girişe izin verilmiyor",                                                                     // 73
      "Service unknown": "Servis tanınmıyor",                                                                          // 75
      "Unrecognized options for login request": "Giriş isteği için tanınmayan seçenekler",                             // 76
      "User validation failed": "Kullanıcı doğrulama başarısız",                                                       // 77
      "Username already exists.": "Kullanıcı adı zaten kayıtlı.",                                                      // 78
      "You are not logged in.": "Kullanıcı girişi yapmadın.",                                                          // 79
      "You've been logged out by the server. Please log in again.": "Sunucu tarafından çıkarıldın. Lütfen tekrar kullanıcı girişi yap.",
      "Your session has expired. Please log in again.": "Oturumun zaman aşımına uğradı. Lütfen tekrar kullanıcı girişi yap.",
      "No matching login attempt found": "Eşleşen bir giriş teşebbüsü bulunamadı",                                     // 85
      "Password is old. Please reset your password.": "Şifre eski. Lütfen şifreni sıfırla.",                           // 89
      "Incorrect password": "Hatalı şifre",                                                                            // 93
      "Invalid email": "Hatalı eposta",                                                                                // 94
      "Must be logged in": "Giriş yapmış olmalısın",                                                                   // 95
      "Need to set a username or email": "Kullanıcı adı veya eposta tanımlamalısın",                                   // 96
      "old password format": "eski şifre biçimi",                                                                      // 97
      "Password may not be empty": "Şifre boş bırakılamaz",                                                            // 98
      "Signups forbidden": "Kayıt yapmaya izin verilmiyor",                                                            // 99
      "Token expired": "İşaretçinin süresi geçti",                                                                     // 100
      "Token has invalid email address": "İşaretçide geçersiz eposta adresi var",                                      // 101
      "User has no password set": "Kullanıcının şifresi tanımlanmamış",                                                // 102
      "User not found": "Kullanıcı bulunamadı",                                                                        // 103
      "Verify email link expired": "Eposta doğrulama bağlantısı zaman aşımına uğradı",                                 // 104
      "Verify email link is for unknown address": "Eposta doğrulama bağlantısı bilinmeyen bir adres içeriyor",         // 105
      "Match failed": "Eşleşme başarısız",                                                                             // 108
      "Unknown error": "Bilinmeyen hata"                                                                               // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("tr", tr);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/uk.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var uk;                                                                                                                // 4
uk = {                                                                                                                 // 4
  add: "додати",                                                                                                       // 6
  and: "та",                                                                                                           // 7
  back: "назад",                                                                                                       // 8
  changePassword: "Змінити пароль",                                                                                    // 9
  choosePassword: "Придумайте пароль",                                                                                 // 10
  clickAgree: "Натиснувши на Реєстрація ви погоджуєтеся з умовами",                                                    // 11
  configure: "Налаштувати",                                                                                            // 12
  createAccount: "Створити аккаунт",                                                                                   // 13
  currentPassword: "Діючий пароль",                                                                                    // 14
  dontHaveAnAccount: "Немає аккаунта?",                                                                                // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Email",                                                                                               // 17
  emailResetLink: "Отримати посилання для оновлення паролю",                                                           // 18
  forgotPassword: "Забули пароль?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Якщо у вас вже є аккаунт:",                                                              // 20
  newPassword: "Новий пароль",                                                                                         // 21
  newPasswordAgain: "Новий пароль (ще раз)",                                                                           // 22
  optional: "Необов’язково",                                                                                           // 23
  OR: "АБО",                                                                                                           // 24
  password: "Пароль",                                                                                                  // 25
  passwordAgain: "Пароль (ще раз)",                                                                                    // 26
  privacyPolicy: "Політики безпеки",                                                                                   // 27
  remove: "Видалити",                                                                                                  // 28
  resetYourPassword: "Відновити пароль",                                                                               // 29
  setPassword: "Встановити пароль",                                                                                    // 30
  sign: "Підпис",                                                                                                      // 31
  signIn: "Увійти",                                                                                                    // 32
  signin: "увійти",                                                                                                    // 33
  signOut: "Вийти",                                                                                                    // 34
  signUp: "Зареєструватися",                                                                                           // 35
  signupCode: "Реєстраційний код",                                                                                     // 36
  signUpWithYourEmailAddress: "Зареєструйтесь з вашою email адресою",                                                  // 37
  terms: "Умовами користування",                                                                                       // 38
  updateYourPassword: "Оновити пароль",                                                                                // 39
  username: "Ім’я користувача",                                                                                        // 40
  usernameOrEmail: "Ім’я користувача або email",                                                                       // 41
  "with": "з",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "Email відправлено",                                                                                    // 46
    emailVerified: "Email пройшов перевірку",                                                                          // 47
    passwordChanged: "Пароль змінено",                                                                                 // 48
    passwordReset: "Пароль скинуто"                                                                                    // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email є обов’язковим.",                                                                            // 53
    minChar: "Мінімальна кіл-ть символів для паролю 7.",                                                               // 54
    pwdsDontMatch: "Паролі не співпадають",                                                                            // 55
    pwOneDigit: "Пароль повинен містити хоча б одну цифру.",                                                           // 56
    pwOneLetter: "Пароль повинен містити хоча б одну букву.",                                                          // 57
    signInRequired: "Для продовження необхідно увійти.",                                                               // 58
    signupCodeIncorrect: "Невірний реєстраційний код.",                                                                // 59
    signupCodeRequired: "Необхідний реєстраційний код.",                                                               // 60
    usernameIsEmail: "Ім’я користувача не може бути email адресою.",                                                   // 61
    usernameRequired: "Ім’я користувача є обов’язковим.",                                                              // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "Email вже існує",                                                                      // 70
      "Email doesn't match the criteria.": "Email відповідає критеріям.",                                              // 71
      "Invalid login token": "Невірний токен для входу",                                                               // 72
      "Login forbidden": "Вхід заборонено",                                                                            // 73
      "Service unknown": "Невідомий сервіс",                                                                           // 75
      "Unrecognized options for login request": "Невідомі параметри для запиту входу",                                 // 76
      "User validation failed": "Перевірка користувача не вдалася",                                                    // 77
      "Username already exists.": "Користувач існує.",                                                                 // 78
      "You are not logged in.": "Ви не ввійшли.",                                                                      // 79
      "You've been logged out by the server. Please log in again.": "Сервер ініціював вихід. Будь ласка увійдіть ще раз.",
      "Your session has expired. Please log in again.": "Ваша сесія застаріла. Будь ласка увійдіть ще раз.",           // 81
      "No matching login attempt found": "Не було знайдено відповідної спроби увійти",                                 // 85
      "Password is old. Please reset your password.": "Пароль застарів. Будь ласка, скиньте Ваш пароль.",              // 89
      "Incorrect password": "Невірний пароль",                                                                         // 93
      "Invalid email": "Неіснуючий Email",                                                                             // 94
      "Must be logged in": "Необхідно увійти",                                                                         // 95
      "Need to set a username or email": "Необхідно ім’я користувача або email",                                       // 96
      "old password format": "старий формат паролю",                                                                   // 97
      "Password may not be empty": "Пароль не може бути пустим",                                                       // 98
      "Signups forbidden": "Реєстрацію відключено",                                                                    // 99
      "Token expired": "Час дії токена вичерпано",                                                                     // 100
      "Token has invalid email address": "Невірна email адреса для токена",                                            // 101
      "User has no password set": "У користувача не встановлено пароль",                                               // 102
      "User not found": "Користувач не знайдений",                                                                     // 103
      "Verify email link expired": "Посилання підтвердження email застаріло",                                          // 104
      "Verify email link is for unknown address": "Посилання підтвердження email для невідомої адреси",                // 105
      "Match failed": "Не співпадають",                                                                                // 108
      "Unknown error": "Невідома помилка"                                                                              // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("uk", uk);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/vi.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var vi;                                                                                                                // 4
vi = {                                                                                                                 // 4
  add: "thêm",                                                                                                         // 6
  and: "và",                                                                                                           // 7
  back: "trở lại",                                                                                                     // 8
  changePassword: "Đổi mật khẩu",                                                                                      // 9
  choosePassword: "Chọn một mật khẩu",                                                                                 // 10
  clickAgree: "Bằng cách nhấn vào Đăng ký, bạn đã đồng ý với",                                                         // 11
  configure: "Cấu hình",                                                                                               // 12
  createAccount: "Tạo Tài khoản",                                                                                      // 13
  currentPassword: "Mật khẩu hiện tại",                                                                                // 14
  dontHaveAnAccount: "Chưa có tài khoản?",                                                                             // 15
  email: "Email",                                                                                                      // 16
  emailAddress: "Địa chỉ Email",                                                                                       // 17
  emailResetLink: "Gửi",                                                                                               // 18
  forgotPassword: "Quên mật khẩu?",                                                                                    // 19
  ifYouAlreadyHaveAnAccount: "Nếu bạn đã có tài khoản",                                                                // 20
  newPassword: "Mật khẩu mới",                                                                                         // 21
  newPasswordAgain: "Mật khẩu mới (nhập lại)",                                                                         // 22
  optional: "Tùy chọn",                                                                                                // 23
  OR: "Hoặc",                                                                                                          // 24
  password: "Mật khẩu",                                                                                                // 25
  passwordAgain: "Mật khẩu (nhập lại)",                                                                                // 26
  privacyPolicy: "Chính sách bảo mật",                                                                                 // 27
  remove: "xóa",                                                                                                       // 28
  resetYourPassword: "Lấy lại mật khẩu",                                                                               // 29
  setPassword: "Thiết lập mật khẩu",                                                                                   // 30
  sign: "Ký",                                                                                                          // 31
  signIn: "Đăng nhập",                                                                                                 // 32
  signin: "đăng nhập",                                                                                                 // 33
  signOut: "Đăng xuất",                                                                                                // 34
  signUp: "Đăng ký",                                                                                                   // 35
  signupCode: "Mã đăng ký",                                                                                            // 36
  signUpWithYourEmailAddress: "Đăng ký với email của bạn",                                                             // 37
  terms: "Điều khoản sử dụng",                                                                                         // 38
  updateYourPassword: "Cập nhật mật khẩu",                                                                             // 39
  username: "Tên đăng nhập",                                                                                           // 40
  usernameOrEmail: "Tên đăng nhập hoặc email",                                                                         // 41
  "with": "với",                                                                                                       // 42
  info: {                                                                                                              // 45
    emailSent: "Email đã được gửi đi!",                                                                                // 46
    emailVerified: "Email đã được xác minh",                                                                           // 47
    passwordChanged: "Đã đổi mật khẩu",                                                                                // 48
    passwordReset: "Lất lại mật khẩu"                                                                                  // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "Email phải có.",                                                                                   // 53
    minChar: "Mật khẩu phải có ít nhất 7 ký tự.",                                                                      // 54
    pwdsDontMatch: "Mật khẩu không giống nhau",                                                                        // 55
    pwOneDigit: "Mật khẩu phải có ít nhất 1 chữ số.",                                                                  // 56
    pwOneLetter: "Mật khẩu phải có 1 ký tự chữ.",                                                                      // 57
    signInRequired: "Phải đăng nhập.",                                                                                 // 58
    signupCodeIncorrect: "Mã số đăng ký sai.",                                                                         // 59
    signupCodeRequired: "Phải có mã số đăng ký.",                                                                      // 60
    usernameIsEmail: "Tên đăng nhập không thể là địa chỉ email.",                                                      // 61
    usernameRequired: "Phải có tên đăng nhập.",                                                                        // 62
    accounts: {                                                                                                        // 65
      "A login handler should return a result or undefined": "Bộ xử lý đăng nhập phải trả về một kết quả hoặc undefined",
      "Email already exists.": "Email đã tồn tại.",                                                                    // 70
      "Email doesn't match the criteria.": "Email không phù hợp.",                                                     // 71
      "Invalid login token": "Mã đăng nhập không đúng",                                                                // 72
      "Login forbidden": "Đăng nhập bị cấm",                                                                           // 73
      "Service unknown": "Chưa biết Dịch vụ",                                                                          // 75
      "Unrecognized options for login request": "Tùy chọn không được công nhận đối với yêu cầu đăng nhập",             // 76
      "User validation failed": "Xác nhận người dùng thất bại",                                                        // 77
      "Username already exists.": "Tên đăng nhập đã tồn tại.",                                                         // 78
      "You are not logged in.": "Bạn chưa đăng nhập.",                                                                 // 79
      "You've been logged out by the server. Please log in again.": "Bạn đã bị đăng xuất bởi máy chủ. Vui lòng đăng nhập lại.",
      "Your session has expired. Please log in again.": "Thời gian đăng nhập đã hết. Vui lòng đăng nhập lại.",         // 81
      "No matching login attempt found": "Không tìm thấy đăng nhập phù hợp",                                           // 85
      "Password is old. Please reset your password.": "Mật khẩu đã cũ. Vui lòng lấy lại mật khẩu.",                    // 89
      "Incorrect password": "Mật khẩu sai",                                                                            // 93
      "Invalid email": "Email sai",                                                                                    // 94
      "Must be logged in": "Phải đăng nhập",                                                                           // 95
      "Need to set a username or email": "Phải điền tên đăng nhập hoặc email",                                         // 96
      "old password format": "định dạng mật khẩu cũ",                                                                  // 97
      "Password may not be empty": "mật khẩu không được để trống",                                                     // 98
      "Signups forbidden": "Đăng ký đã bị cấm",                                                                        // 99
      "Token expired": "Hết phiên đăng nhập",                                                                          // 100
      "Token has invalid email address": "Phiên đăng nhập chứa địa chỉ email sai",                                     // 101
      "User has no password set": "Người dùng chưa có mật khẩu",                                                       // 102
      "User not found": "Không tìm thấy người dùng",                                                                   // 103
      "Verify email link expired": "Đường dẫn xác nhận email đã hết hạn",                                              // 104
      "Verify email link is for unknown address": "Đường dẫn xác nhận email là cho địa chỉ chưa xác định",             // 105
      "Match failed": "Không đúng",                                                                                    // 108
      "Unknown error": "Lỗi chưa được biết"                                                                            // 111
    }                                                                                                                  // 69
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("vi", vi);                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/zh_CN.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var zh_CN;                                                                                                             // 4
zh_CN = {                                                                                                              // 4
  add: "添加",                                                                                                           // 6
  and: "和",                                                                                                            // 7
  back: "返回",                                                                                                          // 8
  cancel: "取消",                                                                                                        // 9
  changePassword: "修改密码",                                                                                              // 10
  choosePassword: "新密码",                                                                                               // 11
  clickAgree: "点击注册表示您同意",                                                                                             // 12
  configure: "配置",                                                                                                     // 13
  createAccount: "创建账户",                                                                                               // 14
  currentPassword: "当前密码",                                                                                             // 15
  dontHaveAnAccount: "没有账户？",                                                                                          // 16
  email: "电子邮箱",                                                                                                       // 17
  emailAddress: "电邮地址",                                                                                                // 18
  emailResetLink: "邮件重置链接",                                                                                            // 19
  forgotPassword: "忘记密码？",                                                                                             // 20
  ifYouAlreadyHaveAnAccount: "如果您已有账户",                                                                                // 21
  newPassword: "新密码",                                                                                                  // 22
  newPasswordAgain: "再输一遍新密码",                                                                                         // 23
  optional: "可选的",                                                                                                     // 24
  OR: "或",                                                                                                             // 25
  password: "密码",                                                                                                      // 26
  passwordAgain: "再输一遍密码",                                                                                             // 27
  privacyPolicy: "隐私条例",                                                                                               // 28
  remove: "移除",                                                                                                        // 29
  resetYourPassword: "重置您的密码",                                                                                         // 30
  setPassword: "设置密码",                                                                                                 // 31
  sign: "登",                                                                                                           // 32
  signIn: "登录",                                                                                                        // 33
  signin: "登录",                                                                                                        // 34
  signOut: "登出",                                                                                                       // 35
  signUp: "注册",                                                                                                        // 36
  signupCode: "注册码",                                                                                                   // 37
  signUpWithYourEmailAddress: "用您的电子邮件地址注册",                                                                           // 38
  terms: "使用条例",                                                                                                       // 39
  updateYourPassword: "更新您的密码",                                                                                        // 40
  username: "用户名",                                                                                                     // 41
  usernameOrEmail: "用户名或电子邮箱",                                                                                         // 42
  "with": "与",                                                                                                         // 43
  enterPassword: "输入密码",                                                                                               // 44
  enterNewPassword: "输入新密码",                                                                                           // 45
  enterEmail: "输入电子邮件",                                                                                                // 46
  enterUsername: "输入用户名",                                                                                              // 47
  enterUsernameOrEmail: "输入用户名或电子邮件",                                                                                  // 48
  orUse: "或是使用",                                                                                                       // 49
  info: {                                                                                                              // 51
    emailSent: "邮件已发出",                                                                                                // 52
    emailVerified: "邮件验证成功",                                                                                           // 53
    passwordChanged: "密码修改成功",                                                                                         // 54
    passwordReset: "密码重置成功"                                                                                            // 55
  },                                                                                                                   // 52
  error: {                                                                                                             // 58
    emailRequired: "必须填写电子邮件",                                                                                         // 59
    minChar: "密码至少7个字符长",                                                                                              // 60
    pwdsDontMatch: "两次密码不一致",                                                                                          // 61
    pwOneDigit: "密码中至少有一位数字",                                                                                          // 62
    pwOneLetter: "密码中至少有一位字母",                                                                                         // 63
    signInRequired: "您必须登录后才能查看",                                                                                      // 64
    signupCodeIncorrect: "注册码错误",                                                                                      // 65
    signupCodeRequired: "必须有注册码",                                                                                      // 66
    usernameIsEmail: "是用户名而不是电子邮件地址",                                                                                  // 67
    usernameRequired: "必须填写用户名。",                                                                                      // 68
    accounts: {                                                                                                        // 71
      "Email already exists.": "该电子邮件地址已被使用。",                                                                         // 76
      "Email doesn't match the criteria.": "错误的的电子邮件地址。",                                                              // 77
      "Invalid login token": "登录密匙错误",                                                                                 // 78
      "Login forbidden": "登录被阻止",                                                                                      // 79
      "Service unknown": "未知服务",                                                                                       // 81
      "Unrecognized options for login request": "登录请求存在无法识别的选项",                                                       // 82
      "User validation failed": "用户验证失败",                                                                              // 83
      "Username already exists.": "用户名已被占用。",                                                                          // 84
      "You are not logged in.": "您还没有登录。",                                                                             // 85
      "You've been logged out by the server. Please log in again.": "您被服务器登出了。请重新登录。",                                 // 86
      "Your session has expired. Please log in again.": "会话过期，请重新登录。",                                                 // 87
      "Invalid email or username": "不合法的电子邮件或用户名",                                                                     // 88
      "Internal server error": "内部服务器错误",                                                                              // 89
      "undefined": "未知错误",                                                                                             // 90
      "No matching login attempt found": "未发现对应登录请求",                                                                  // 94
      "Password is old. Please reset your password.": "密码过于老了，请重置您的密码。",                                               // 98
      "Incorrect password": "错误的密码",                                                                                   // 102
      "Invalid email": "不合法的电子邮件地址",                                                                                   // 103
      "Must be logged in": "必须先登录",                                                                                    // 104
      "Need to set a username or email": "必须设置用户名或电子邮件地址",                                                             // 105
      "old password format": "较老的密码格式",                                                                                // 106
      "Password may not be empty": "密码不应该为空",                                                                          // 107
      "Signups forbidden": "注册被禁止",                                                                                    // 108
      "Token expired": "密匙过期",                                                                                         // 109
      "Token has invalid email address": "密匙对应的电子邮箱地址不合法",                                                             // 110
      "User has no password set": "用户没有密码",                                                                            // 111
      "User not found": "未找到该用户",                                                                                      // 112
      "Verify email link expired": "激活验证邮件的链接已过期",                                                                     // 113
      "Verify email link is for unknown address": "验证邮件的链接去向未知地址",                                                     // 114
      "Match failed": "匹配失败",                                                                                          // 117
      "Unknown error": "未知错误"                                                                                          // 120
    }                                                                                                                  // 76
  }                                                                                                                    // 59
};                                                                                                                     // 6
T9n.map("zh_CN", zh_CN);                                                                                               // 123
T9n.map("zh-CN", zh_CN);                                                                                               // 124
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/zh_TW.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var zh_TW;                                                                                                             // 4
zh_TW = {                                                                                                              // 4
  add: "添加",                                                                                                           // 6
  and: "和",                                                                                                            // 7
  back: "返回",                                                                                                          // 8
  cancel: "取消",                                                                                                        // 9
  changePassword: "修改密碼",                                                                                              // 10
  choosePassword: "選擇密碼",                                                                                              // 11
  clickAgree: "點擊註冊, 您同意我們的",                                                                                          // 12
  configure: "配置",                                                                                                     // 13
  createAccount: "建立帳號",                                                                                               // 14
  currentPassword: "當前密碼",                                                                                             // 15
  dontHaveAnAccount: "還沒有賬戶?",                                                                                         // 16
  email: "電子郵箱",                                                                                                       // 17
  emailAddress: "電郵地址",                                                                                                // 18
  emailResetLink: "電子郵件重設連結",                                                                                          // 19
  forgotPassword: "忘記密碼?",                                                                                             // 20
  ifYouAlreadyHaveAnAccount: "如果您已有賬戶",                                                                                // 21
  newPassword: "新密碼",                                                                                                  // 22
  newPasswordAgain: "新密碼 (重新輸入)",                                                                                      // 23
  optional: "可選的",                                                                                                     // 24
  OR: "或",                                                                                                             // 25
  password: "密碼",                                                                                                      // 26
  passwordAgain: "密碼 (重新輸入)",                                                                                          // 27
  privacyPolicy: "隱私政策",                                                                                               // 28
  remove: "刪除",                                                                                                        // 29
  resetYourPassword: "重置您的密碼",                                                                                         // 30
  setPassword: "設置密碼",                                                                                                 // 31
  sign: "登",                                                                                                           // 32
  signIn: "登入",                                                                                                        // 33
  signin: "登入",                                                                                                        // 34
  signOut: "登出",                                                                                                       // 35
  signUp: "註冊",                                                                                                        // 36
  signupCode: "註冊碼",                                                                                                   // 37
  signUpWithYourEmailAddress: "使用您的電郵地址註冊",                                                                            // 38
  terms: "使用條款",                                                                                                       // 39
  updateYourPassword: "更新您的密碼",                                                                                        // 40
  username: "用戶名",                                                                                                     // 41
  usernameOrEmail: "用戶名或電子郵箱",                                                                                         // 42
  "with": "與",                                                                                                         // 43
  enterPassword: "輸入密碼",                                                                                               // 44
  enterNewPassword: "輸入新密碼",                                                                                           // 45
  enterEmail: "輸入電子郵件",                                                                                                // 46
  enterUsername: "輸入用戶名",                                                                                              // 47
  enterUsernameOrEmail: "輸入用戶名或電子郵件",                                                                                  // 48
  orUse: "或是使用",                                                                                                       // 49
  info: {                                                                                                              // 52
    emailSent: "郵件已發送",                                                                                                // 53
    emailVerified: "郵件已驗證",                                                                                            // 54
    passwordChanged: "密碼已修改",                                                                                          // 55
    passwordReset: "密碼重置"                                                                                              // 56
  },                                                                                                                   // 53
  error: {                                                                                                             // 59
    emailRequired: "必須填寫電子郵件。",                                                                                        // 60
    minChar: "密碼至少需要7個字符。",                                                                                            // 61
    pwdsDontMatch: "密碼不一致。",                                                                                           // 62
    pwOneDigit: "密碼必須至少有一位數字。",                                                                                        // 63
    pwOneLetter: "密碼必須至少有一位字母。",                                                                                       // 64
    signInRequired: "您必須先登錄才能繼續。",                                                                                     // 65
    signupCodeIncorrect: "註冊碼錯誤。",                                                                                     // 66
    signupCodeRequired: "必須有註冊碼。",                                                                                     // 67
    usernameIsEmail: "用戶名不能為電郵地址。",                                                                                    // 68
    usernameRequired: "必須有用戶名。",                                                                                       // 69
    accounts: {                                                                                                        // 72
      "Email already exists.": "電郵地址已被使用。",                                                                            // 77
      "Email doesn't match the criteria.": "電郵地址不符合條件。",                                                               // 78
      "Invalid login token": "無效的登錄令牌",                                                                                // 79
      "Login forbidden": "禁止登錄",                                                                                       // 80
      "Service unknown": "未知服務",                                                                                       // 82
      "Unrecognized options for login request": "無法識別的登錄請求選項",                                                         // 83
      "User validation failed": "用戶驗證失敗",                                                                              // 84
      "Username already exists.": "用戶名已經存在。",                                                                          // 85
      "You are not logged in.": "您尚未登入。",                                                                              // 86
      "You've been logged out by the server. Please log in again.": "你已被伺服器登出，請重新登入。",                                 // 87
      "Your session has expired. Please log in again.": "您的協定已過期，請重新登入。",                                              // 88
      "Invalid email or username": "無效的電子郵件或用戶名",                                                                      // 89
      "Internal server error": "内部服务器错误",                                                                              // 90
      "undefined": "未知錯誤",                                                                                             // 91
      "No matching login attempt found": "沒有找到匹配的登入請求",                                                                // 95
      "Password is old. Please reset your password.": "密碼是舊的。請重置您的密碼。",                                                // 99
      "Incorrect password": "密碼不正確",                                                                                   // 103
      "Invalid email": "無效的電子郵件",                                                                                      // 104
      "Must be logged in": "必須先登入",                                                                                    // 105
      "Need to set a username or email": "必須設置用戶名或電郵地址",                                                               // 106
      "old password format": "舊密碼格式",                                                                                  // 107
      "Password may not be empty": "密碼不能為空的",                                                                          // 108
      "Signups forbidden": "註冊被禁止",                                                                                    // 109
      "Token expired": "密匙過期",                                                                                         // 110
      "Token has invalid email address": "密匙具有無效的電郵地址",                                                                // 111
      "User has no password set": "用戶沒有設置密碼",                                                                          // 112
      "User not found": "找不到用戶",                                                                                       // 113
      "Verify email link expired": "驗證電郵連結已過期",                                                                        // 114
      "Verify email link is for unknown address": "驗證電郵連結是未知的地址",                                                      // 115
      "Match failed": "匹配失敗",                                                                                          // 118
      "Unknown error": "未知錯誤"                                                                                          // 121
    }                                                                                                                  // 77
  }                                                                                                                    // 60
};                                                                                                                     // 6
T9n.map("zh_TW", zh_TW);                                                                                               // 124
T9n.map("zh-TW", zh_TW);                                                                                               // 125
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/softwarerero_accounts-t9n/t9n/zh_HK.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var zh_HK;                                                                                                             // 4
zh_HK = {                                                                                                              // 4
  add: "新增",                                                                                                           // 6
  and: "和",                                                                                                            // 7
  back: "返回",                                                                                                          // 8
  changePassword: "修改密碼",                                                                                              // 9
  choosePassword: "選擇密碼",                                                                                              // 10
  clickAgree: "點擊註冊, 您同意我們的",                                                                                          // 11
  configure: "設定",                                                                                                     // 12
  createAccount: "建立帳號",                                                                                               // 13
  currentPassword: "現有密碼",                                                                                             // 14
  dontHaveAnAccount: "還沒有賬號？",                                                                                         // 15
  email: "電郵",                                                                                                         // 16
  emailAddress: "電郵地址",                                                                                                // 17
  emailResetLink: "重設電郵連結",                                                                                            // 18
  forgotPassword: "忘記密碼?",                                                                                             // 19
  ifYouAlreadyHaveAnAccount: "如果已有賬號",                                                                                 // 20
  newPassword: "新密碼",                                                                                                  // 21
  newPasswordAgain: "新密碼 (重新輸入)",                                                                                      // 22
  optional: "可選填",                                                                                                     // 23
  OR: "或",                                                                                                             // 24
  password: "密碼",                                                                                                      // 25
  passwordAgain: "密碼（重新輸入）",                                                                                           // 26
  privacyPolicy: "私隱條款",                                                                                               // 27
  remove: "刪除",                                                                                                        // 28
  resetYourPassword: "重置密碼",                                                                                           // 29
  setPassword: "設定密碼",                                                                                                 // 30
  sign: "登",                                                                                                           // 31
  signIn: "登入",                                                                                                        // 32
  signin: "登入",                                                                                                        // 33
  signOut: "登出",                                                                                                       // 34
  signUp: "註冊",                                                                                                        // 35
  signupCode: "註冊碼",                                                                                                   // 36
  signUpWithYourEmailAddress: "使用您的電郵地址註冊",                                                                            // 37
  terms: "使用條款",                                                                                                       // 38
  updateYourPassword: "更新您的密碼",                                                                                        // 39
  username: "用戶名",                                                                                                     // 40
  usernameOrEmail: "用戶名或電子郵箱",                                                                                         // 41
  "with": "與",                                                                                                         // 42
  info: {                                                                                                              // 45
    emailSent: "已發送郵件",                                                                                                // 46
    emailVerified: "已驗證郵件",                                                                                            // 47
    passwordChanged: "已修改密碼",                                                                                          // 48
    passwordReset: "密碼重置"                                                                                              // 49
  },                                                                                                                   // 46
  error: {                                                                                                             // 52
    emailRequired: "必須填寫電子郵件。",                                                                                        // 53
    minChar: "密碼至少需要 7 個字符。",                                                                                          // 54
    pwdsDontMatch: "密碼不一致。",                                                                                           // 55
    pwOneDigit: "密碼必須至少包括一個數字。",                                                                                       // 56
    pwOneLetter: "密碼必須至少有包括一個字符。",                                                                                     // 57
    signInRequired: "您必須先登錄才能繼續。",                                                                                     // 58
    signupCodeIncorrect: "註冊碼不符。",                                                                                     // 59
    signupCodeRequired: "必須有註冊碼。",                                                                                     // 60
    usernameIsEmail: "用戶名不能設為電郵地址。",                                                                                   // 61
    usernameRequired: "必須有用戶名。",                                                                                       // 62
    accounts: {                                                                                                        // 65
      "Email already exists.": "電郵地址已在本服務登記使用。",                                                                       // 70
      "Email doesn't match the criteria.": "電郵地址不符合條件。",                                                               // 71
      "Invalid login token": "無效的登錄編碼",                                                                                // 72
      "Login forbidden": "禁止登錄",                                                                                       // 73
      "Service unknown": "未知服務",                                                                                       // 75
      "Unrecognized options for login request": "無法識別的登錄請求",                                                           // 76
      "User validation failed": "用戶驗證失敗",                                                                              // 77
      "Username already exists.": "用戶名已存在。",                                                                           // 78
      "You are not logged in.": "您尚未登入。",                                                                              // 79
      "You've been logged out by the server. Please log in again.": "您已被強制登出，請重新登入。",                                  // 80
      "Your session has expired. Please log in again.": "閒置時間過長，請重新登入。",                                               // 81
      "No matching login attempt found": "沒有找到匹配的登入請求",                                                                // 85
      "Password is old. Please reset your password.": "密碼已失效，請重置。",                                                    // 89
      "Incorrect password": "密碼不正確",                                                                                   // 93
      "Invalid email": "無效的電子郵件",                                                                                      // 94
      "Must be logged in": "必須先登入",                                                                                    // 95
      "Need to set a username or email": "必須設置用戶名或電郵地址",                                                               // 96
      "old password format": "舊密碼格式",                                                                                  // 97
      "Password may not be empty": "密碼不能為空",                                                                           // 98
      "Signups forbidden": "註冊被禁止",                                                                                    // 99
      "Token expired": "編碼已經過期",                                                                                       // 100
      "Token has invalid email address": "編碼中的電郵地址無效",                                                                 // 101
      "User has no password set": "用戶尚未設置密碼",                                                                          // 102
      "User not found": "找不到用戶",                                                                                       // 103
      "Verify email link expired": "驗證電郵連結已過期",                                                                        // 104
      "Verify email link is for unknown address": "驗證電郵連結是未知的地址",                                                      // 105
      "Match failed": "無法配對",                                                                                          // 108
      "Unknown error": "無法確認的系統問題"                                                                                     // 111
    }                                                                                                                  // 70
  }                                                                                                                    // 53
};                                                                                                                     // 6
T9n.map("zh_HK", zh_HK);                                                                                               // 114
T9n.map("zh-HK", zh_HK);                                                                                               // 115
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['softwarerero:accounts-t9n'] = {}, {
  T9n: T9n
});

})();

//# sourceMappingURL=softwarerero_accounts-t9n.js.map
