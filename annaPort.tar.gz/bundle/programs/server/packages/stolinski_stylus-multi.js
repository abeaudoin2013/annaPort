(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['stolinski:stylus-multi'] = {};

})();
